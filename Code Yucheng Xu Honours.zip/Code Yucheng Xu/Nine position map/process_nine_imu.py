#!/usr/bin/env python3
"""Process Baby Paul IMU data from nine positions (P1-P9), recorded one at a time.
Create plots, result tables and a phase-normalised map video.

Run python process_nine_imu.py --help for options.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from dataclasses import dataclass
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.animation import FFMpegWriter
from PIL import Image
from scipy.interpolate import griddata
from scipy.signal import (
    butter,
    detrend,
    hilbert,
    periodogram,
    savgol_filter,
    sosfiltfilt,
)

try:
    import imageio_ffmpeg

    mpl.rcParams["animation.ffmpeg_path"] = imageio_ffmpeg.get_ffmpeg_exe()
except ImportError:
    # 如果没有安装 imageio_ffmpeg，则使用 PATH 中的 ffmpeg。
    pass


BASE_DIR = Path(__file__).resolve().parent
POSITIONS = [f"P{i}" for i in range(1, 10)]
POSITION_PATTERN = re.compile(
    r"(?<![A-Za-z0-9])P([1-9])(?![0-9])",
    re.IGNORECASE,
)
SUPPORTED_EXTENSIONS = {".txt", ".csv"}
GRAVITY_M_S2 = 9.80665


@dataclass
class LoadedIMU:
    time_s: np.ndarray
    acceleration_mg: np.ndarray
    source_format: str


@dataclass
class ProcessedPosition:
    position: str
    source_path: Path
    uniform_time_s: np.ndarray
    raw_acceleration_mg: np.ndarray
    filtered_acceleration_mg: np.ndarray
    pca_scores_mg: np.ndarray
    selected_component_index: int
    time_s: np.ndarray
    selected_signal_mg: np.ndarray
    phase: np.ndarray
    phase_profile_mg: np.ndarray
    metrics: dict[str, object]


def resolve_existing(path_text: str | Path) -> Path:
    """Resolve a path from the working folder or this program folder."""
    path = Path(path_text).expanduser()
    if path.is_absolute():
        return path
    if path.exists():
        return path.resolve()
    return (BASE_DIR / path).resolve()


def resolve_output(path_text: str | Path) -> Path:
    path = Path(path_text).expanduser()
    if path.is_absolute():
        return path
    return (BASE_DIR / path).resolve()


def normalise_column_name(name: object) -> str:
    text = str(name).strip().lower()
    text = text.replace("µ", "u").replace("μ", "u")
    return re.sub(r"[^a-z0-9]+", "_", text).strip("_")


def first_nonempty_line(path: Path) -> str:
    with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
        for line in handle:
            if line.strip():
                return line.strip()
    raise ValueError(f"The file is empty: {path.name}")


def line_looks_headered(line: str) -> bool:
    lower = line.lower()
    header_markers = (
        "acc_x",
        "accel_x",
        "acceleration_x",
        "scaled acc x",
        "sample_index",
        "time_us",
        "timestamp_us",
    )
    return any(marker in lower for marker in header_markers)


def acceleration_factor_to_mg(column_name: str) -> float:
    """Return the unit conversion factor for an acceleration column."""
    name = normalise_column_name(column_name)

    if (
        "m_s2" in name
        or "m_s_2" in name
        or "mps2" in name
        or "ms2" in name
    ):
        return 1000.0 / GRAVITY_M_S2

    if re.search(r"(^|_)mg($|_)", name) or name.endswith("mg"):
        return 1.0

    if re.search(r"(^|_)g($|_)", name) or name.endswith("_g"):
        return 1000.0

    # 原有 ICM-20948 记录器默认使用 mg。
    return 1.0


def find_axis_column(columns: dict[str, str], axis: str) -> str:
    exact_candidates = [
        f"acc_{axis}_mg",
        f"accel_{axis}_mg",
        f"acceleration_{axis}_mg",
        f"scaled_acc_{axis}_mg",
        f"scaled_accel_{axis}_mg",
        f"acc{axis}_mg",
        f"a{axis}_mg",
        f"a_{axis}_mg",
        f"acc_{axis}",
        f"accel_{axis}",
        f"acceleration_{axis}",
        f"acc{axis}",
        f"a{axis}_mg",
        f"a_{axis}",
    ]

    for candidate in exact_candidates:
        if candidate in columns:
            return columns[candidate]

    matches: list[str] = []

    for normalised, original in columns.items():
        has_acceleration = any(
            token in normalised
            for token in ("acc", "accel", "acceleration")
        )
        has_axis = (
            re.search(rf"(^|_){axis}($|_)", normalised) is not None
        )

        if (
            has_acceleration
            and has_axis
            and "accuracy" not in normalised
        ):
            matches.append(original)

    if len(matches) == 1:
        return matches[0]

    if not matches:
        raise ValueError(
            f"Could not find the acceleration {axis.upper()} column."
        )

    raise ValueError(
        f"Several possible acceleration {axis.upper()} columns "
        f"were found: {matches}"
    )


def numeric_time_seconds(
    frame: pd.DataFrame,
    columns: dict[str, str],
) -> np.ndarray:
    candidates = [
        ("time_us", 1e-6),
        ("timestamp_us", 1e-6),
        ("micros", 1e-6),
        ("time_ms", 1e-3),
        ("timestamp_ms", 1e-3),
        ("millis", 1e-3),
        ("time_s", 1.0),
        ("timestamp_s", 1.0),
        ("elapsed_s", 1.0),
    ]

    for name, factor in candidates:
        if name in columns:
            values = pd.to_numeric(
                frame[columns[name]],
                errors="coerce",
            ).to_numpy(float)
            return values * factor

    datetime_candidates = [
        "pc_timestamp_utc",
        "pc_time_utc",
        "utc_timestamp",
        "timestamp",
        "datetime",
        "pc_timestamp",
    ]

    for name in datetime_candidates:
        if name in columns:
            parsed = pd.to_datetime(
                frame[columns[name]],
                errors="coerce",
                utc=True,
                format="mixed",
            )

            if parsed.notna().sum() >= 100:
                nanoseconds = (
                    parsed.astype("int64", copy=False)
                    .to_numpy(dtype=float, copy=True)
                )
                nanoseconds[parsed.isna().to_numpy()] = np.nan
                return nanoseconds * 1e-9

    raise ValueError(
        "Could not find a usable time column. Expected time_us, "
        "time_ms, time_s, or a PC timestamp column."
    )


def load_headered_csv(path: Path) -> LoadedIMU:
    frame = pd.read_csv(path, sep=",", engine="python")

    if frame.empty:
        raise ValueError(f"No data rows were found in {path.name}.")

    columns = {
        normalise_column_name(column): str(column)
        for column in frame.columns
    }

    x_column = find_axis_column(columns, "x")
    y_column = find_axis_column(columns, "y")
    z_column = find_axis_column(columns, "z")
    time_s = numeric_time_seconds(frame, columns)

    acceleration = np.column_stack(
        [
            pd.to_numeric(frame[column], errors="coerce")
            .to_numpy(float)
            * acceleration_factor_to_mg(column)
            for column in (x_column, y_column, z_column)
        ]
    )

    return LoadedIMU(
        time_s=time_s,
        acceleration_mg=acceleration,
        source_format="headered CSV",
    )


def parse_raw_schema(
    fields: list[str],
) -> tuple[float, float, float, float] | None:
    """Parse the logger schema with optional leading timestamp fields."""
    for offset in (0, 1, 2):
        if len(fields) < offset + 8:
            continue

        try:
            sample_index = float(fields[offset])
            time_us = float(fields[offset + 1])
            dt_us = float(fields[offset + 2])
            acc_x = float(fields[offset + 5])
            acc_y = float(fields[offset + 6])
            acc_z = float(fields[offset + 7])
        except ValueError:
            continue

        if not np.isfinite(
            [sample_index, time_us, dt_us, acc_x, acc_y, acc_z]
        ).all():
            continue

        if time_us < 0 or dt_us <= 0:
            continue

        return time_us * 1e-6, acc_x, acc_y, acc_z

    return None


def load_headerless_log(path: Path) -> LoadedIMU:
    rows: list[tuple[float, float, float, float]] = []
    bad_lines: list[int] = []

    with path.open(
        "r",
        encoding="utf-8-sig",
        errors="replace",
        newline="",
    ) as handle:
        for line_number, raw_line in enumerate(handle, start=1):
            if not raw_line.strip():
                continue

            fields = next(csv.reader([raw_line]))
            parsed = parse_raw_schema(fields)

            if parsed is None:
                bad_lines.append(line_number)
            else:
                rows.append(parsed)

    if bad_lines:
        preview = ", ".join(
            str(number) for number in bad_lines[:8]
        )
        suffix = "..." if len(bad_lines) > 8 else ""

        raise ValueError(
            f"Could not parse line(s) {preview}{suffix} "
            f"in {path.name}."
        )

    if not rows:
        raise ValueError(
            f"No valid IMU rows were found in {path.name}."
        )

    array = np.asarray(rows, dtype=float)

    return LoadedIMU(
        time_s=array[:, 0],
        acceleration_mg=array[:, 1:4],
        source_format="ICM-20948 numeric log",
    )


def load_imu(path: Path) -> LoadedIMU:
    first_line = first_nonempty_line(path)

    loaded = (
        load_headered_csv(path)
        if line_looks_headered(first_line)
        else load_headerless_log(path)
    )

    valid = (
        np.isfinite(loaded.time_s)
        & np.isfinite(loaded.acceleration_mg).all(axis=1)
    )

    time_s = loaded.time_s[valid]
    acceleration = loaded.acceleration_mg[valid]

    if time_s.size < 100:
        raise ValueError(
            f"Only {time_s.size} valid samples were found in "
            f"{path.name}; at least 100 are required."
        )

    order = np.argsort(time_s)
    time_s = time_s[order]
    acceleration = acceleration[order]

    frame = pd.DataFrame(
        {
            "time_s": time_s,
            "acc_x_mg": acceleration[:, 0],
            "acc_y_mg": acceleration[:, 1],
            "acc_z_mg": acceleration[:, 2],
        }
    )

    frame = (
        frame.groupby("time_s", as_index=False)
        .mean(numeric_only=True)
        .sort_values("time_s")
    )

    time_s = frame["time_s"].to_numpy(dtype=float, copy=True)
    acceleration = frame[
        ["acc_x_mg", "acc_y_mg", "acc_z_mg"]
    ].to_numpy(dtype=float, copy=True)

    if time_s.size < 100 or not np.all(np.diff(time_s) > 0):
        raise ValueError(
            f"Timestamps in {path.name} must increase and "
            "contain at least 100 unique samples."
        )

    time_s = time_s - time_s[0]

    return LoadedIMU(
        time_s=time_s,
        acceleration_mg=acceleration,
        source_format=loaded.source_format,
    )


def discover_position_files(input_dir: Path) -> dict[str, Path]:
    if not input_dir.is_dir():
        raise FileNotFoundError(
            f"Input folder not found: {input_dir}"
        )

    mapping: dict[str, Path] = {}
    ignored: list[str] = []

    for path in sorted(input_dir.iterdir()):
        if (
            not path.is_file()
            or path.suffix.lower() not in SUPPORTED_EXTENSIONS
        ):
            continue

        match = POSITION_PATTERN.search(path.stem)

        if match is None:
            ignored.append(path.name)
            continue

        position = f"P{match.group(1)}"

        if position in mapping:
            raise ValueError(
                f"More than one file was assigned to {position}: "
                f"{mapping[position].name!r} and {path.name!r}. "
                "Keep exactly one file per position."
            )

        mapping[position] = path

    missing = [
        position for position in POSITIONS
        if position not in mapping
    ]

    if missing:
        detail = f" Missing positions: {', '.join(missing)}."

        if ignored:
            detail += (
                " Files without a P1-P9 label were ignored: "
                f"{', '.join(ignored)}."
            )

        raise ValueError(
            "Exactly nine IMU files are required, with P1-P9 "
            "in their filenames." + detail
        )

    return {
        position: mapping[position]
        for position in POSITIONS
    }


def load_positions(path: Path) -> pd.DataFrame:
    positions = pd.read_csv(path)
    required = {"position", "x_norm", "y_norm"}
    missing = required.difference(positions.columns)

    if missing:
        raise ValueError(
            f"Positions CSV is missing columns: {sorted(missing)}"
        )

    positions = positions[
        ["position", "x_norm", "y_norm"]
    ].copy()

    positions["position"] = (
        positions["position"].astype(str).str.upper()
    )

    if positions["position"].duplicated().any():
        raise ValueError(
            "positions.csv must have only one row for each position."
        )

    available = set(positions["position"])
    missing_positions = [
        position for position in POSITIONS
        if position not in available
    ]

    if missing_positions:
        raise ValueError(
            f"positions.csv does not contain: {missing_positions}"
        )

    positions = (
        positions.set_index("position")
        .loc[POSITIONS]
        .reset_index()
    )

    positions[["x_norm", "y_norm"]] = positions[
        ["x_norm", "y_norm"]
    ].apply(pd.to_numeric, errors="raise")

    coordinates = positions[
        ["x_norm", "y_norm"]
    ].to_numpy(float)

    if (
        not np.isfinite(coordinates).all()
        or np.any((coordinates < 0.0) | (coordinates > 1.0))
    ):
        raise ValueError(
            "All normalised position coordinates must be "
            "between 0 and 1."
        )

    return positions


def resample_uniform(
    loaded: LoadedIMU,
) -> tuple[np.ndarray, np.ndarray, dict[str, float]]:
    dt = np.diff(loaded.time_s)
    median_dt = float(np.median(dt))

    if median_dt <= 0:
        raise ValueError(
            "The median sampling interval is not positive."
        )

    fs = 1.0 / median_dt

    uniform_time = np.arange(
        0.0,
        loaded.time_s[-1] + 0.5 * median_dt,
        median_dt,
    )

    uniform_acceleration = np.column_stack(
        [
            np.interp(
                uniform_time,
                loaded.time_s,
                loaded.acceleration_mg[:, axis],
            )
            for axis in range(3)
        ]
    )

    timing = {
        "original_sample_count": int(len(loaded.time_s)),
        "uniform_sample_count": int(len(uniform_time)),
        "duration_s": float(
            uniform_time[-1] - uniform_time[0]
        ),
        "sampling_rate_hz": fs,
        "median_dt_s": median_dt,
        "minimum_dt_s": float(np.min(dt)),
        "maximum_dt_s": float(np.max(dt)),
        "sample_interval_cv_percent": float(
            100.0 * np.std(dt) / median_dt
        ),
    }

    return uniform_time, uniform_acceleration, timing


def spectral_measurements(
    signal_values: np.ndarray,
    fs: float,
    low_hz: float,
    high_hz: float,
) -> tuple[float, float, float]:
    nfft = max(
        16384,
        1 << int(np.ceil(np.log2(len(signal_values)))),
    )

    frequency, power = periodogram(
        signal_values,
        fs=fs,
        window="hann",
        detrend="linear",
        nfft=nfft,
        scaling="density",
    )

    allowed = np.flatnonzero(
        (frequency >= low_hz)
        & (frequency <= high_hz)
    )

    if allowed.size == 0:
        raise ValueError(
            "No spectral bins lie inside the selected "
            "respiratory band."
        )

    peak_index = int(
        allowed[np.argmax(power[allowed])]
    )
    peak_frequency = float(frequency[peak_index])

    # 使用峰值附近三个频点的对数功率进行抛物线细化。
    if (
        0 < peak_index < len(power) - 1
        and np.all(
            power[peak_index - 1:peak_index + 2] > 0
        )
    ):
        log_power = np.log(
            power[peak_index - 1:peak_index + 2]
        )
        denominator = (
            log_power[0]
            - 2.0 * log_power[1]
            + log_power[2]
        )

        if denominator != 0:
            offset = (
                0.5
                * (log_power[0] - log_power[2])
                / denominator
            )
            peak_frequency = float(
                frequency[peak_index]
                + offset * (frequency[1] - frequency[0])
            )

    band = (
        (frequency >= low_hz)
        & (frequency <= high_hz)
    )

    half_width = max(
        0.035,
        0.10 * peak_frequency,
    )

    peak_band = (
        band
        & (
            np.abs(frequency - peak_frequency)
            <= half_width
        )
    )

    remainder = band & ~peak_band

    # 修正频谱功率计算：
# Sum the selected PSD bins and multiply by the frequency spacing.
# This avoids integrating across the excluded peak region.
    df = float(frequency[1] - frequency[0])

    signal_power = float(
        np.sum(power[peak_band]) * df
    )
    noise_power = float(
        np.sum(power[remainder]) * df
    )

    tiny = np.finfo(float).tiny

    spectral_snr_db = float(
        10.0
        * np.log10(
            (signal_power + tiny)
            / (noise_power + tiny)
        )
    )

    concentration = float(
        signal_power
        / (signal_power + noise_power + tiny)
    )

    return (
        peak_frequency,
        spectral_snr_db,
        concentration,
    )


def circular_phase_profile(
    signal_values: np.ndarray,
    bins: int,
) -> tuple[np.ndarray, np.ndarray]:
    analytic_phase = (
        np.mod(
            np.angle(hilbert(signal_values)),
            2.0 * np.pi,
        )
        / (2.0 * np.pi)
    )

    indices = np.floor(
        analytic_phase * bins
    ).astype(int)
    indices = np.clip(indices, 0, bins - 1)

    profile = np.full(
        bins,
        np.nan,
        dtype=float,
    )

    for index in range(bins):
        values = signal_values[indices == index]
        if values.size:
            profile[index] = float(
                np.median(values)
            )

    valid = np.isfinite(profile)

    if valid.sum() < int(0.8 * bins):
        raise ValueError(
            "Too few respiratory phase bins contain samples."
        )

    phase = np.arange(bins, dtype=float) / bins

    profile = np.interp(
        phase,
        np.r_[
            phase[valid] - 1.0,
            phase[valid],
            phase[valid] + 1.0,
        ],
        np.tile(profile[valid], 3),
    )

    if bins >= 9:
        window = min(
            9,
            bins if bins % 2 else bins - 1,
        )
        profile = savgol_filter(
            profile,
            window_length=window,
            polyorder=2,
            mode="wrap",
        )

    profile -= float(np.mean(profile))

    # 将各点代表性周期的正峰对齐到约 25% 相位。
    # 这是顺序记录构成的合成周期，不代表同时采集。
    target_peak = bins // 4

    profile = np.roll(
        profile,
        target_peak - int(np.argmax(profile)),
    )

    return phase, profile


def process_position(
    position: str,
    path: Path,
    expected_rr_bpm: float,
    low_hz: float,
    high_hz: float,
    phase_bins: int,
) -> ProcessedPosition:
    loaded = load_imu(path)

    time_s, acceleration, timing = resample_uniform(
        loaded
    )

    fs = timing["sampling_rate_hz"]

    if not 0.0 < low_hz < high_hz < fs / 2.0:
        raise ValueError(
            f"Filter [{low_hz}, {high_hz}] Hz is invalid "
            f"for {path.name} at fs={fs:.3f} Hz."
        )

    acceleration_detrended = detrend(
        acceleration,
        axis=0,
        type="linear",
    )

    sos = butter(
        4,
        [low_hz, high_hz],
        btype="bandpass",
        fs=fs,
        output="sos",
    )

    filtered = sosfiltfilt(
        sos,
        acceleration_detrended,
        axis=0,
    )

    # 九点幅度分析仅中心化，不进行逐轴标准差归一化。
    centred = (
        filtered
        - np.mean(
            filtered,
            axis=0,
            keepdims=True,
        )
    )

    _, singular_values, components = np.linalg.svd(
        centred,
        full_matrices=False,
    )

    # 使用绝对值最大的载荷统一各主成分的数学极性。
    for index in range(components.shape[0]):
        dominant_loading = int(
            np.argmax(
                np.abs(components[index])
            )
        )

        if components[index, dominant_loading] < 0:
            components[index] *= -1.0

    scores = centred @ components.T

    variance = (
        singular_values**2
        / max(len(centred) - 1, 1)
    )
    explained = variance / np.sum(variance)

    # 每端裁剪 2 秒或记录长度的 5%，取较小者。
    trim = min(
        int(round(2.0 * fs)),
        max(
            0,
            int(round(0.05 * len(scores))),
        ),
    )

    analysis_slice = slice(
        trim,
        -trim if trim else None,
    )

    analysis_scores = scores[analysis_slice]
    analysis_time = time_s[analysis_slice]

    if len(analysis_scores) < 100:
        analysis_scores = scores
        analysis_time = time_s
        trim = 0

    frequencies: list[float] = []
    spectral_snr: list[float] = []
    concentrations: list[float] = []

    for component_index in range(3):
        frequency, snr_db, concentration = (
            spectral_measurements(
                analysis_scores[:, component_index],
                fs,
                low_hz,
                high_hz,
            )
        )

        frequencies.append(frequency)
        spectral_snr.append(snr_db)
        concentrations.append(concentration)

    # 保留原来的主成分选择规则：
    # Score each PC using spectral concentration, proximity to expected RR and variance.
    expected_hz = expected_rr_bpm / 60.0
    sigma_hz = max(
        0.05,
        0.20 * expected_hz,
    )

    closeness = np.exp(
        -0.5
        * (
            (
                np.asarray(frequencies)
                - expected_hz
            )
            / sigma_hz
        ) ** 2
    )

    variance_weight = (
        0.5
        + 0.5
        * np.sqrt(
            explained
            / max(
                float(np.max(explained)),
                np.finfo(float).eps,
            )
        )
    )

    selection_score = (
        np.asarray(concentrations)
        * closeness
        * variance_weight
    )

    selected_index = int(
        np.argmax(selection_score)
    )

    selected_signal = analysis_scores[
        :,
        selected_index,
    ]
    selected_frequency = frequencies[
        selected_index
    ]
    estimated_rr_bpm = (
        60.0 * selected_frequency
    )

    phase, profile = circular_phase_profile(
        selected_signal,
        phase_bins,
    )

    amplitude_p2p = float(
        np.percentile(selected_signal, 95)
        - np.percentile(selected_signal, 5)
    )

    flags: list[str] = []

    if timing["duration_s"] < 20.0:
        flags.append("SHORT_RECORDING")

    if timing["maximum_dt_s"] > max(
        0.25,
        5.0 * timing["median_dt_s"],
    ):
        flags.append("TIMING_GAP")

    if abs(
        estimated_rr_bpm - expected_rr_bpm
    ) > max(
        3.0,
        0.15 * expected_rr_bpm,
    ):
        flags.append("RR_MISMATCH")

    if spectral_snr[selected_index] < 0.0:
        flags.append("WEAK_SPECTRAL_PEAK")

    quality_flag = (
        "OK"
        if not flags
        else ";".join(flags)
    )

    metrics: dict[str, object] = {
        "position": position,
        "input_file": path.name,
        "source_format": loaded.source_format,
        **timing,
        "trimmed_edge_samples_each_side": trim,
        "bandpass_low_hz": low_hz,
        "bandpass_high_hz": high_hz,
        "expected_rr_bpm": expected_rr_bpm,
        "selected_component": (
            f"PC{selected_index + 1}"
        ),
        "selected_component_explained_variance_fraction": (
            float(explained[selected_index])
        ),
        "selected_component_spectral_snr_db": (
            spectral_snr[selected_index]
        ),
        "dominant_frequency_hz": selected_frequency,
        "estimated_rr_bpm": estimated_rr_bpm,
        "absolute_rr_difference_from_setting_bpm": (
            abs(
                estimated_rr_bpm
                - expected_rr_bpm
            )
        ),
        "amplitude_p2p_mg": amplitude_p2p,
        "pc_loading_x": float(
            components[selected_index, 0]
        ),
        "pc_loading_y": float(
            components[selected_index, 1]
        ),
        "pc_loading_z": float(
            components[selected_index, 2]
        ),
        "pc1_rr_bpm": 60.0 * frequencies[0],
        "pc2_rr_bpm": 60.0 * frequencies[1],
        "pc3_rr_bpm": 60.0 * frequencies[2],
        "quality_flag": quality_flag,
    }

    return ProcessedPosition(
        position=position,
        source_path=path,
        uniform_time_s=time_s,
        raw_acceleration_mg=acceleration,
        filtered_acceleration_mg=filtered,
        pca_scores_mg=scores,
        selected_component_index=selected_index,
        time_s=analysis_time - analysis_time[0],
        selected_signal_mg=selected_signal,
        phase=phase,
        phase_profile_mg=profile,
        metrics=metrics,
    )


def image_points(
    positions: pd.DataFrame,
    width: int,
    height: int,
) -> np.ndarray:
    x = (
        positions["x_norm"].to_numpy(float)
        * (width - 1)
    )
    y = (
        positions["y_norm"].to_numpy(float)
        * (height - 1)
    )
    return np.column_stack((x, y))


def interpolated_field(
    points: np.ndarray,
    values: np.ndarray,
    width: int,
    height: int,
    method: str,
    resolution: int = 500,
) -> np.ndarray:
    aspect = width / height

    rows = max(
        200,
        int(resolution / max(aspect, 1.0)),
    )
    columns = max(
        200,
        int(resolution * min(aspect, 1.0)),
    )

    grid_x, grid_y = np.meshgrid(
        np.linspace(
            0,
            width - 1,
            columns,
        ),
        np.linspace(
            0,
            height - 1,
            rows,
        ),
    )

    try:
        field = griddata(
            points,
            values,
            (grid_x, grid_y),
            method=method,
        )
    except Exception:
        field = griddata(
            points,
            values,
            (grid_x, grid_y),
            method="linear",
        )

    finite_values = values[
        np.isfinite(values)
    ]

    if finite_values.size:
        field = np.clip(
            field,
            finite_values.min(),
            finite_values.max(),
        )

    return field


def map_figure(
    background: np.ndarray,
    points: np.ndarray,
    labels: list[str],
    field: np.ndarray,
    title: str,
    colourbar_label: str,
    cmap_name: str,
    vmin: float,
    vmax: float,
    alpha: float,
    note: str,
) -> tuple[
    plt.Figure,
    plt.Axes,
    mpl.image.AxesImage,
]:
    height, width = background.shape[:2]

    mpl.rcParams.update(
        {
            "font.size": 11,
            "axes.titleweight": "bold",
            "figure.facecolor": "white",
        }
    )

    figure, axes = plt.subplots(
        figsize=(12.8, 7.2),
        layout="constrained",
    )

    axes.imshow(background)

    colourmap = mpl.colormaps[
        cmap_name
    ].copy()
    colourmap.set_bad(
        (0.0, 0.0, 0.0, 0.0)
    )

    overlay = axes.imshow(
        field,
        extent=(
            0,
            width - 1,
            height - 1,
            0,
        ),
        origin="upper",
        cmap=colourmap,
        vmin=vmin,
        vmax=vmax,
        alpha=alpha,
        interpolation="bilinear",
    )

    axes.scatter(
        points[:, 0],
        points[:, 1],
        s=38,
        facecolors="white",
        edgecolors="black",
        linewidths=0.9,
        zorder=4,
    )

    for label, (x, y) in zip(
        labels,
        points,
    ):
        axes.annotate(
            label,
            (x, y),
            xytext=(7, -7),
            textcoords="offset points",
            color="black",
            fontsize=9,
            weight="bold",
            zorder=5,
            bbox={
                "boxstyle": "round,pad=0.18",
                "fc": "white",
                "ec": "none",
                "alpha": 0.80,
            },
        )

    colourbar = figure.colorbar(
        overlay,
        ax=axes,
        fraction=0.038,
        pad=0.025,
    )
    colourbar.set_label(
        colourbar_label
    )

    axes.set_title(
        title,
        pad=10,
    )

    axes.text(
        0.5,
        0.015,
        note,
        transform=axes.transAxes,
        ha="center",
        va="bottom",
        fontsize=8,
        bbox={
            "boxstyle": "round,pad=0.3",
            "fc": "white",
            "ec": "none",
            "alpha": 0.82,
        },
    )

    axes.set_xlim(
        0,
        width - 1,
    )
    axes.set_ylim(
        height - 1,
        0,
    )
    axes.set_axis_off()

    return figure, axes, overlay


def create_static_map(
    background: np.ndarray,
    positions: pd.DataFrame,
    metrics: pd.DataFrame,
    output: Path,
    condition: str,
    alpha: float,
) -> Path:
    height, width = background.shape[:2]

    points = image_points(
        positions,
        width,
        height,
    )

    values = (
        metrics.set_index("position")
        .loc[POSITIONS, "amplitude_p2p_mg"]
        .to_numpy(float)
    )

    field = interpolated_field(
        points,
        values,
        width,
        height,
        method="linear",
    )

    vmin = 0.0
    vmax = float(np.max(values))

    if vmax <= vmin:
        vmax = vmin + 1.0

    figure, _, _ = map_figure(
        background,
        points,
        POSITIONS,
        field,
        f"Baby Paul IMU respiratory amplitude — {condition}",
        "PCA respiratory amplitude, robust p-p (mg)",
        "viridis",
        vmin,
        vmax,
        alpha,
        "P1-P9 are measured locations; colours between points "
        "are linearly interpolated.",
    )

    output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    figure.savefig(
        output,
        dpi=300,
        bbox_inches="tight",
        facecolor="white",
    )
    plt.close(figure)

    return output


def colour_limits(
    values: np.ndarray,
    *,
    include_zero: bool = False,
    include_value: float | None = None,
) -> tuple[float, float]:
    """Return plotting limits including requested reference values."""
    finite = np.asarray(
        values,
        dtype=float,
    )
    finite = finite[
        np.isfinite(finite)
    ]

    if finite.size == 0:
        return 0.0, 1.0

    lower = float(np.min(finite))
    upper = float(np.max(finite))

    if include_zero:
        lower = min(lower, 0.0)
        upper = max(upper, 0.0)

    if include_value is not None:
        lower = min(
            lower,
            include_value,
        )
        upper = max(
            upper,
            include_value,
        )

    span = upper - lower

    if span <= np.finfo(float).eps:
        padding = max(
            abs(upper) * 0.05,
            0.5,
        )
    else:
        padding = 0.06 * span

    return (
        lower - padding,
        upper + padding,
    )


def create_metric_map(
    background: np.ndarray,
    positions: pd.DataFrame,
    metrics: pd.DataFrame,
    metric: str,
    output: Path,
    condition: str,
    title: str,
    colourbar_label: str,
    cmap_name: str,
    alpha: float,
    *,
    include_zero: bool = False,
    include_reference: float | None = None,
    note: str = (
        "P1-P9 are measured locations; colours between points "
        "are linearly interpolated."
    ),
) -> Path:
    """Create one spatial map from a numeric result column."""
    height, width = background.shape[:2]

    points = image_points(
        positions,
        width,
        height,
    )

    values = (
        metrics.set_index("position")
        .loc[POSITIONS, metric]
        .to_numpy(float)
    )

    field = interpolated_field(
        points,
        values,
        width,
        height,
        method="linear",
    )

    vmin, vmax = colour_limits(
        values,
        include_zero=include_zero,
        include_value=include_reference,
    )

    figure, _, _ = map_figure(
        background,
        points,
        POSITIONS,
        field,
        f"{title} — {condition}",
        colourbar_label,
        cmap_name,
        vmin,
        vmax,
        alpha,
        note,
    )

    output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    figure.savefig(
        output,
        dpi=300,
        bbox_inches="tight",
        facecolor="white",
    )
    plt.close(figure)

    return output


def ordered_metrics(
    metrics: pd.DataFrame,
) -> pd.DataFrame:
    """Return metrics in the fixed P1-P9 order."""
    return (
        metrics.set_index("position")
        .loc[POSITIONS]
        .reset_index()
    )


def style_axes(
    axes: plt.Axes,
) -> None:
    axes.grid(
        axis="y",
        alpha=0.22,
        linewidth=0.7,
    )
    axes.spines[
        ["top", "right"]
    ].set_visible(False)


def add_bar_labels(
    axes: plt.Axes,
    bars: mpl.container.BarContainer,
    decimals: int = 2,
) -> None:
    labels = [
        f"{bar.get_height():.{decimals}f}"
        for bar in bars
    ]

    axes.bar_label(
        bars,
        labels=labels,
        padding=3,
        fontsize=8,
    )


def create_metric_summary(
    metrics: pd.DataFrame,
    output: Path,
    condition: str,
    expected_rr_bpm: float,
) -> Path:
    """Create a four-panel summary of the position metrics."""
    data = ordered_metrics(metrics)
    x = np.arange(len(data))
    labels = data["position"].tolist()

    colours = [
        "#2A9D8F"
        if flag == "OK"
        else "#D1495B"
        for flag in data["quality_flag"]
    ]

    figure, axes = plt.subplots(
        2,
        2,
        figsize=(14, 9),
        layout="constrained",
    )

    bars = axes[0, 0].bar(
        x,
        data["amplitude_p2p_mg"],
        color=colours,
    )
    axes[0, 0].set_title(
        "Respiratory amplitude"
    )
    axes[0, 0].set_ylabel(
        "Robust peak-to-peak amplitude (mg)"
    )
    add_bar_labels(
        axes[0, 0],
        bars,
    )

    bars = axes[0, 1].bar(
        x,
        data["estimated_rr_bpm"],
        color=colours,
    )
    axes[0, 1].axhline(
        expected_rr_bpm,
        color="#D62728",
        linestyle="--",
        linewidth=1.4,
        label=(
            f"Paul setting: {expected_rr_bpm:g} bpm"
        ),
    )
    axes[0, 1].set_title(
        "Estimated respiratory rate"
    )
    axes[0, 1].set_ylabel(
        "Breaths/min"
    )
    axes[0, 1].legend(
        frameon=False,
        fontsize=9,
    )
    add_bar_labels(
        axes[0, 1],
        bars,
    )

    bars = axes[1, 0].bar(
        x,
        data[
            "absolute_rr_difference_from_setting_bpm"
        ],
        color=colours,
    )

    tolerance = max(
        3.0,
        0.15 * expected_rr_bpm,
    )

    axes[1, 0].axhline(
        tolerance,
        color="#D62728",
        linestyle="--",
        linewidth=1.4,
        label=(
            "Automatic flag threshold: "
            f"{tolerance:g} bpm"
        ),
    )
    axes[1, 0].set_title(
        "Absolute respiratory-rate error"
    )
    axes[1, 0].set_ylabel(
        "Absolute error (breaths/min)"
    )
    axes[1, 0].legend(
        frameon=False,
        fontsize=9,
    )
    add_bar_labels(
        axes[1, 0],
        bars,
    )

    bars = axes[1, 1].bar(
        x,
        data[
            "selected_component_spectral_snr_db"
        ],
        color=colours,
    )
    axes[1, 1].axhline(
        0.0,
        color="#D62728",
        linestyle="--",
        linewidth=1.4,
        label="Weak-peak threshold: 0 dB",
    )
    axes[1, 1].set_title(
        "Respiratory-band spectral SNR"
    )
    axes[1, 1].set_ylabel(
        "SNR (dB)"
    )
    axes[1, 1].legend(
        frameon=False,
        fontsize=9,
    )
    add_bar_labels(
        axes[1, 1],
        bars,
    )

    for axes_item in axes.flat:
        axes_item.set_xticks(
            x,
            labels,
        )
        style_axes(axes_item)

    figure.suptitle(
        f"Baby Paul P1-P9 key metrics — {condition}",
        fontsize=16,
        weight="bold",
    )

    output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    figure.savefig(
        output,
        dpi=300,
        bbox_inches="tight",
        facecolor="white",
    )
    plt.close(figure)

    return output


def create_waveform_comparison(
    processed: list[ProcessedPosition],
    output: Path,
    condition: str,
) -> Path:
    """Plot the selected respiratory PCA signal for every position."""
    results = {
        item.position: item
        for item in processed
    }

    visible_duration = min(
        20.0,
        max(
            float(item.time_s[-1])
            for item in processed
        ),
    )

    visible_values = np.concatenate(
        [
            item.selected_signal_mg[
                item.time_s <= visible_duration
            ]
            for item in processed
            if np.any(
                item.time_s <= visible_duration
            )
        ]
    )

    limit = max(
        float(
            np.nanpercentile(
                np.abs(visible_values),
                99,
            )
        ),
        np.finfo(float).eps,
    )

    figure, axes = plt.subplots(
        3,
        3,
        figsize=(15, 10),
        sharex=True,
        sharey=True,
        layout="constrained",
    )

    for axes_item, position in zip(
        axes.flat,
        POSITIONS,
    ):
        item = results[position]
        keep = (
            item.time_s <= visible_duration
        )

        axes_item.plot(
            item.time_s[keep],
            item.selected_signal_mg[keep],
            color="#176B87",
            linewidth=0.9,
        )
        axes_item.axhline(
            0.0,
            color="black",
            linewidth=0.5,
            alpha=0.5,
        )
        axes_item.set_title(
            f"{position}: "
            f"{item.metrics['selected_component']}, "
            f"RR {float(item.metrics['estimated_rr_bpm']):.2f} bpm"
        )
        axes_item.set_xlim(
            0.0,
            visible_duration,
        )
        axes_item.set_ylim(
            -1.08 * limit,
            1.08 * limit,
        )
        axes_item.grid(
            alpha=0.2,
            linewidth=0.6,
        )

    for axes_item in axes[-1, :]:
        axes_item.set_xlabel(
            "Time (s)"
        )

    for axes_item in axes[:, 0]:
        axes_item.set_ylabel(
            "Selected PCA signal (mg)"
        )

    figure.suptitle(
        f"P1-P9 filtered PCA respiratory waveforms — {condition}\n"
        f"First {visible_duration:g} s shown with a shared vertical scale",
        fontsize=15,
        weight="bold",
    )

    output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    figure.savefig(
        output,
        dpi=300,
        bbox_inches="tight",
        facecolor="white",
    )
    plt.close(figure)

    return output


def selected_periodogram(
    item: ProcessedPosition,
) -> tuple[np.ndarray, np.ndarray]:
    fs = float(
        item.metrics["sampling_rate_hz"]
    )

    nfft = max(
        8192,
        1 << int(
            np.ceil(
                np.log2(
                    len(item.selected_signal_mg)
                )
            )
        ),
    )

    return periodogram(
        item.selected_signal_mg,
        fs=fs,
        window="hann",
        detrend="linear",
        nfft=nfft,
        scaling="density",
    )


def create_psd_comparison(
    processed: list[ProcessedPosition],
    output: Path,
    condition: str,
    expected_rr_bpm: float,
    low_hz: float,
    high_hz: float,
) -> Path:
    """Plot the respiratory-band PSD for each position."""
    results = {
        item.position: item
        for item in processed
    }

    figure, axes = plt.subplots(
        3,
        3,
        figsize=(15, 10),
        sharex=True,
        layout="constrained",
    )

    expected_hz = (
        expected_rr_bpm / 60.0
    )

    for axes_item, position in zip(
        axes.flat,
        POSITIONS,
    ):
        item = results[position]

        frequency, power = (
            selected_periodogram(item)
        )

        keep = (
            (frequency >= low_hz)
            & (frequency <= high_hz)
        )

        db = (
            10.0
            * np.log10(
                power[keep]
                + np.finfo(float).tiny
            )
        )

        axes_item.plot(
            frequency[keep],
            db,
            color="#5B3A9E",
            linewidth=1.0,
        )
        axes_item.axvline(
            expected_hz,
            color="#D62728",
            linestyle="--",
            linewidth=1.0,
            label="Paul setting",
        )
        axes_item.axvline(
            float(
                item.metrics[
                    "dominant_frequency_hz"
                ]
            ),
            color="#E69F00",
            linestyle=":",
            linewidth=1.2,
            label="Estimated peak",
        )
        axes_item.set_title(
            f"{position}: "
            f"{float(item.metrics['selected_component_spectral_snr_db']):.2f} dB"
        )
        axes_item.set_xlim(
            low_hz,
            high_hz,
        )
        axes_item.grid(
            alpha=0.2,
            linewidth=0.6,
        )

    for axes_item in axes[-1, :]:
        axes_item.set_xlabel(
            "Frequency (Hz)"
        )

    for axes_item in axes[:, 0]:
        axes_item.set_ylabel(
            "PSD (dB mg²/Hz)"
        )

    figure.suptitle(
        f"P1-P9 respiratory-band power spectra — {condition}\n"
        "Red dashed: Paul setting; orange dotted: estimated peak",
        fontsize=15,
        weight="bold",
    )

    output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    figure.savefig(
        output,
        dpi=300,
        bbox_inches="tight",
        facecolor="white",
    )
    plt.close(figure)

    return output


def create_phase_profile_comparison(
    processed: list[ProcessedPosition],
    output: Path,
    condition: str,
) -> Path:
    """Plot one phase-normalised respiratory cycle per position."""
    results = {
        item.position: item
        for item in processed
    }

    all_values = np.concatenate(
        [
            item.phase_profile_mg
            for item in processed
        ]
    )

    limit = max(
        float(
            np.nanpercentile(
                np.abs(all_values),
                99,
            )
        ),
        np.finfo(float).eps,
    )

    figure, axes = plt.subplots(
        3,
        3,
        figsize=(15, 10),
        sharex=True,
        sharey=True,
        layout="constrained",
    )

    for axes_item, position in zip(
        axes.flat,
        POSITIONS,
    ):
        item = results[position]

        axes_item.plot(
            item.phase * 100.0,
            item.phase_profile_mg,
            color="#C44E52",
            linewidth=1.5,
        )
        axes_item.fill_between(
            item.phase * 100.0,
            0.0,
            item.phase_profile_mg,
            color="#C44E52",
            alpha=0.15,
        )
        axes_item.axhline(
            0.0,
            color="black",
            linewidth=0.5,
            alpha=0.5,
        )
        axes_item.set_title(position)
        axes_item.set_xlim(
            0.0,
            100.0,
        )
        axes_item.set_ylim(
            -1.08 * limit,
            1.08 * limit,
        )
        axes_item.grid(
            alpha=0.2,
            linewidth=0.6,
        )

    for axes_item in axes[-1, :]:
        axes_item.set_xlabel(
            "Respiratory phase (%)"
        )

    for axes_item in axes[:, 0]:
        axes_item.set_ylabel(
            "PCA acceleration (mg)"
        )

    figure.suptitle(
        "P1-P9 phase-normalised representative "
        f"respiratory cycles — {condition}",
        fontsize=15,
        weight="bold",
    )

    output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    figure.savefig(
        output,
        dpi=300,
        bbox_inches="tight",
        facecolor="white",
    )
    plt.close(figure)

    return output


def create_pca_selection_summary(
    metrics: pd.DataFrame,
    output: Path,
    condition: str,
) -> Path:
    """Summarise selected component loadings and explained variance."""
    data = ordered_metrics(metrics)
    x = np.arange(len(data))
    width = 0.24

    figure, axes = plt.subplots(
        2,
        1,
        figsize=(14, 9),
        layout="constrained",
    )

    axes[0].bar(
        x - width,
        data["pc_loading_x"],
        width,
        label="X loading",
        color="#0072B2",
    )
    axes[0].bar(
        x,
        data["pc_loading_y"],
        width,
        label="Y loading",
        color="#E69F00",
    )
    axes[0].bar(
        x + width,
        data["pc_loading_z"],
        width,
        label="Z loading",
        color="#009E73",
    )
    axes[0].axhline(
        0.0,
        color="black",
        linewidth=0.7,
    )
    axes[0].set_title(
        "Selected PCA component loadings"
    )
    axes[0].set_ylabel(
        "Loading coefficient"
    )
    axes[0].set_xticks(
        x,
        data["position"],
    )
    axes[0].legend(
        ncol=3,
        frameon=False,
    )
    style_axes(axes[0])

    component_colours = {
        "PC1": "#4C78A8",
        "PC2": "#F58518",
        "PC3": "#54A24B",
    }

    colours = [
        component_colours.get(
            value,
            "#777777",
        )
        for value in data[
            "selected_component"
        ]
    ]

    bars = axes[1].bar(
        x,
        data[
            "selected_component_explained_variance_fraction"
        ] * 100.0,
        color=colours,
    )
    axes[1].set_title(
        "Variance explained by the selected component"
    )
    axes[1].set_ylabel(
        "Explained variance (%)"
    )
    axes[1].set_xticks(
        x,
        data["position"],
    )

    for bar, component in zip(
        bars,
        data["selected_component"],
    ):
        axes[1].text(
            bar.get_x()
            + bar.get_width() / 2.0,
            bar.get_height(),
            component,
            ha="center",
            va="bottom",
            fontsize=9,
            weight="bold",
        )

    style_axes(axes[1])

    figure.suptitle(
        f"PCA component selection — {condition}",
        fontsize=15,
        weight="bold",
    )

    output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    figure.savefig(
        output,
        dpi=300,
        bbox_inches="tight",
        facecolor="white",
    )
    plt.close(figure)

    return output


def create_data_quality_summary(
    metrics: pd.DataFrame,
    output: Path,
    condition: str,
) -> Path:
    """Plot acquisition timing checks and automatic quality flags."""
    data = ordered_metrics(metrics)
    x = np.arange(len(data))

    colours = [
        "#2A9D8F"
        if flag == "OK"
        else "#D1495B"
        for flag in data["quality_flag"]
    ]

    figure, axes = plt.subplots(
        2,
        2,
        figsize=(14, 9),
        layout="constrained",
    )

    bars = axes[0, 0].bar(
        x,
        data["sampling_rate_hz"],
        color=colours,
    )
    axes[0, 0].set_title(
        "Measured sampling rate"
    )
    axes[0, 0].set_ylabel(
        "Sampling rate (Hz)"
    )
    add_bar_labels(
        axes[0, 0],
        bars,
        decimals=3,
    )

    bars = axes[0, 1].bar(
        x,
        data["duration_s"],
        color=colours,
    )
    axes[0, 1].axhline(
        20.0,
        color="#D62728",
        linestyle="--",
        linewidth=1.2,
        label="Short-recording threshold",
    )
    axes[0, 1].set_title(
        "Usable recording duration"
    )
    axes[0, 1].set_ylabel(
        "Duration (s)"
    )
    axes[0, 1].legend(
        frameon=False,
        fontsize=9,
    )
    add_bar_labels(
        axes[0, 1],
        bars,
        decimals=1,
    )

    bars = axes[1, 0].bar(
        x,
        data["sample_interval_cv_percent"],
        color=colours,
    )
    axes[1, 0].set_title(
        "Sample-interval variability"
    )
    axes[1, 0].set_ylabel(
        "Interval coefficient of variation (%)"
    )
    add_bar_labels(
        axes[1, 0],
        bars,
        decimals=2,
    )

    axes[1, 1].set_title(
        "Automatic quality flags"
    )
    axes[1, 1].set_xlim(
        0.0,
        1.0,
    )
    axes[1, 1].set_ylim(
        -0.5,
        len(data) - 0.5,
    )
    axes[1, 1].invert_yaxis()
    axes[1, 1].set_axis_off()

    for row, record in data.iterrows():
        colour = (
            "#E7F5EF"
            if record["quality_flag"] == "OK"
            else "#FBE9EC"
        )

        axes[1, 1].text(
            0.02,
            row,
            f"{record['position']}: "
            f"{record['quality_flag']}",
            ha="left",
            va="center",
            fontsize=10,
            bbox={
                "boxstyle": "round,pad=0.32",
                "fc": colour,
                "ec": "none",
            },
        )

    for axes_item in (
        axes[0, 0],
        axes[0, 1],
        axes[1, 0],
    ):
        axes_item.set_xticks(
            x,
            data["position"],
        )
        style_axes(axes_item)

    figure.suptitle(
        f"P1-P9 data-quality summary — {condition}",
        fontsize=15,
        weight="bold",
    )

    output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    figure.savefig(
        output,
        dpi=300,
        bbox_inches="tight",
        facecolor="white",
    )
    plt.close(figure)

    return output


def create_position_diagnostic(
    item: ProcessedPosition,
    output: Path,
    condition: str,
    expected_rr_bpm: float,
    low_hz: float,
    high_hz: float,
) -> Path:
    """Create a six-panel diagnostic report for one position."""
    figure, axes = plt.subplots(
        3,
        2,
        figsize=(15, 12),
        layout="constrained",
    )

    axis_colours = [
        "#0072B2",
        "#E69F00",
        "#009E73",
    ]
    axis_names = [
        "X",
        "Y",
        "Z",
    ]

    raw_display = (
        item.raw_acceleration_mg
        - np.median(
            item.raw_acceleration_mg,
            axis=0,
        )
    )

    for index, (name, colour) in enumerate(
        zip(
            axis_names,
            axis_colours,
        )
    ):
        axes[0, 0].plot(
            item.uniform_time_s,
            raw_display[:, index],
            color=colour,
            linewidth=0.7,
            label=name,
        )
        axes[0, 1].plot(
            item.uniform_time_s,
            item.filtered_acceleration_mg[:, index],
            color=colour,
            linewidth=0.7,
            label=name,
        )

    axes[0, 0].set_title(
        "Raw acceleration fluctuations "
        "(median removed for display)"
    )
    axes[0, 0].set_ylabel(
        "Acceleration (mg)"
    )
    axes[0, 1].set_title(
        f"Band-pass filtered axes ({low_hz:g}–{high_hz:g} Hz)"
    )
    axes[0, 1].set_ylabel(
        "Filtered acceleration (mg)"
    )
    axes[0, 0].legend(
        ncol=3,
        frameon=False,
    )
    axes[0, 1].legend(
        ncol=3,
        frameon=False,
    )

    pc_colours = [
        "#4C78A8",
        "#F58518",
        "#54A24B",
    ]

    for index, colour in enumerate(
        pc_colours
    ):
        label = f"PC{index + 1}"

        if index == item.selected_component_index:
            label += " (selected)"

        axes[1, 0].plot(
            item.uniform_time_s,
            item.pca_scores_mg[:, index],
            color=colour,
            linewidth=0.7,
            label=label,
        )

    axes[1, 0].set_title(
        "All PCA component scores"
    )
    axes[1, 0].set_ylabel(
        "PCA score (mg)"
    )
    axes[1, 0].legend(
        ncol=3,
        frameon=False,
        fontsize=8,
    )

    axes[1, 1].plot(
        item.time_s,
        item.selected_signal_mg,
        color="#176B87",
        linewidth=0.9,
    )
    axes[1, 1].axhline(
        0.0,
        color="black",
        linewidth=0.5,
        alpha=0.5,
    )
    axes[1, 1].set_title(
        "Selected respiratory signal: "
        f"{item.metrics['selected_component']} | "
        f"amplitude {float(item.metrics['amplitude_p2p_mg']):.2f} mg"
    )
    axes[1, 1].set_ylabel(
        "Selected PCA signal (mg)"
    )

    frequency, power = (
        selected_periodogram(item)
    )

    keep = (
        (frequency >= low_hz)
        & (frequency <= high_hz)
    )

    axes[2, 0].plot(
        frequency[keep],
        10.0 * np.log10(
            power[keep]
            + np.finfo(float).tiny
        ),
        color="#5B3A9E",
        linewidth=1.0,
    )
    axes[2, 0].axvline(
        expected_rr_bpm / 60.0,
        color="#D62728",
        linestyle="--",
        linewidth=1.2,
        label="Paul setting",
    )
    axes[2, 0].axvline(
        float(
            item.metrics[
                "dominant_frequency_hz"
            ]
        ),
        color="#E69F00",
        linestyle=":",
        linewidth=1.4,
        label="Estimated peak",
    )
    axes[2, 0].set_xlim(
        low_hz,
        high_hz,
    )
    axes[2, 0].set_title(
        "Respiratory-band PSD | "
        f"SNR {float(item.metrics['selected_component_spectral_snr_db']):.2f} dB"
    )
    axes[2, 0].set_xlabel(
        "Frequency (Hz)"
    )
    axes[2, 0].set_ylabel(
        "PSD (dB mg²/Hz)"
    )
    axes[2, 0].legend(
        frameon=False,
        fontsize=8,
    )

    axes[2, 1].plot(
        item.phase * 100.0,
        item.phase_profile_mg,
        color="#C44E52",
        linewidth=1.5,
    )
    axes[2, 1].fill_between(
        item.phase * 100.0,
        0.0,
        item.phase_profile_mg,
        color="#C44E52",
        alpha=0.15,
    )
    axes[2, 1].axhline(
        0.0,
        color="black",
        linewidth=0.5,
        alpha=0.5,
    )
    axes[2, 1].set_xlim(
        0.0,
        100.0,
    )
    axes[2, 1].set_title(
        "Phase-normalised representative cycle"
    )
    axes[2, 1].set_xlabel(
        "Respiratory phase (%)"
    )
    axes[2, 1].set_ylabel(
        "PCA acceleration (mg)"
    )

    for axes_item in axes.flat:
        axes_item.grid(
            alpha=0.2,
            linewidth=0.6,
        )

    for axes_item in axes[:2, :].flat:
        axes_item.set_xlabel(
            "Time (s)"
        )

    figure.suptitle(
        f"{item.position} complete IMU diagnostic — {condition}\n"
        f"Estimated RR {float(item.metrics['estimated_rr_bpm']):.2f} bpm | "
        f"quality: {item.metrics['quality_flag']}",
        fontsize=15,
        weight="bold",
    )

    output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    figure.savefig(
        output,
        dpi=300,
        bbox_inches="tight",
        facecolor="white",
    )
    plt.close(figure)

    return output


def create_complete_static_outputs(
    background: np.ndarray,
    positions: pd.DataFrame,
    metrics: pd.DataFrame,
    processed: list[ProcessedPosition],
    output_dir: Path,
    condition: str,
    expected_rr_bpm: float,
    low_hz: float,
    high_hz: float,
    alpha: float,
) -> list[Path]:
    """Create all static result figures and return their paths."""
    map_dir = (
        output_dir / "colour_maps"
    )
    comparison_dir = (
        output_dir / "comparison_figures"
    )
    diagnostic_dir = (
        output_dir / "position_diagnostics"
    )

    outputs = [
        create_metric_map(
            background,
            positions,
            metrics,
            "amplitude_p2p_mg",
            map_dir
            / "01_IMU_respiratory_amplitude_map.png",
            condition,
            "Baby Paul IMU respiratory amplitude",
            "Robust peak-to-peak amplitude (mg)",
            "viridis",
            alpha,
            include_zero=True,
        ),
        create_metric_map(
            background,
            positions,
            metrics,
            "estimated_rr_bpm",
            map_dir
            / "02_estimated_respiratory_rate_map.png",
            condition,
            "Baby Paul estimated respiratory rate",
            "Estimated respiratory rate (breaths/min)",
            "plasma",
            alpha,
            include_reference=expected_rr_bpm,
            note=(
                f"Paul setting: {expected_rr_bpm:g} breaths/min. "
                "P1-P9 are measured; colours between points "
                "are interpolated."
            ),
        ),
        create_metric_map(
            background,
            positions,
            metrics,
            "absolute_rr_difference_from_setting_bpm",
            map_dir
            / "03_absolute_respiratory_rate_error_map.png",
            condition,
            "Baby Paul absolute respiratory-rate error",
            "Absolute RR error (breaths/min)",
            "magma",
            alpha,
            include_zero=True,
        ),
        create_metric_map(
            background,
            positions,
            metrics,
            "selected_component_spectral_snr_db",
            map_dir
            / "04_respiratory_spectral_snr_map.png",
            condition,
            "Baby Paul respiratory spectral SNR",
            "Respiratory-band spectral SNR (dB)",
            "cividis",
            alpha,
            include_reference=0.0,
        ),
        create_metric_summary(
            metrics,
            comparison_dir
            / "05_P1_P9_key_metrics.png",
            condition,
            expected_rr_bpm,
        ),
        create_waveform_comparison(
            processed,
            comparison_dir
            / "06_P1_P9_PCA_waveforms.png",
            condition,
        ),
        create_psd_comparison(
            processed,
            comparison_dir
            / "07_P1_P9_power_spectra.png",
            condition,
            expected_rr_bpm,
            low_hz,
            high_hz,
        ),
        create_phase_profile_comparison(
            processed,
            comparison_dir
            / "08_P1_P9_phase_profiles.png",
            condition,
        ),
        create_pca_selection_summary(
            metrics,
            comparison_dir
            / "09_PCA_component_selection.png",
            condition,
        ),
        create_data_quality_summary(
            metrics,
            comparison_dir
            / "10_data_quality_summary.png",
            condition,
        ),
    ]

    for item in processed:
        outputs.append(
            create_position_diagnostic(
                item,
                diagnostic_dir
                / f"{item.position}_complete_diagnostic.png",
                condition,
                expected_rr_bpm,
                low_hz,
                high_hz,
            )
        )

    return outputs


def create_animation(
    background: np.ndarray,
    positions: pd.DataFrame,
    phase_profiles: pd.DataFrame,
    output: Path,
    condition: str,
    alpha: float,
    method: str,
    cycles: int,
    fps: int,
    dpi: int,
) -> Path:
    height, width = background.shape[:2]

    points = image_points(
        positions,
        width,
        height,
    )

    phase_values = np.sort(
        phase_profiles["phase"].unique()
    )

    values_by_phase = np.vstack(
        [
            phase_profiles[
                phase_profiles["position"] == position
            ]
            .sort_values("phase")["value_mg"]
            .to_numpy(float)
            for position in POSITIONS
        ]
    ).T

    limit = float(
        np.nanpercentile(
            np.abs(values_by_phase),
            99,
        )
    )
    limit = max(
        limit,
        np.finfo(float).eps,
    )

    initial = interpolated_field(
        points,
        values_by_phase[0],
        width,
        height,
        method=method,
    )

    figure, axes, overlay = map_figure(
        background,
        points,
        POSITIONS,
        initial,
        "Baby Paul phase-normalised composite "
        f"respiratory motion — {condition}",
        "PCA respiratory acceleration (mg)",
        "RdBu_r",
        -limit,
        limit,
        alpha,
        "Sequential P1-P9 recordings were aligned by respiratory "
        "phase; spatial interpolation is for visualisation.",
    )

    phase_text = axes.text(
        0.02,
        0.97,
        "Respiratory phase: 0%",
        transform=axes.transAxes,
        ha="left",
        va="top",
        fontsize=11,
        weight="bold",
        bbox={
            "boxstyle": "round,pad=0.35",
            "fc": "white",
            "ec": "none",
            "alpha": 0.86,
        },
    )

    output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    writer = FFMpegWriter(
        fps=fps,
        codec="libx264",
        bitrate=6000,
        extra_args=[
            "-pix_fmt",
            "yuv420p",
            "-movflags",
            "+faststart",
        ],
        metadata={
            "title": (
                f"Baby Paul IMU colour map — {condition}"
            ),
            "artist": "Yucheng Xu",
        },
    )

    with writer.saving(
        figure,
        str(output),
        dpi=dpi,
    ):
        for _ in range(cycles):
            for index, phase in enumerate(
                phase_values
            ):
                field = interpolated_field(
                    points,
                    values_by_phase[index],
                    width,
                    height,
                    method=method,
                )
                overlay.set_data(field)
                phase_text.set_text(
                    f"Respiratory phase: {phase * 100:4.0f}%"
                )
                writer.grab_frame(
                    facecolor="white"
                )

    plt.close(figure)

    return output


def save_outputs(
    processed: list[ProcessedPosition],
    positions: pd.DataFrame,
    output_dir: Path,
    settings: dict[str, object],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    position_lookup = positions.set_index(
        "position"
    )

    metrics_rows: list[
        dict[str, object]
    ] = []
    phase_rows: list[
        dict[str, object]
    ] = []

    signal_dir = (
        output_dir / "processed_signals"
    )
    signal_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    for result in processed:
        x_norm = float(
            position_lookup.loc[
                result.position,
                "x_norm",
            ]
        )
        y_norm = float(
            position_lookup.loc[
                result.position,
                "y_norm",
            ]
        )

        metrics_rows.append(
            {
                "position": result.position,
                "x_norm": x_norm,
                "y_norm": y_norm,
                **result.metrics,
            }
        )

        for phase, value in zip(
            result.phase,
            result.phase_profile_mg,
        ):
            phase_rows.append(
                {
                    "position": result.position,
                    "x_norm": x_norm,
                    "y_norm": y_norm,
                    "phase": phase,
                    "value_mg": value,
                }
            )

        trim = int(
            result.metrics[
                "trimmed_edge_samples_each_side"
            ]
        )

        analysis_window = np.ones(
            len(result.uniform_time_s),
            dtype=bool,
        )

        if trim:
            analysis_window[:trim] = False
            analysis_window[-trim:] = False

        selected_full = (
            result.pca_scores_mg[
                :,
                result.selected_component_index,
            ]
        )

        pd.DataFrame(
            {
                "time_s": result.uniform_time_s,
                "raw_acc_x_mg": (
                    result.raw_acceleration_mg[:, 0]
                ),
                "raw_acc_y_mg": (
                    result.raw_acceleration_mg[:, 1]
                ),
                "raw_acc_z_mg": (
                    result.raw_acceleration_mg[:, 2]
                ),
                "filtered_acc_x_mg": (
                    result.filtered_acceleration_mg[:, 0]
                ),
                "filtered_acc_y_mg": (
                    result.filtered_acceleration_mg[:, 1]
                ),
                "filtered_acc_z_mg": (
                    result.filtered_acceleration_mg[:, 2]
                ),
                "PC1_mg": (
                    result.pca_scores_mg[:, 0]
                ),
                "PC2_mg": (
                    result.pca_scores_mg[:, 1]
                ),
                "PC3_mg": (
                    result.pca_scores_mg[:, 2]
                ),
                "selected_pca_signal_mg": (
                    selected_full
                ),
                "included_in_metric_analysis": (
                    analysis_window
                ),
            }
        ).to_csv(
            signal_dir
            / f"{result.position}_complete_processed_signal.csv",
            index=False,
        )

    metrics = pd.DataFrame(
        metrics_rows
    )
    phase_profiles = pd.DataFrame(
        phase_rows
    )

    metrics.to_csv(
        output_dir
        / "P1_P9_processing_summary.csv",
        index=False,
    )

    metrics[
        [
            "position",
            "x_norm",
            "y_norm",
            "estimated_rr_bpm",
            "absolute_rr_difference_from_setting_bpm",
            "amplitude_p2p_mg",
            "selected_component_spectral_snr_db",
            "quality_flag",
        ]
    ].to_csv(
        output_dir
        / "P1_P9_position_metrics.csv",
        index=False,
    )

    phase_profiles.to_csv(
        output_dir
        / "P1_P9_phase_profiles.csv",
        index=False,
    )

    with (
        output_dir / "analysis_settings.json"
    ).open(
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(
            settings,
            handle,
            indent=2,
            ensure_ascii=False,
        )

    return metrics, phase_profiles


def save_results_index(
    output_dir: Path,
    condition: str,
) -> Path:
    """Write a Chinese index alongside each result set."""
    output = (
        output_dir / "RESULTS_INDEX_CN.txt"
    )

    content = f"""Baby Paul 九点 IMU 完整分析结果：{condition}

1. colour_maps
   01：P1-P9 呼吸振幅 colour map
   02：估计呼吸率 colour map
   03：相对 Baby Paul 设定值的绝对 RR 误差 colour map
   04：呼吸频段频谱 SNR colour map

2. comparison_figures
   05：振幅、估计 RR、RR 误差与 SNR 的九点汇总
   06：P1-P9 选定 PCA 呼吸波形对比
   07：P1-P9 呼吸频段功率谱 PSD
   08：P1-P9 相位标准化代表性呼吸周期
   09：选定 PCA 分量的三轴载荷与解释方差
   10：采样率、记录时长、时间间隔变化及质量标记

3. position_diagnostics
   P1-P9 各一张六面板诊断图：原始三轴、滤波三轴、PC1-PC3、
   选定呼吸信号、PSD 与代表性呼吸周期。

4. IMU_phase_normalised_composite_map.mp4
   九份顺序记录按呼吸相位对齐后生成的动态合成图；不表示九点同时测量。

5. CSV 与 processed_signals
   P1_P9_position_metrics.csv：主要位置指标。
   P1_P9_processing_summary.csv：完整处理与质量信息。
   P1_P9_phase_profiles.csv：相位波形数值。
   processed_signals：各点原始三轴、滤波三轴、PC1-PC3 和选定信号。

使用顺序：先看 10_data_quality_summary 和 processing_summary；确认质量后，
再比较 05_key_metrics、四张 colour map、波形与 PSD。若 P1-P9 并非在九个
真实位置分别采集，colour map 只能用于程序测试，不能解释为空间分布。
"""

    output.write_text(
        content,
        encoding="utf-8",
    )

    return output


def pick_positions(
    args: argparse.Namespace,
) -> None:
    background_path = resolve_existing(
        args.background
    )
    output_path = resolve_output(
        args.output
    )

    if not background_path.exists():
        raise FileNotFoundError(
            f"Background image not found: {background_path}"
        )

    background = np.asarray(
        Image.open(
            background_path
        ).convert("RGB")
    )

    figure, axes = plt.subplots(
        figsize=(12, 7)
    )
    axes.imshow(background)
    axes.set_title(
        "Click P1 to P9 in order; "
        "the window closes after the ninth click"
    )
    axes.set_axis_off()

    clicked = plt.ginput(
        9,
        timeout=0,
    )
    plt.close(figure)

    if len(clicked) != 9:
        raise RuntimeError(
            f"Expected 9 clicks, received {len(clicked)}."
        )

    height, width = background.shape[:2]

    positions = pd.DataFrame(
        {
            "position": POSITIONS,
            "x_norm": [
                x / (width - 1)
                for x, _ in clicked
            ],
            "y_norm": [
                y / (height - 1)
                for _, y in clicked
            ],
        }
    )

    output_path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    positions.to_csv(
        output_path,
        index=False,
    )

    print(
        f"Created: {output_path}"
    )


def run_analysis(
    args: argparse.Namespace,
) -> None:
    input_dir = resolve_existing(
        args.input_dir
    )
    positions_path = resolve_existing(
        args.positions
    )
    background_path = resolve_existing(
        args.background
    )

    if not positions_path.exists():
        raise FileNotFoundError(
            f"Position file not found: {positions_path}"
        )

    if not background_path.exists():
        raise FileNotFoundError(
            f"Background image not found: {background_path}"
        )

    if args.expected_rr_bpm <= 0:
        raise ValueError(
            "--expected-rr-bpm must be positive."
        )

    if args.phase_bins < 24:
        raise ValueError(
            "--phase-bins must be at least 24."
        )

    condition = (
        args.condition
        or f"RR{args.expected_rr_bpm:g}"
    )

    output_root = resolve_output(
        args.output_dir
    )
    output_dir = (
        output_root / condition
    )

    files = discover_position_files(
        input_dir
    )
    positions = load_positions(
        positions_path
    )

    background = np.asarray(
        Image.open(
            background_path
        ).convert("RGB")
    )

    print(
        "Nine IMU files found:"
    )
    for position, path in files.items():
        print(
            f"  {position}: {path.name}"
        )

    processed: list[
        ProcessedPosition
    ] = []

    for position, path in files.items():
        print(
            f"Processing {position} ..."
        )

        processed.append(
            process_position(
                position=position,
                path=path,
                expected_rr_bpm=(
                    args.expected_rr_bpm
                ),
                low_hz=args.low_hz,
                high_hz=args.high_hz,
                phase_bins=args.phase_bins,
            )
        )

    settings: dict[str, object] = {
        "program_output_version": "complete-analysis-v2",
        "condition": condition,
        "expected_rr_bpm": args.expected_rr_bpm,
        "bandpass_low_hz": args.low_hz,
        "bandpass_high_hz": args.high_hz,
        "phase_bins": args.phase_bins,
        "static_interpolation": "linear",
        "video_interpolation": args.video_method,
        "video_cycles": args.cycles,
        "video_fps": args.fps,
        "background_file": background_path.name,
        "positions_file": positions_path.name,
        "input_files": {
            position: path.name
            for position, path in files.items()
        },
    }

    metrics, phase_profiles = save_outputs(
        processed,
        positions,
        output_dir,
        settings,
    )

    print(
        "Creating four colour maps, comparison figures, "
        "and P1-P9 diagnostics ..."
    )

    static_paths = (
        create_complete_static_outputs(
            background=background,
            positions=positions,
            metrics=metrics,
            processed=processed,
            output_dir=output_dir,
            condition=condition,
            expected_rr_bpm=(
                args.expected_rr_bpm
            ),
            low_hz=args.low_hz,
            high_hz=args.high_hz,
            alpha=args.alpha,
        )
    )

    index_path = save_results_index(
        output_dir,
        condition,
    )

    print(
        "Creating phase-normalised composite MP4 ..."
    )

    video_path = create_animation(
        background=background,
        positions=positions,
        phase_profiles=phase_profiles,
        output=(
            output_dir
            / "IMU_phase_normalised_composite_map.mp4"
        ),
        condition=condition,
        alpha=args.alpha,
        method=args.video_method,
        cycles=args.cycles,
        fps=args.fps,
        dpi=args.video_dpi,
    )

    display = metrics[
        [
            "position",
            "selected_component",
            "sampling_rate_hz",
            "estimated_rr_bpm",
            "amplitude_p2p_mg",
            "quality_flag",
        ]
    ].copy()

    print(
        "\nProcessing summary:"
    )
    print(
        display.to_string(
            index=False,
            float_format=(
                lambda value: f"{value:.3f}"
            ),
        )
    )

    print(
        "\nCreated final results:"
    )
    print(
        f"  {len(static_paths)} static PNG figures"
    )
    print(
        f"  {output_dir / 'colour_maps'}"
    )
    print(
        f"  {output_dir / 'comparison_figures'}"
    )
    print(
        f"  {output_dir / 'position_diagnostics'}"
    )
    print(
        f"  {video_path}"
    )
    print(
        f"  {output_dir / 'P1_P9_position_metrics.csv'}"
    )
    print(
        f"  {output_dir / 'P1_P9_processing_summary.csv'}"
    )
    print(
        f"  {output_dir / 'P1_P9_phase_profiles.csv'}"
    )
    print(
        f"  {index_path}"
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=__doc__
    )
    subparsers = parser.add_subparsers(
        dest="command",
        required=True,
    )

    run = subparsers.add_parser(
        "run",
        help=(
            "Process nine P1-P9 IMU recordings "
            "and create results."
        ),
    )

    run.add_argument(
        "--input-dir",
        default="imu_data",
        help=(
            "Folder containing exactly one P1-P9 file each."
        ),
    )
    run.add_argument(
        "--positions",
        default="positions_new.csv",
        help=(
            "P1-P9 coordinates on the background image."
        ),
    )
    run.add_argument(
        "--background",
        default="baby_paul_new.jpg",
        help=(
            "Background image for the maps."
        ),
    )
    run.add_argument(
        "--output-dir",
        default="results",
        help=(
            "Root folder for generated results."
        ),
    )
    run.add_argument(
        "--expected-rr-bpm",
        type=float,
        required=True,
        help=(
            "Respiratory rate set on Baby Paul, "
            "in breaths/min; used to select the "
            "PCA component."
        ),
    )
    run.add_argument(
        "--condition",
        help=(
            "Result label, for example RR20. "
            "Defaults to the configured RR."
        ),
    )
    run.add_argument(
        "--low-hz",
        type=float,
        default=0.1,
        help=(
            "Lower band-pass cutoff in Hz."
        ),
    )
    run.add_argument(
        "--high-hz",
        type=float,
        default=1.5,
        help=(
            "Upper band-pass cutoff in Hz."
        ),
    )
    run.add_argument(
        "--phase-bins",
        type=int,
        default=72,
    )
    run.add_argument(
        "--video-method",
        choices=[
            "linear",
            "cubic",
        ],
        default="cubic",
    )
    run.add_argument(
        "--alpha",
        type=float,
        default=0.66,
        help=(
            "Colour overlay opacity from 0 to 1."
        ),
    )
    run.add_argument(
        "--cycles",
        type=int,
        default=7,
    )
    run.add_argument(
        "--fps",
        type=int,
        default=24,
    )
    run.add_argument(
        "--video-dpi",
        type=int,
        default=120,
    )
    run.set_defaults(
        function=run_analysis
    )

    picker = subparsers.add_parser(
        "pick",
        help=(
            "Click P1-P9 on a replacement background "
            "and save new coordinates."
        ),
    )
    picker.add_argument(
        "--background",
        default="baby_paul_new.jpg",
    )
    picker.add_argument(
        "--output",
        default="positions_new.csv",
    )
    picker.set_defaults(
        function=pick_positions
    )

    return parser


def main() -> None:
    args = build_parser().parse_args()
    args.function(args)


if __name__ == "__main__":
    main()