%% USER SETTINGS

scriptFolder = fileparts(mfilename('fullpath'));
if isempty(scriptFolder)
    scriptFolder = pwd;
end

% These are the three paired recordings identified in the experiment notes.
trials = table( ...
    ["RR20"; "RR35"; "RR50"], ...
    [20; 35; 50], ...
    ["20260805_003820"; "20260805_004005"; "20260805_004147"], ...
    'VariableNames', {'Name', 'ExpectedRR_bpm', 'FileStem'});

% Leave this empty to search Data, the script folder and ../Data.
cfg.dataFolder = "";

cfg.outputFolder = fullfile( ...
    scriptFolder, "Results", "IMU_Graseby_Comparison_20260805_v5_trimmed");

cfg.respiratoryBand_Hz = [0.10 1.50];
cfg.filterOrder = 4;
cfg.spectrumMinimumNFFT = 4096;
cfg.minimumPCExplainedVariance_percent = 5;
cfg.spectralPeakHalfWidth_Hz = 0.08;

% The best-lag result is descriptive. The allowed lag is also limited to
% 45% of the expected breathing period so that the search cannot jump by a
% complete respiratory cycle.
cfg.maximumLag_s = 1.5;

% 对所有 RR 条件使用同一裁剪规则；设为 0 和 0 可分析完整共同区间。
cfg.trimStart_s = 10;
cfg.trimEnd_s = 10;

cfg.minimumOverlap_s = 10;
cfg.recommendedMinimumBreathingCycles = 3;
cfg.showFigures = true;
cfg.saveMATLABFigureFiles = false;
cfg.figureResolution_dpi = 300;

%% INITIAL CHECKS

assertRequiredFunctionsAreAvailable();

if strlength(cfg.dataFolder) == 0
    cfg.dataFolder = findDataFolder(scriptFolder, trials.FileStem(1));
end

if strlength(cfg.dataFolder) == 0 || ~isfolder(cfg.dataFolder)
    error( ...
        "The Data folder was not found. Set cfg.dataFolder to the folder " + ...
        "that contains the paired *_imu.csv and *_graseby.csv files.");
end

if ~exist(cfg.outputFolder, 'dir')
    mkdir(cfg.outputFolder);
end

fprintf("\nData folder:\n%s\n", char(cfg.dataFolder));
fprintf("\nOutput folder:\n%s\n", char(cfg.outputFolder));

%% PROCESS RR20, RR35 AND RR50

trialResults = cell(height(trials), 1);
summaryTables = cell(height(trials), 1);

for trialIndex = 1:height(trials)
    fprintf("\n====================================================\n");
    fprintf("Processing %s\n", char(trials.Name(trialIndex)));
    fprintf("====================================================\n");

    trialResults{trialIndex} = analyseOneTrial( ...
        trials(trialIndex, :), cfg);
    summaryTables{trialIndex} = trialResults{trialIndex}.Summary;
end

combinedSummary = vertcat(summaryTables{:});

writetable( ...
    combinedSummary, ...
    fullfile(cfg.outputFolder, "RR20_RR35_RR50_Combined_Summary.csv"));

createCombinedSummaryFigure(combinedSummary, cfg);

fprintf("\nAll analyses completed successfully.\n");
fprintf("Combined results were saved in:\n%s\n", char(cfg.outputFolder));

%% LOCAL FUNCTIONS

function result = analyseOneTrial(trial, cfg)

    trialName = string(trial.Name);
    expectedRR_bpm = trial.ExpectedRR_bpm;
    fileStem = string(trial.FileStem);
    expectedFrequency_Hz = expectedRR_bpm / 60;
    expectedPeriod_s = 60 / expectedRR_bpm;

    imuFile = fullfile(cfg.dataFolder, fileStem + "_imu.csv");
    grasebyFile = fullfile( ...
        cfg.dataFolder, fileStem + "_graseby.csv");

    if ~isfile(imuFile)
        error("IMU file was not found: %s", char(imuFile));
    end

    if ~isfile(grasebyFile)
        error("Graseby file was not found: %s", char(grasebyFile));
    end

    trialOutputFolder = fullfile(cfg.outputFolder, trialName);
    if ~exist(trialOutputFolder, 'dir')
        mkdir(trialOutputFolder);
    end

    imu = loadNewIMUCSV(imuFile);
    graseby = loadNewGrasebyCSV(grasebyFile);

    % Filter the Graseby signal before reducing it from about 1000 Hz to
    % the common IMU-rate grid. This reduces high-frequency aliasing.
    graseby.FilteredNative = preprocessRespiratoryChannel( ...
        graseby.Voltage_V, ...
        graseby.Fs_Hz, ...
        cfg.respiratoryBand_Hz, ...
        cfg.filterOrder);

    common = buildUniformOverlap(imu, graseby, cfg);

    %% IMU filtering and PCA

    accFiltered = zeros(size(common.Acceleration_mg));
    for channel = 1:3
        accFiltered(:, channel) = preprocessRespiratoryChannel( ...
            common.Acceleration_mg(:, channel), ...
            common.Fs_Hz, ...
            cfg.respiratoryBand_Hz, ...
            cfg.filterOrder);
    end

    %% 统一裁剪分析区间：完整滤波后、标准化和 PCA 前
    validateattributes(cfg.trimStart_s, {'numeric'}, ...
        {'scalar', 'real', 'finite', 'nonnegative'});
    validateattributes(cfg.trimEnd_s, {'numeric'}, ...
        {'scalar', 'real', 'finite', 'nonnegative'});

    originalTime_s = common.RelativeTime_s(:);
    keep = originalTime_s >= cfg.trimStart_s & ...
        originalTime_s <= originalTime_s(end) - cfg.trimEnd_s;

    if nnz(keep) < 4
        error('%s: too few samples remain after edge trimming.', ...
            char(trialName));
    end

    retainedOriginalTime_s = originalTime_s(keep);
    retainedDuration_s = ...
        retainedOriginalTime_s(end) - retainedOriginalTime_s(1);
    if retainedDuration_s < cfg.minimumOverlap_s
        error([ ...
            '%s: only %.3f s remain after trimming. ' ...
            'At least %.3f s are required. Reduce trimming or use a longer recording.'], ...
            char(trialName), retainedDuration_s, cfg.minimumOverlap_s);
    end

    % 保留完整共同区间和实际裁剪时长，便于区分原始记录与分析窗口。
    common.OriginalOverlapStartUTC = common.TimestampUTC(1);
    common.OriginalOverlapEndUTC = common.TimestampUTC(end);
    common.OriginalOverlapDuration_s = common.Duration_s;
    common.OriginalSampleCount = numel(originalTime_s);
    common.OriginalOverlapTime_s = retainedOriginalTime_s;
    common.ActualTrimStart_s = retainedOriginalTime_s(1);
    common.ActualTrimEnd_s = originalTime_s(end) - retainedOriginalTime_s(end);

    accFiltered = accFiltered(keep, :);
    common.Acceleration_mg = common.Acceleration_mg(keep, :);
    common.GrasebyRaw_V = common.GrasebyRaw_V(keep);
    common.GrasebyFiltered = common.GrasebyFiltered(keep);
    common.TimestampUTC = common.TimestampUTC(keep);
    common.Posix_s = common.Posix_s(keep);
    common.RelativeTime_s = retainedOriginalTime_s - retainedOriginalTime_s(1);
    common.Duration_s = retainedDuration_s;

    recommendedDuration_s = max( ...
        cfg.minimumOverlap_s, ...
        cfg.recommendedMinimumBreathingCycles * expectedPeriod_s);
    if common.Duration_s < recommendedDuration_s
        warning([ ...
            '%s has %.2f s in the retained analysis interval. ' ...
            'At least %.2f s is recommended.'], ...
            char(trialName), common.Duration_s, recommendedDuration_s);
    end

    channelMean = mean(accFiltered, 1, 'omitnan');
    channelStd = std(accFiltered, 0, 1, 'omitnan');

    if any(~isfinite(channelStd) | channelStd == 0)
        error("%s contains a constant processed acceleration axis.", ...
            char(trialName));
    end

    standardisedAcceleration = ...
        (accFiltered - channelMean) ./ channelStd;

    [pcCoefficients, pcScores, ~, ~, explainedVariance] = ...
        pca(standardisedAcceleration, 'Rows', 'complete');

    nPC = min(3, size(pcScores, 2));
    pcScores = pcScores(:, 1:nPC);

    pcDominantFrequency_Hz = nan(nPC, 1);
    pcEstimatedRR_bpm = nan(nPC, 1);
    pcRRError_bpm = nan(nPC, 1);
    pcSpectralSNR_dB = nan(nPC, 1);

    for pcIndex = 1:nPC
        [frequencyAxis_Hz, amplitude, dominantFrequency_Hz] = ...
            calculateWindowedSpectrum( ...
            pcScores(:, pcIndex), ...
            common.Fs_Hz, ...
            cfg.respiratoryBand_Hz, ...
            cfg.spectrumMinimumNFFT);

        if pcIndex == 1
            pcSpectrumFrequency_Hz = frequencyAxis_Hz;
            pcSpectrumAmplitude = ...
                nan(numel(frequencyAxis_Hz), nPC);
            pcSpectrumNormalised = ...
                nan(numel(frequencyAxis_Hz), nPC);
        end

        pcSpectrumAmplitude(:, pcIndex) = amplitude;
        pcSpectrumNormalised(:, pcIndex) = normaliseSpectrumInBand( ...
            frequencyAxis_Hz, amplitude, cfg.respiratoryBand_Hz);

        pcDominantFrequency_Hz(pcIndex) = dominantFrequency_Hz;
        pcEstimatedRR_bpm(pcIndex) = dominantFrequency_Hz * 60;
        pcRRError_bpm(pcIndex) = abs( ...
            pcEstimatedRR_bpm(pcIndex) - expectedRR_bpm);
        pcSpectralSNR_dB(pcIndex) = calculateSpectralSNR( ...
            frequencyAxis_Hz, ...
            amplitude, ...
            dominantFrequency_Hz, ...
            cfg.respiratoryBand_Hz, ...
            cfg.spectralPeakHalfWidth_Hz);
    end

    % Select the respiratory PC by spectral concentration, independently of expected RR.
    eligiblePC = ...
        isfinite(pcSpectralSNR_dB) & ...
        explainedVariance(1:nPC) >= ...
        cfg.minimumPCExplainedVariance_percent;

    if ~any(eligiblePC)
        warning([ ...
            '%s: no PC met the explained-variance threshold. ' ...
            'The finite PC with the highest respiratory-band SNR is used.'], ...
            char(trialName));
        eligiblePC = isfinite(pcSpectralSNR_dB);
    end

    if ~any(eligiblePC)
        error("%s: no valid PCA respiratory component was found.", ...
            char(trialName));
    end

    eligiblePCNumbers = find(eligiblePC);
    [~, localBestPC] = max(pcSpectralSNR_dB(eligiblePCNumbers));
    selectedPC = eligiblePCNumbers(localBestPC);

    selectedIMUSignal = pcScores(:, selectedPC);
    selectedIMUNormalised = normaliseSignal(selectedIMUSignal);
    selectedIMURR_bpm = pcEstimatedRR_bpm(selectedPC);
    selectedIMURRError_bpm = pcRRError_bpm(selectedPC);
    selectedIMUSNR_dB = pcSpectralSNR_dB(selectedPC);

    %% Graseby frequency analysis

    grasebyNormalised = normaliseSignal(common.GrasebyFiltered);

    [grasebySpectrumFrequency_Hz, ...
        grasebySpectrumAmplitude, ...
        grasebyDominantFrequency_Hz] = calculateWindowedSpectrum( ...
        common.GrasebyFiltered, ...
        common.Fs_Hz, ...
        cfg.respiratoryBand_Hz, ...
        cfg.spectrumMinimumNFFT);

    grasebySpectrumNormalised = normaliseSpectrumInBand( ...
        grasebySpectrumFrequency_Hz, ...
        grasebySpectrumAmplitude, ...
        cfg.respiratoryBand_Hz);

    grasebyRR_bpm = grasebyDominantFrequency_Hz * 60;
    grasebyRRError_bpm = abs(grasebyRR_bpm - expectedRR_bpm);
    grasebySNR_dB = calculateSpectralSNR( ...
        grasebySpectrumFrequency_Hz, ...
        grasebySpectrumAmplitude, ...
        grasebyDominantFrequency_Hz, ...
        cfg.respiratoryBand_Hz, ...
        cfg.spectralPeakHalfWidth_Hz);

    imuGrasebyRRDifference_bpm = abs( ...
        selectedIMURR_bpm - grasebyRR_bpm);

    %% Timestamp and waveform agreement

    zeroLagCorrelationSigned = calculateCorrelation( ...
        selectedIMUNormalised, grasebyNormalised);

    allowedLag_s = min( ...
        cfg.maximumLag_s, 0.45 * expectedPeriod_s);

    lagResult = findBestLagAndSign( ...
        selectedIMUNormalised, ...
        grasebyNormalised, ...
        common.Fs_Hz, ...
        allowedLag_s);

    [lagAdjustedCorrelation, ...
        lagAdjustedMAE, ...
        lagAdjustedRMSE] = calculateNormalisedMetrics( ...
        lagResult.IMUAligned, lagResult.GrasebyAligned);

    zeroLagCorrelationAfterSignCorrection = ...
        lagResult.IMUSignFactor * zeroLagCorrelationSigned;

    %% Quality reporting

    fprintf("IMU file:      %s\n", char(imuFile));
    fprintf("Graseby file:  %s\n", char(grasebyFile));
    fprintf("IMU Fs:        %.6f Hz\n", imu.Fs_Hz);
    fprintf("Graseby Fs:    %.6f Hz\n", graseby.Fs_Hz);
    fprintf("Common Fs:     %.6f Hz\n", common.Fs_Hz);
    fprintf("Full UTC overlap: %.3f s\n", common.OriginalOverlapDuration_s);
    fprintf("Requested trim: start %.3f s, end %.3f s\n", ...
        cfg.trimStart_s, cfg.trimEnd_s);
    fprintf("Actual trim:    start %.3f s, end %.3f s\n", ...
        common.ActualTrimStart_s, common.ActualTrimEnd_s);
    fprintf("Retained analysis interval: %.3f s (%d samples)\n", ...
        common.Duration_s, numel(common.RelativeTime_s));
    fprintf("IMU time_us wraps detected: %d\n", imu.TimeCounterWrapCount);
    fprintf("Selected IMU component: PC%d (%.2f%% variance)\n", ...
        selectedPC, explainedVariance(selectedPC));
    fprintf("IMU RR:        %.3f breaths/min\n", selectedIMURR_bpm);
    fprintf("Graseby RR:    %.3f breaths/min\n", grasebyRR_bpm);
    fprintf("Expected RR:   %.3f breaths/min\n", expectedRR_bpm);
    fprintf("UTC correlation before PC polarity correction: %.4f\n", ...
        zeroLagCorrelationSigned);
    fprintf("UTC correlation after PC polarity correction: %.4f\n", ...
        zeroLagCorrelationAfterSignCorrection);
    fprintf("IMU PC polarity factor: %+d\n", lagResult.IMUSignFactor);
    fprintf("Best waveform lag: %.4f s\n", lagResult.Lag_s);
    fprintf("Lag-adjusted normalised correlation: %.4f\n", ...
        lagAdjustedCorrelation);

    interpretationNote = ...
        "The two files were aligned using their UTC timestamp overlap. " + ...
        "The configured leading and trailing intervals were removed jointly " + ...
        "after filtering and before standardisation, PCA and spectral analysis. " + ...
        "The IMU time_us counter was unwrapped and used to suppress serial " + ...
        "timestamp jitter. The reported best waveform lag can include both " + ...
        "logger delay and physiological/sensor phase difference; it is not " + ...
        "interpreted as pure clock error. PCA polarity was set using the " + ...
        "best-lag result; the zero-lag plot reports the correlation of the " + ...
        "curves actually displayed. The original signed zero-lag correlation " + ...
        "is retained separately in the summary.";

    summaryStruct = struct;
    summaryStruct.Trial = trialName;
    summaryStruct.ExpectedRespiratoryRate_bpm = expectedRR_bpm;
    summaryStruct.ExpectedFrequency_Hz = expectedFrequency_Hz;
    summaryStruct.FileStem = fileStem;
    summaryStruct.IMUFile = string(imuFile);
    summaryStruct.GrasebyFile = string(grasebyFile);
    summaryStruct.IMURawSampleCount = imu.SampleCount;
    summaryStruct.GrasebyRawSampleCount = graseby.SampleCount;
    summaryStruct.IMUSamplingFrequency_Hz = imu.Fs_Hz;
    summaryStruct.GrasebySamplingFrequency_Hz = graseby.Fs_Hz;
    summaryStruct.CommonSamplingFrequency_Hz = common.Fs_Hz;
    summaryStruct.OverlapStartUTC = formatUTC(common.OriginalOverlapStartUTC);
    summaryStruct.OverlapEndUTC = formatUTC(common.OriginalOverlapEndUTC);
    summaryStruct.OverlapDuration_s = common.OriginalOverlapDuration_s;
    summaryStruct.CommonSampleCount = common.OriginalSampleCount;
    summaryStruct.RequestedTrimStart_s = cfg.trimStart_s;
    summaryStruct.RequestedTrimEnd_s = cfg.trimEnd_s;
    summaryStruct.ActualTrimStart_s = common.ActualTrimStart_s;
    summaryStruct.ActualTrimEnd_s = common.ActualTrimEnd_s;
    summaryStruct.AnalysisStartUTC = formatUTC(common.TimestampUTC(1));
    summaryStruct.AnalysisEndUTC = formatUTC(common.TimestampUTC(end));
    summaryStruct.AnalysisDuration_s = common.Duration_s;
    summaryStruct.AnalysisSampleCount = numel(common.RelativeTime_s);
    summaryStruct.IMUTimeCounterWrapCount = imu.TimeCounterWrapCount;
    summaryStruct.IMULoggerTimestampJitterRMS_ms = ...
        imu.LoggerTimestampJitterRMS_ms;
    summaryStruct.IMUMedianDeviceInterval_us = imu.MedianDeviceInterval_us;
    summaryStruct.IMUFinalNotReadyCount = imu.FinalNotReadyCount;
    summaryStruct.IMUFinalOverrunCount = imu.FinalOverrunCount;
    summaryStruct.GrasebyUniqueVoltageLevels = ...
        graseby.UniqueVoltageLevels;
    summaryStruct.SelectedIMUPC = selectedPC;
    summaryStruct.SelectedIMUPCExplainedVariance_percent = ...
        explainedVariance(selectedPC);
    summaryStruct.SelectedIMUPCSpectralSNR_dB = selectedIMUSNR_dB;
    summaryStruct.IMUDominantFrequency_Hz = ...
        pcDominantFrequency_Hz(selectedPC);
    summaryStruct.IMUEstimatedRespiratoryRate_bpm = selectedIMURR_bpm;
    summaryStruct.IMUAbsoluteRespiratoryRateError_bpm = ...
        selectedIMURRError_bpm;
    summaryStruct.GrasebySpectralSNR_dB = grasebySNR_dB;
    summaryStruct.GrasebyDominantFrequency_Hz = ...
        grasebyDominantFrequency_Hz;
    summaryStruct.GrasebyEstimatedRespiratoryRate_bpm = grasebyRR_bpm;
    summaryStruct.GrasebyAbsoluteRespiratoryRateError_bpm = ...
        grasebyRRError_bpm;
    summaryStruct.AbsoluteIMUGrasebyRRDifference_bpm = ...
        imuGrasebyRRDifference_bpm;
    summaryStruct.ZeroLagCorrelationSigned = zeroLagCorrelationSigned;
    summaryStruct.ZeroLagCorrelationAfterPCSignCorrection = ...
        zeroLagCorrelationAfterSignCorrection;
    summaryStruct.AllowedLagSearch_s = allowedLag_s;
    summaryStruct.GrasebyLagRelativeToIMU_s = lagResult.Lag_s;
    summaryStruct.IMUPCSignWasFlipped = lagResult.IMUSignFactor < 0;
    summaryStruct.LagAdjustedCorrelation_Normalised = ...
        lagAdjustedCorrelation;
    summaryStruct.LagAdjustedMAE_Normalised = lagAdjustedMAE;
    summaryStruct.LagAdjustedRMSE_Normalised = lagAdjustedRMSE;
    summaryStruct.TimestampOverlapValid = true;
    summaryStruct.InterpretationNote = interpretationNote;

    summaryTable = struct2table(summaryStruct, 'AsArray', true);

    pcCandidateTable = table( ...
        (1:nPC)', ...
        explainedVariance(1:nPC), ...
        pcCoefficients(1, 1:nPC)', ...
        pcCoefficients(2, 1:nPC)', ...
        pcCoefficients(3, 1:nPC)', ...
        pcDominantFrequency_Hz, ...
        pcEstimatedRR_bpm, ...
        pcRRError_bpm, ...
        pcSpectralSNR_dB, ...
        (1:nPC)' == selectedPC, ...
        'VariableNames', { ...
        'PC', ...
        'ExplainedVariance_percent', ...
        'LoadingX', ...
        'LoadingY', ...
        'LoadingZ', ...
        'DominantFrequency_Hz', ...
        'EstimatedRespiratoryRate_bpm', ...
        'AbsoluteRespiratoryRateError_bpm', ...
        'RespiratoryBandSpectralSNR_dB', ...
        'SelectedForRespiratoryAnalysis'});

    synchronizedTable = table( ...
        common.TimestampUTC, ...
        common.RelativeTime_s, ...
        common.OriginalOverlapTime_s, ...
        common.Acceleration_mg(:, 1), ...
        common.Acceleration_mg(:, 2), ...
        common.Acceleration_mg(:, 3), ...
        accFiltered(:, 1), ...
        accFiltered(:, 2), ...
        accFiltered(:, 3), ...
        selectedIMUSignal, ...
        selectedIMUNormalised, ...
        common.GrasebyRaw_V, ...
        common.GrasebyFiltered, ...
        grasebyNormalised, ...
        'VariableNames', { ...
        'TimestampUTC', ...
        'RelativeTime_s', ...
        'TimeFromOriginalOverlapStart_s', ...
        'RawAccX_mg', ...
        'RawAccY_mg', ...
        'RawAccZ_mg', ...
        'FilteredAccX_mg', ...
        'FilteredAccY_mg', ...
        'FilteredAccZ_mg', ...
        'SelectedIMUPC', ...
        'SelectedIMUPC_Normalised', ...
        'GrasebyRaw_V', ...
        'GrasebyFiltered_V', ...
        'GrasebyFiltered_Normalised'});

    lagAdjustedPairTable = table( ...
        common.TimestampUTC(lagResult.IMUIndices), ...
        common.TimestampUTC(lagResult.GrasebyIndices), ...
        (0:numel(lagResult.IMUAligned)-1)' / common.Fs_Hz, ...
        lagResult.IMUAligned, ...
        lagResult.GrasebyAligned, ...
        lagResult.IMUAligned - lagResult.GrasebyAligned, ...
        'VariableNames', { ...
        'IMUTimestampUTC', ...
        'GrasebyTimestampUTC', ...
        'PairRelativeTime_s', ...
        'IMUPC_SignCorrected_Normalised', ...
        'Graseby_Normalised', ...
        'NormalisedDifference'});

    spectrumTable = table( ...
        pcSpectrumFrequency_Hz, ...
        grasebySpectrumAmplitude, ...
        grasebySpectrumNormalised, ...
        'VariableNames', { ...
        'Frequency_Hz', ...
        'GrasebyAmplitude', ...
        'GrasebyAmplitudeNormalisedInRespiratoryBand'});

    for pcIndex = 1:nPC
        spectrumTable.(sprintf('PC%d_Amplitude', pcIndex)) = ...
            pcSpectrumAmplitude(:, pcIndex);
        spectrumTable.(sprintf( ...
            'PC%d_AmplitudeNormalisedInRespiratoryBand', pcIndex)) = ...
            pcSpectrumNormalised(:, pcIndex);
    end

    filePrefix = trialName + "_" + fileStem;

    writetable(summaryTable, fullfile( ...
        trialOutputFolder, filePrefix + "_Summary.csv"));
    writetable(pcCandidateTable, fullfile( ...
        trialOutputFolder, filePrefix + "_IMU_PC_Candidates.csv"));
    writetable(synchronizedTable, fullfile( ...
        trialOutputFolder, filePrefix + "_Synchronized_Timeseries.csv"));
    writetable(lagAdjustedPairTable, fullfile( ...
        trialOutputFolder, filePrefix + "_Lag_Adjusted_Pairs.csv"));
    writetable(spectrumTable, fullfile( ...
        trialOutputFolder, filePrefix + "_Spectra.csv"));

    createTrialFigure( ...
        trialName, ...
        expectedRR_bpm, ...
        common, ...
        accFiltered, ...
        selectedPC, ...
        selectedIMUNormalised, ...
        grasebyNormalised, ...
        pcSpectrumFrequency_Hz, ...
        pcSpectrumNormalised(:, selectedPC), ...
        grasebySpectrumNormalised, ...
        selectedIMURR_bpm, ...
        grasebyRR_bpm, ...
        selectedIMUSNR_dB, ...
        grasebySNR_dB, ...
        zeroLagCorrelationSigned, ...
        lagResult, ...
        lagAdjustedCorrelation, ...
        lagAdjustedRMSE, ...
        cfg, ...
        fullfile(trialOutputFolder, ...
        filePrefix + "_IMU_Graseby_Comparison"));

    result = struct;
    result.Summary = summaryTable;
    result.PCCandidates = pcCandidateTable;
    result.SynchronizedTimeseries = synchronizedTable;
    result.LagAdjustedPairs = lagAdjustedPairTable;
end

function imu = loadNewIMUCSV(fileName)

    inputTable = readtable( ...
        fileName, ...
        'FileType', 'text', ...
        'Delimiter', ',', ...
        'ReadVariableNames', true, ...
        'Encoding', 'UTF-8', ...
        'VariableNamingRule', 'preserve', ...
        'TextType', 'string');

    timestampName = findColumnName( ...
        inputTable, ["timestamp", "utc_timestamp", "time_stamp"]);
    timeUsName = findColumnName( ...
        inputTable, ["time_us", "timeus", "device_time_us"]);
    axName = findColumnName( ...
        inputTable, ["ax_mg", "acc_x_mg", "accx_mg", "accX", "ax"]);
    ayName = findColumnName( ...
        inputTable, ["ay_mg", "acc_y_mg", "accy_mg", "accY", "ay"]);
    azName = findColumnName( ...
        inputTable, ["az_mg", "acc_z_mg", "accz_mg", "accZ", "az"]);

    timestampUTC = parseUTCTimestamps( ...
        inputTable.(char(timestampName)), fileName);
    loggerPosix_s = posixtime(timestampUTC);
    timeUsRaw = toNumericColumn(inputTable.(char(timeUsName)));
    acceleration_mg = [ ...
        toNumericColumn(inputTable.(char(axName))), ...
        toNumericColumn(inputTable.(char(ayName))), ...
        toNumericColumn(inputTable.(char(azName)))];

    validRows = ...
        isfinite(loggerPosix_s) & ...
        isfinite(timeUsRaw) & ...
        all(isfinite(acceleration_mg), 2);

    timestampUTC = timestampUTC(validRows);
    loggerPosix_s = loggerPosix_s(validRows);
    timeUsRaw = timeUsRaw(validRows);
    acceleration_mg = acceleration_mg(validRows, :);

    if numel(timeUsRaw) < 10
        error("Too few valid IMU samples were found in %s.", ...
            char(fileName));
    end

    [timeUsUnwrapped, wrapCount] = unwrapMicrosecondCounter(timeUsRaw);
    deviceRelativeTime_s = ...
        (timeUsUnwrapped - timeUsUnwrapped(1)) * 1e-6;

    if any(diff(deviceRelativeTime_s) <= 0)
        error([ ...
            'The IMU time_us column in %s is not strictly increasing ' ...
            'after 32-bit counter unwrapping.'], char(fileName));
    end

    % Robustly anchor the low-jitter device clock to the UTC logger clock.
    utcAnchorPosix_s = median( ...
        loggerPosix_s - deviceRelativeTime_s, 'omitnan');
    stablePosix_s = utcAnchorPosix_s + deviceRelativeTime_s;
    loggerTimestampResidual_ms = ...
        1000 * (loggerPosix_s - stablePosix_s);

    [stablePosix_s, sortIndex] = sort(stablePosix_s);
    timestampUTC = timestampUTC(sortIndex);
    loggerPosix_s = loggerPosix_s(sortIndex);
    timeUsUnwrapped = timeUsUnwrapped(sortIndex);
    acceleration_mg = acceleration_mg(sortIndex, :);
    loggerTimestampResidual_ms = ...
        loggerTimestampResidual_ms(sortIndex);

    [stablePosix_s, uniqueIndex] = unique(stablePosix_s, 'stable');
    timestampUTC = timestampUTC(uniqueIndex);
    loggerPosix_s = loggerPosix_s(uniqueIndex);
    timeUsUnwrapped = timeUsUnwrapped(uniqueIndex);
    acceleration_mg = acceleration_mg(uniqueIndex, :);
    loggerTimestampResidual_ms = ...
        loggerTimestampResidual_ms(uniqueIndex);

    positiveDt_s = diff(stablePosix_s);
    fs_Hz = 1 / median(positiveDt_s);

    [notReadyValues, hasNotReady] = getOptionalNumericColumn( ...
        inputTable, ["not_ready_count", "notreadycount"]);
    [overrunValues, hasOverrun] = getOptionalNumericColumn( ...
        inputTable, ["overrun_count", "overruncount"]);

    if hasNotReady
        finalNotReadyCount = max(notReadyValues, [], 'omitnan');
    else
        finalNotReadyCount = NaN;
    end

    if hasOverrun
        finalOverrunCount = max(overrunValues, [], 'omitnan');
    else
        finalOverrunCount = NaN;
    end

    imu = struct;
    imu.FileName = string(fileName);
    imu.TimestampUTC = datetime( ...
        stablePosix_s, 'ConvertFrom', 'posixtime', 'TimeZone', 'UTC');
    imu.TimestampUTC.Format = "uuuu-MM-dd'T'HH:mm:ss.SSSSSSXXX";
    imu.Posix_s = stablePosix_s;
    imu.LoggerPosix_s = loggerPosix_s;
    imu.TimeUsUnwrapped = timeUsUnwrapped;
    imu.Acceleration_mg = acceleration_mg;
    imu.Fs_Hz = fs_Hz;
    imu.SampleCount = numel(stablePosix_s);
    imu.TimeCounterWrapCount = wrapCount;
    imu.LoggerTimestampJitterRMS_ms = sqrt(mean( ...
        loggerTimestampResidual_ms .^ 2, 'omitnan'));
    imu.MedianDeviceInterval_us = median(diff(timeUsUnwrapped));
    imu.FinalNotReadyCount = finalNotReadyCount;
    imu.FinalOverrunCount = finalOverrunCount;
end

function graseby = loadNewGrasebyCSV(fileName)

    % Read the fixed timestamp,voltage format without automatic delimiter detection.
    [timestampText, voltage_V] = readGrasebyTwoColumnCSV(fileName);

    timestampUTC = parseUTCTimestamps(timestampText, fileName);
    posix_s = posixtime(timestampUTC);

    validRows = isfinite(posix_s) & isfinite(voltage_V);
    timestampUTC = timestampUTC(validRows);
    posix_s = posix_s(validRows);
    voltage_V = voltage_V(validRows);

    if numel(posix_s) < 10
        error("Too few valid Graseby samples were found in %s.", ...
            char(fileName));
    end

    [posix_s, sortIndex] = sort(posix_s);
    timestampUTC = timestampUTC(sortIndex);
    voltage_V = voltage_V(sortIndex);

    [posix_s, uniqueIndex] = unique(posix_s, 'stable');
    timestampUTC = timestampUTC(uniqueIndex);
    voltage_V = voltage_V(uniqueIndex);

    positiveDt_s = diff(posix_s);
    positiveDt_s = positiveDt_s(positiveDt_s > 0);

    if isempty(positiveDt_s)
        error("The Graseby timestamps in %s do not increase.", ...
            char(fileName));
    end

    fs_Hz = 1 / median(positiveDt_s);

    graseby = struct;
    graseby.FileName = string(fileName);
    graseby.TimestampUTC = timestampUTC;
    graseby.Posix_s = posix_s;
    graseby.Voltage_V = voltage_V;
    graseby.Fs_Hz = fs_Hz;
    graseby.SampleCount = numel(posix_s);
    graseby.UniqueVoltageLevels = numel(unique(voltage_V));
end

function [timestampText, voltage_V] = readGrasebyTwoColumnCSV(fileName)

    fileID = fopen(fileName, 'rt', 'n', 'UTF-8');
    if fileID < 0
        error("Unable to open Graseby file: %s", char(fileName));
    end
    closeFile = onCleanup(@() fclose(fileID)); %#ok<NASGU>

    headerLine = fgetl(fileID);
    if ~ischar(headerLine)
        error("The Graseby file is empty: %s", char(fileName));
    end

    % Remove a UTF-8 byte-order mark if MATLAB exposes it as a character.
    headerLine = erase(string(headerLine), char(65279));
    headerFields = split(headerLine, ',');
    if numel(headerFields) < 2
        error([ ...
            'The first line of %s is not a comma-separated two-column ' ...
            'header. Found: %s'], char(fileName), char(headerLine));
    end

    timestampHeader = lower(strtrim(headerFields(1)));
    if ~any(strcmp(timestampHeader, ...
            ["timestamp", "utc_timestamp", "time_stamp"]))
        warning([ ...
            'The first Graseby column in %s is labelled "%s"; it will ' ...
            'still be interpreted as the UTC timestamp.'], ...
            char(fileName), char(headerFields(1)));
    end

    % Split each row at the final comma to preserve the timestamp.
    allocationBlock = 100000;
    capacity = allocationBlock;
    timestampBuffer = strings(capacity, 1);
    voltageBuffer = nan(capacity, 1);
    validRowCount = 0;
    lineNumber = 1;

    while true
        lineText = fgetl(fileID);
        if ~ischar(lineText)
            break;
        end

        lineNumber = lineNumber + 1;
        lineText = strtrim(lineText);

        if isempty(lineText)
            continue;
        end

        commaIndex = find(lineText == ',', 1, 'last');
        if isempty(commaIndex) || commaIndex == 1 || ...
                commaIndex == length(lineText)
            error([ ...
                'Invalid Graseby CSV row in %s at line %d. Expected ' ...
                'timestamp,voltage but found: %s'], ...
                char(fileName), lineNumber, lineText);
        end

        timestampValue = strtrim(lineText(1:(commaIndex - 1)));
        voltageText = strtrim(lineText((commaIndex + 1):end));

        % Accept quoted timestamps as well as the unquoted timestamps in
        % the current logger files.
        if length(timestampValue) >= 2 && ...
                timestampValue(1) == '"' && timestampValue(end) == '"'
            timestampValue = timestampValue(2:(end - 1));
        end

        voltageValue = str2double(voltageText);
        if ~isfinite(voltageValue)
            error([ ...
                'Invalid Graseby voltage in %s at line %d: %s'], ...
                char(fileName), lineNumber, voltageText);
        end

        validRowCount = validRowCount + 1;
        if validRowCount > capacity
            capacity = capacity + allocationBlock;
            timestampBuffer(capacity, 1) = "";
            voltageBuffer(capacity, 1) = NaN;
        end

        timestampBuffer(validRowCount) = string(timestampValue);
        voltageBuffer(validRowCount) = voltageValue;
    end

    if validRowCount == 0
        error("No Graseby data rows were read from %s.", char(fileName));
    end

    timestampText = strip(timestampBuffer(1:validRowCount));
    voltage_V = voltageBuffer(1:validRowCount);
end

function common = buildUniformOverlap(imu, graseby, cfg)

    overlapStartPosix_s = max(imu.Posix_s(1), graseby.Posix_s(1));
    overlapEndPosix_s = min(imu.Posix_s(end), graseby.Posix_s(end));
    availableOverlap_s = overlapEndPosix_s - overlapStartPosix_s;

    if ~isfinite(availableOverlap_s) || ...
            availableOverlap_s < cfg.minimumOverlap_s
        error([ ...
            'The paired files have only %.3f s of UTC overlap. ' ...
            'At least %.3f s is required.'], ...
            availableOverlap_s, cfg.minimumOverlap_s);
    end

    commonFs_Hz = imu.Fs_Hz;
    commonSampleCount = floor(availableOverlap_s * commonFs_Hz);

    if commonSampleCount < 10
        error("Too few samples remain after UTC synchronization.");
    end

    commonPosix_s = overlapStartPosix_s + ...
        (0:commonSampleCount-1)' / commonFs_Hz;

    acceleration_mg = interp1( ...
        imu.Posix_s, ...
        imu.Acceleration_mg, ...
        commonPosix_s, ...
        'linear');

    grasebyRaw_V = interp1( ...
        graseby.Posix_s, ...
        graseby.Voltage_V, ...
        commonPosix_s, ...
        'linear');

    grasebyFiltered = interp1( ...
        graseby.Posix_s, ...
        graseby.FilteredNative, ...
        commonPosix_s, ...
        'linear');

    validRows = ...
        all(isfinite(acceleration_mg), 2) & ...
        isfinite(grasebyRaw_V) & ...
        isfinite(grasebyFiltered);

    commonPosix_s = commonPosix_s(validRows);
    acceleration_mg = acceleration_mg(validRows, :);
    grasebyRaw_V = grasebyRaw_V(validRows);
    grasebyFiltered = grasebyFiltered(validRows);

    if numel(commonPosix_s) < 10
        error("Interpolation left too few simultaneous samples.");
    end

    timestampUTC = datetime( ...
        commonPosix_s, ...
        'ConvertFrom', 'posixtime', ...
        'TimeZone', 'UTC');
    timestampUTC.Format = "uuuu-MM-dd'T'HH:mm:ss.SSSSSSXXX";

    common = struct;
    common.TimestampUTC = timestampUTC;
    common.Posix_s = commonPosix_s;
    common.RelativeTime_s = commonPosix_s - commonPosix_s(1);
    common.Acceleration_mg = acceleration_mg;
    common.GrasebyRaw_V = grasebyRaw_V;
    common.GrasebyFiltered = grasebyFiltered;
    common.Fs_Hz = commonFs_Hz;
    common.Duration_s = common.RelativeTime_s(end);
end

function y = preprocessRespiratoryChannel(x, fs, band, filterOrder)

    x = double(x(:));
    x = fillmissing(x, 'linear', 'EndValues', 'nearest');
    x = detrend(x);

    if ~isfinite(fs) || fs <= 2 * band(2)
        error("Sampling frequency %.4f Hz is too low for filtering.", fs);
    end

    [z, p, k] = butter( ...
        filterOrder, band / (fs / 2), 'bandpass');
    [sos, gain] = zp2sos(z, p, k);
    y = filtfilt(sos, gain, x);
end

function [frequencyAxis, amplitude, dominantFrequency_Hz] = ...
    calculateWindowedSpectrum(x, fs, searchBand, minimumNFFT)

    x = double(x(:));
    x = fillmissing(x, 'linear', 'EndValues', 'nearest');
    x = detrend(x, 0);

    sampleCount = numel(x);
    if sampleCount < 4
        error("At least four samples are required for frequency analysis.");
    end

    nFFT = max(minimumNFFT, 2 ^ nextpow2(sampleCount));
    analysisWindow = hann(sampleCount, 'periodic');
    coherentGain = sum(analysisWindow);

    spectrum = fft(x .* analysisWindow, nFFT);
    oneSidedCount = floor(nFFT / 2) + 1;
    spectrum = spectrum(1:oneSidedCount);

    frequencyAxis = (0:oneSidedCount-1)' * fs / nFFT;
    amplitude = 2 * abs(spectrum) / coherentGain;
    amplitude(1) = amplitude(1) / 2;

    if mod(nFFT, 2) == 0
        amplitude(end) = amplitude(end) / 2;
    end

    searchRows = ...
        frequencyAxis >= searchBand(1) & ...
        frequencyAxis <= searchBand(2) & ...
        isfinite(amplitude);
    searchIndices = find(searchRows);

    if isempty(searchIndices)
        dominantFrequency_Hz = NaN;
        return;
    end

    [~, localPeakIndex] = max(amplitude(searchIndices));
    peakIndex = searchIndices(localPeakIndex);
    dominantFrequency_Hz = frequencyAxis(peakIndex);

    % Three-bin log-amplitude parabolic interpolation reduces dependence on
    % the zero-padded FFT display grid. It does not create new information.
    if peakIndex > 1 && peakIndex < numel(amplitude)
        neighbouringLogAmplitude = log( ...
            amplitude(peakIndex-1:peakIndex+1) + eps);
        denominator = ...
            neighbouringLogAmplitude(1) - ...
            2 * neighbouringLogAmplitude(2) + ...
            neighbouringLogAmplitude(3);

        if isfinite(denominator) && abs(denominator) > eps
            interpolationOffset = 0.5 * ...
                (neighbouringLogAmplitude(1) - ...
                neighbouringLogAmplitude(3)) / denominator;

            if isfinite(interpolationOffset) && ...
                    abs(interpolationOffset) <= 1
                dominantFrequency_Hz = frequencyAxis(peakIndex) + ...
                    interpolationOffset * fs / nFFT;
            end
        end
    end

    dominantFrequency_Hz = min( ...
        max(dominantFrequency_Hz, searchBand(1)), searchBand(2));
end

function snr_dB = calculateSpectralSNR( ...
    frequencyAxis, amplitude, dominantFrequency_Hz, band, peakHalfWidth_Hz)

    if ~isfinite(dominantFrequency_Hz)
        snr_dB = NaN;
        return;
    end

    powerSpectrum = amplitude .^ 2;
    inBand = frequencyAxis >= band(1) & frequencyAxis <= band(2);
    signalRows = inBand & ...
        abs(frequencyAxis - dominantFrequency_Hz) <= peakHalfWidth_Hz;
    noiseRows = inBand & ~signalRows;

    signalPower = sum(powerSpectrum(signalRows), 'omitnan');
    noisePower = sum(powerSpectrum(noiseRows), 'omitnan');

    if signalPower <= 0 || noisePower <= 0 || ...
            ~isfinite(signalPower) || ~isfinite(noisePower)
        snr_dB = NaN;
    else
        snr_dB = 10 * log10(signalPower / noisePower);
    end
end

function normalisedAmplitude = normaliseSpectrumInBand( ...
    frequencyAxis, amplitude, band)

    inBand = frequencyAxis >= band(1) & frequencyAxis <= band(2);
    bandMaximum = max(amplitude(inBand), [], 'omitnan');

    if ~isfinite(bandMaximum) || bandMaximum <= 0
        normalisedAmplitude = nan(size(amplitude));
    else
        normalisedAmplitude = amplitude / bandMaximum;
    end
end

function lagResult = findBestLagAndSign( ...
    imuSignal, grasebySignal, fs, maximumLag_s)

    imuSignal = imuSignal(:);
    grasebySignal = grasebySignal(:);

    if numel(imuSignal) ~= numel(grasebySignal)
        error("Lag search inputs must have equal lengths.");
    end

    maximumLagSamples = max(0, round(maximumLag_s * fs));
    lagCandidates = (-maximumLagSamples:maximumLagSamples)';
    correlationCandidates = nan(size(lagCandidates));

    for candidateIndex = 1:numel(lagCandidates)
        lagSamples = lagCandidates(candidateIndex);
        [imuIndices, grasebyIndices] = getLaggedIndices( ...
            numel(imuSignal), lagSamples);
        correlationCandidates(candidateIndex) = calculateCorrelation( ...
            imuSignal(imuIndices), grasebySignal(grasebyIndices));
    end

    finiteCandidates = isfinite(correlationCandidates);
    if ~any(finiteCandidates)
        error("No valid waveform lag correlation could be calculated.");
    end

    candidateNumbers = find(finiteCandidates);
    absoluteCorrelations = abs(correlationCandidates(candidateNumbers));
    bestAbsoluteCorrelation = max(absoluteCorrelations);
    tiedCandidates = candidateNumbers( ...
        abs(absoluteCorrelations - bestAbsoluteCorrelation) < 1e-12);

    % If two lags give the same correlation, prefer the smallest shift.
    [~, smallestShiftIndex] = min(abs(lagCandidates(tiedCandidates)));
    bestCandidate = tiedCandidates(smallestShiftIndex);
    bestLagSamples = lagCandidates(bestCandidate);
    bestSignedCorrelation = correlationCandidates(bestCandidate);

    [imuIndices, grasebyIndices] = getLaggedIndices( ...
        numel(imuSignal), bestLagSamples);

    imuSignFactor = sign(bestSignedCorrelation);
    if imuSignFactor == 0 || ~isfinite(imuSignFactor)
        imuSignFactor = 1;
    end

    lagResult = struct;
    lagResult.LagSamples = bestLagSamples;
    % Positive means the Graseby waveform occurs later than the IMU waveform.
    lagResult.Lag_s = bestLagSamples / fs;
    lagResult.IMUSignFactor = imuSignFactor;
    lagResult.IMUIndices = imuIndices;
    lagResult.GrasebyIndices = grasebyIndices;
    lagResult.IMUAligned = imuSignFactor * imuSignal(imuIndices);
    lagResult.GrasebyAligned = grasebySignal(grasebyIndices);
    lagResult.BestSignedCorrelationBeforeSignCorrection = ...
        bestSignedCorrelation;
end

function [imuIndices, grasebyIndices] = getLaggedIndices( ...
    sampleCount, lagSamples)

    if lagSamples > 0
        imuIndices = (1:sampleCount-lagSamples)';
        grasebyIndices = (1+lagSamples:sampleCount)';
    elseif lagSamples < 0
        imuIndices = (1-lagSamples:sampleCount)';
        grasebyIndices = (1:sampleCount+lagSamples)';
    else
        imuIndices = (1:sampleCount)';
        grasebyIndices = imuIndices;
    end
end

function correlationValue = calculateCorrelation(firstSignal, secondSignal)

    firstSignal = firstSignal(:);
    secondSignal = secondSignal(:);
    validRows = isfinite(firstSignal) & isfinite(secondSignal);

    if nnz(validRows) < 4
        correlationValue = NaN;
        return;
    end

    firstSignal = firstSignal(validRows);
    secondSignal = secondSignal(validRows);

    if std(firstSignal) == 0 || std(secondSignal) == 0
        correlationValue = NaN;
        return;
    end

    correlationMatrix = corrcoef(firstSignal, secondSignal);
    correlationValue = correlationMatrix(1, 2);
end

function [correlationValue, maeValue, rmseValue] = ...
    calculateNormalisedMetrics(firstSignal, secondSignal)

    firstSignal = firstSignal(:);
    secondSignal = secondSignal(:);
    validRows = isfinite(firstSignal) & isfinite(secondSignal);

    if nnz(validRows) < 4
        correlationValue = NaN;
        maeValue = NaN;
        rmseValue = NaN;
        return;
    end

    firstSignal = firstSignal(validRows);
    secondSignal = secondSignal(validRows);
    correlationValue = calculateCorrelation(firstSignal, secondSignal);
    difference = firstSignal - secondSignal;
    maeValue = mean(abs(difference));
    rmseValue = sqrt(mean(difference .^ 2));
end

function y = normaliseSignal(x)

    x = double(x(:));
    validRows = isfinite(x);
    y = nan(size(x));

    if ~any(validRows)
        return;
    end

    centre = mean(x(validRows));
    scale = std(x(validRows));

    if ~isfinite(scale) || scale == 0
        scale = 1;
    end

    y(validRows) = (x(validRows) - centre) / scale;
end

function [unwrappedTimeUs, wrapCount] = ...
    unwrapMicrosecondCounter(rawTimeUs)

    rawTimeUs = double(rawTimeUs(:));
    unwrappedTimeUs = nan(size(rawTimeUs));
    unwrappedTimeUs(1) = rawTimeUs(1);

    counterModulus = 2 ^ 32;
    wrapDetectionThreshold = -counterModulus / 2;
    accumulatedOffset = 0;
    wrapCount = 0;

    for sampleIndex = 2:numel(rawTimeUs)
        rawStep = rawTimeUs(sampleIndex) - rawTimeUs(sampleIndex - 1);

        if rawStep < wrapDetectionThreshold
            accumulatedOffset = accumulatedOffset + counterModulus;
            wrapCount = wrapCount + 1;
        end

        unwrappedTimeUs(sampleIndex) = ...
            rawTimeUs(sampleIndex) + accumulatedOffset;
    end
end

function timestampUTC = parseUTCTimestamps(timestampValues, fileName)

    if isdatetime(timestampValues)
        timestampUTC = timestampValues(:);
        if isempty(timestampUTC.TimeZone)
            timestampUTC.TimeZone = 'UTC';
        else
            timestampUTC.TimeZone = 'UTC';
        end
        timestampUTC.Format = "uuuu-MM-dd'T'HH:mm:ss.SSSSSSXXX";
        return;
    end

    timestampText = strip(string(timestampValues(:)));
    inputFormats = [ ...
        "uuuu-MM-dd'T'HH:mm:ss.SSSSSSSSSXXX", ...
        "uuuu-MM-dd'T'HH:mm:ss.SSSSSSXXX", ...
        "uuuu-MM-dd'T'HH:mm:ss.SSSXXX", ...
        "uuuu-MM-dd'T'HH:mm:ssXXX"];

    timestampUTC = NaT(size(timestampText), 'TimeZone', 'UTC');
    parsedSuccessfully = false;

    for formatIndex = 1:numel(inputFormats)
        try
            candidate = datetime( ...
                timestampText, ...
                'InputFormat', char(inputFormats(formatIndex)), ...
                'TimeZone', 'UTC');

            if nnz(~isnat(candidate)) >= max(1, floor(0.95 * numel(candidate)))
                timestampUTC = candidate;
                parsedSuccessfully = true;
                break;
            end
        catch
            % Try the next explicitly supported ISO 8601 format.
        end
    end

    if ~parsedSuccessfully
        error([ ...
            'Unable to parse the UTC timestamp column in %s. Expected ' ...
            'an ISO 8601 value such as ' ...
            '2026-08-05T00:38:20.123456+00:00.'], char(fileName));
    end

    timestampUTC.Format = "uuuu-MM-dd'T'HH:mm:ss.SSSSSSXXX";
end

function columnName = findColumnName(inputTable, aliases)

    variableNames = strip(string(inputTable.Properties.VariableNames));
    aliases = strip(string(aliases));

    for aliasIndex = 1:numel(aliases)
        matchIndex = find(strcmpi(variableNames, aliases(aliasIndex)), 1);
        if ~isempty(matchIndex)
            columnName = variableNames(matchIndex);
            return;
        end
    end

    error( ...
        "Required column was not found. Accepted names: %s. Available: %s", ...
        char(strjoin(aliases, ", ")), ...
        char(strjoin(variableNames, ", ")));
end

function columnName = findOnlyNumericSignalColumn( ...
    inputTable, timestampName, fileName)

    variableNames = string(inputTable.Properties.VariableNames);
    candidateIndices = find(~strcmp(variableNames, timestampName));
    finiteFractions = zeros(size(candidateIndices));

    for candidateIndex = 1:numel(candidateIndices)
        values = toNumericColumn(inputTable.( ...
            char(variableNames(candidateIndices(candidateIndex)))));
        finiteFractions(candidateIndex) = mean(isfinite(values));
    end

    validCandidates = candidateIndices(finiteFractions >= 0.95);
    if numel(validCandidates) ~= 1
        error([ ...
            'The Graseby voltage column in %s could not be identified ' ...
            'unambiguously. Expected the header 电压 or voltage.'], ...
            char(fileName));
    end

    columnName = variableNames(validCandidates);
end

function numericValues = toNumericColumn(values)

    if isnumeric(values) || islogical(values)
        numericValues = double(values(:));
    else
        numericValues = str2double(string(values(:)));
    end
end

function [values, wasFound] = getOptionalNumericColumn(inputTable, aliases)

    try
        columnName = findColumnName(inputTable, aliases);
        values = toNumericColumn(inputTable.(char(columnName)));
        wasFound = true;
    catch
        values = NaN;
        wasFound = false;
    end
end

function folderName = findDataFolder(scriptFolder, firstFileStem)

    candidates = [ ...
        string(fullfile(scriptFolder, "Data")), ...
        string(scriptFolder), ...
        string(fullfile(scriptFolder, "..", "Data"))];

    folderName = "";

    for candidateIndex = 1:numel(candidates)
        candidate = candidates(candidateIndex);
        expectedIMUFile = fullfile( ...
            candidate, firstFileStem + "_imu.csv");
        expectedGrasebyFile = fullfile( ...
            candidate, firstFileStem + "_graseby.csv");

        if isfolder(candidate) && ...
                isfile(expectedIMUFile) && ...
                isfile(expectedGrasebyFile)
            folderName = candidate;
            return;
        end
    end
end

function assertRequiredFunctionsAreAvailable()

    requiredFunctions = [ ...
        "pca", "butter", "zp2sos", "filtfilt", "hann", "exportgraphics"];
    missingFunctions = strings(0, 1);

    for functionIndex = 1:numel(requiredFunctions)
        if exist(char(requiredFunctions(functionIndex)), 'file') == 0
            missingFunctions(end + 1, 1) = ...
                requiredFunctions(functionIndex); %#ok<AGROW>
        end
    end

    if ~isempty(missingFunctions)
        error([ ...
            'Required MATLAB functions are unavailable: %s. ' ...
            'This analysis requires Statistics and Machine Learning ' ...
            'Toolbox (pca) and Signal Processing Toolbox.'], ...
            char(strjoin(missingFunctions, ", ")));
    end
end

function output = formatUTC(timestampUTC)

    timestampUTC.Format = "uuuu-MM-dd'T'HH:mm:ss.SSSSSSXXX";
    output = string(timestampUTC);
end

function createTrialFigure( ...
    trialName, expectedRR_bpm, common, accFiltered, selectedPC, ...
    selectedIMUNormalised, grasebyNormalised, frequencyAxis_Hz, ...
    selectedPCSpectrumNormalised, grasebySpectrumNormalised, ...
    selectedIMURR_bpm, grasebyRR_bpm, selectedIMUSNR_dB, ...
    grasebySNR_dB, zeroLagCorrelationSigned, lagResult, ...
    lagAdjustedCorrelation, lagAdjustedRMSE, cfg, outputBaseName)

    if cfg.showFigures
        figureVisibility = 'on';
    else
        figureVisibility = 'off';
    end

    comparisonFigure = figure( ...
        'Name', char(trialName + " IMU vs Graseby"), ...
        'Color', 'w', ...
        'Visible', figureVisibility, ...
        'Position', [40 30 1500 980]);

    comparisonLayout = tiledlayout( ...
        comparisonFigure, 3, 2, ...
        'TileSpacing', 'compact', ...
        'Padding', 'compact');

    nexttile;
    plot(common.RelativeTime_s, common.Acceleration_mg, 'LineWidth', 0.7);
    grid on;
    xlabel('Time in retained UTC interval [s]');
    ylabel('Acceleration [mg]');
    title('Synchronized raw IMU acceleration');
    legend('X', 'Y', 'Z', 'Location', 'best');

    nexttile;
    hold on;
    for channel = 1:3
        plot( ...
            common.RelativeTime_s, ...
            normaliseSignal(accFiltered(:, channel)), ...
            'LineWidth', 0.8);
    end
    grid on;
    xlabel('Time in retained UTC interval [s]');
    ylabel('Normalised amplitude');
    title(sprintf('Filtered axes (%.1f-%.1f Hz)', ...
        cfg.respiratoryBand_Hz(1), cfg.respiratoryBand_Hz(2)));
    legend('X', 'Y', 'Z', 'Location', 'best');

    nexttile;
    % 只调整 PCA 正负方向，不移动时间；标题必须与所绘曲线一致。
    imuForZeroLag = lagResult.IMUSignFactor * selectedIMUNormalised;
    displayedZeroLagCorrelation = calculateCorrelation( ...
        imuForZeroLag, grasebyNormalised);
    plot(common.RelativeTime_s, imuForZeroLag, 'LineWidth', 1.0);
    hold on;
    plot(common.RelativeTime_s, grasebyNormalised, 'LineWidth', 1.0);
    grid on;
    xlabel('Time in retained UTC interval [s]');
    ylabel('Normalised amplitude');
    title(sprintf('UTC alignment, PC polarity corrected (r = %.3f)', ...
        displayedZeroLagCorrelation));
    legend(sprintf('IMU PC%d', selectedPC), 'Graseby', ...
        'Location', 'best');

    nexttile;
    plot(frequencyAxis_Hz, selectedPCSpectrumNormalised, ...
        'LineWidth', 1.2);
    hold on;
    plot(frequencyAxis_Hz, grasebySpectrumNormalised, ...
        'LineWidth', 1.2);
    xline(expectedRR_bpm / 60, 'k--', ...
        sprintf('Expected %.3f Hz', expectedRR_bpm / 60), ...
        'LineWidth', 1.3);
    grid on;
    xlim([0 cfg.respiratoryBand_Hz(2)]);
    ylim([0 1.08]);
    xlabel('Frequency [Hz]');
    ylabel('Band-normalised amplitude');
    title(sprintf('Spectra: IMU SNR %.1f dB, Graseby SNR %.1f dB', ...
        selectedIMUSNR_dB, grasebySNR_dB));
    legend(sprintf('IMU PC%d', selectedPC), 'Graseby', 'Expected', ...
        'Location', 'best');

    nexttile;
    pairTime_s = (0:numel(lagResult.IMUAligned)-1)' / common.Fs_Hz;
    plot(pairTime_s, lagResult.IMUAligned, 'LineWidth', 1.0);
    hold on;
    plot(pairTime_s, lagResult.GrasebyAligned, 'LineWidth', 1.0);
    grid on;
    xlabel('Lag-adjusted pair time [s]');
    ylabel('Normalised amplitude');
    title(sprintf( ...
        'Best waveform lag %.3f s: r = %.3f, RMSE = %.3f', ...
        lagResult.Lag_s, lagAdjustedCorrelation, lagAdjustedRMSE));
    legend(sprintf('IMU PC%d', selectedPC), 'Graseby', ...
        'Location', 'best');

    nexttile;
    respiratoryRates = [ ...
        expectedRR_bpm, selectedIMURR_bpm, grasebyRR_bpm];
    rateBars = bar(respiratoryRates, 0.65);
    rateBars.FaceColor = 'flat';
    rateBars.CData(1, :) = [0.25 0.25 0.25];
    rateBars.CData(2, :) = [0.00 0.45 0.74];
    rateBars.CData(3, :) = [0.85 0.33 0.10];
    grid on;
    xticks([1 2 3]);
    xticklabels({'Expected', sprintf('IMU PC%d', selectedPC), 'Graseby'});
    ylabel('Respiratory rate [breaths/min]');
    title(sprintf('RR: expected %.2f, IMU %.2f, Graseby %.2f', ...
        expectedRR_bpm, selectedIMURR_bpm, grasebyRR_bpm));
    ylim([0 1.25 * max(respiratoryRates)]);

    title(comparisonLayout, sprintf( ...
        '%s IMU-Graseby comparison | trim %.1f s + %.1f s | retained %.2f s', ...
        char(trialName), cfg.trimStart_s, cfg.trimEnd_s, common.Duration_s));

    exportgraphics( ...
        comparisonFigure, outputBaseName + ".png", ...
        'Resolution', cfg.figureResolution_dpi);

    if cfg.saveMATLABFigureFiles
        savefig(comparisonFigure, outputBaseName + ".fig");
    end

    if ~cfg.showFigures
        close(comparisonFigure);
    end
end

function createCombinedSummaryFigure(combinedSummary, cfg)

    if cfg.showFigures
        figureVisibility = 'on';
    else
        figureVisibility = 'off';
    end

    summaryFigure = figure( ...
        'Name', 'RR20 RR35 RR50 Combined Summary', ...
        'Color', 'w', ...
        'Visible', figureVisibility, ...
        'Position', [80 50 1350 820]);

    summaryLayout = tiledlayout( ...
        summaryFigure, 2, 2, ...
        'TileSpacing', 'compact', ...
        'Padding', 'compact');

    expectedRR = combinedSummary.ExpectedRespiratoryRate_bpm;

    nexttile;
    plot(expectedRR, expectedRR, 'k--o', 'LineWidth', 1.2);
    hold on;
    plot(expectedRR, ...
        combinedSummary.IMUEstimatedRespiratoryRate_bpm, ...
        '-o', 'LineWidth', 1.5);
    plot(expectedRR, ...
        combinedSummary.GrasebyEstimatedRespiratoryRate_bpm, ...
        '-s', 'LineWidth', 1.5);
    grid on;
    xlabel('Expected RR [breaths/min]');
    ylabel('Estimated RR [breaths/min]');
    title('Expected versus estimated respiratory rate');
    legend('Ideal', 'IMU', 'Graseby', 'Location', 'best');

    nexttile;
    errorValues = [ ...
        combinedSummary.IMUAbsoluteRespiratoryRateError_bpm, ...
        combinedSummary.GrasebyAbsoluteRespiratoryRateError_bpm];
    bar(errorValues);
    grid on;
    xticks(1:height(combinedSummary));
    xticklabels(cellstr(combinedSummary.Trial));
    ylabel('Absolute RR error [breaths/min]');
    title('Respiratory-rate error');
    legend('IMU', 'Graseby', 'Location', 'best');

    nexttile;
    bar(combinedSummary.LagAdjustedCorrelation_Normalised, 0.65);
    grid on;
    xticks(1:height(combinedSummary));
    xticklabels(cellstr(combinedSummary.Trial));
    ylim([0 1]);
    ylabel('Correlation coefficient');
    title('Lag-adjusted waveform correlation');

    nexttile;
    bar(combinedSummary.GrasebyLagRelativeToIMU_s, 0.65);
    grid on;
    yline(0, 'k-');
    xticks(1:height(combinedSummary));
    xticklabels(cellstr(combinedSummary.Trial));
    ylabel('Graseby lag relative to IMU [s]');
    title('Best descriptive waveform lag');

    title(summaryLayout, ...
        'Simultaneous IMU-Graseby comparison across RR settings');

    outputBaseName = fullfile( ...
        cfg.outputFolder, "RR20_RR35_RR50_Combined_Summary");
    exportgraphics( ...
        summaryFigure, outputBaseName + ".png", ...
        'Resolution', cfg.figureResolution_dpi);

    if cfg.saveMATLABFigureFiles
        savefig(summaryFigure, outputBaseName + ".fig");
    end

    if ~cfg.showFigures
        close(summaryFigure);
    end
end