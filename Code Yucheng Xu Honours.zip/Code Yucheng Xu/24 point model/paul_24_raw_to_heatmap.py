#!/usr/bin/env python3
"""Read the P1-P24 IMU recordings and create a 3D heatmap of Paul.
Use one file per point, with the point name in the filename.
Estimate motion amplitude from the filtered PCA signal using P95-P5.

Run: python paul_24_raw_to_heatmap.py ./raw_24
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import math
import re
import subprocess
import sys
from pathlib import Path

import numpy as np


POINT_LOCATIONS = {
    "P1": "图像左前·上", "P2": "正前·上", "P3": "图像右前·上",
    "P4": "图像左前·中", "P5": "正前·中", "P6": "图像右前·中",
    "P7": "图像左前·下", "P8": "正前·下", "P9": "图像右前·下",
    "P10": "图像左侧·上", "P11": "图像左侧·中", "P12": "图像左侧·下",
    "P13": "图像右侧·上", "P14": "图像右侧·中", "P15": "图像右侧·下",
    "P16": "图像左后·上", "P17": "图像左后·中", "P18": "图像左后·下",
    "P19": "正后·上", "P20": "正后·中", "P21": "正后·下",
    "P22": "图像右后·上", "P23": "图像右后·中", "P24": "图像右后·下",
}

ACCEL_ALIASES = {
    "x": (
        "raw_acc_x_mg", "raw_accel_x_mg", "filtered_acc_x_mg",
        "ax_mg", "acc_x_mg", "accel_x_mg", "acceleration_x_mg",
        "raw_acc_x", "filtered_acc_x", "ax", "acc_x", "accel_x",
    ),
    "y": (
        "raw_acc_y_mg", "raw_accel_y_mg", "filtered_acc_y_mg",
        "ay_mg", "acc_y_mg", "accel_y_mg", "acceleration_y_mg",
        "raw_acc_y", "filtered_acc_y", "ay", "acc_y", "accel_y",
    ),
    "z": (
        "raw_acc_z_mg", "raw_accel_z_mg", "filtered_acc_z_mg",
        "az_mg", "acc_z_mg", "accel_z_mg", "acceleration_z_mg",
        "raw_acc_z", "filtered_acc_z", "az", "acc_z", "accel_z",
    ),
}

TIME_COLUMNS = {
    "time_us": 1e-6,
    "timestamp_us": 1e-6,
    "elapsed_us": 1e-6,
    "time_ms": 1e-3,
    "timestamp_ms": 1e-3,
    "elapsed_ms": 1e-3,
    "time_s": 1.0,
    "timestamp_s": 1.0,
    "elapsed_s": 1.0,
    "seconds": 1.0,
    "time": None,
}


def normalise_header(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", name.strip().lower()).strip("_")


def read_text(path: Path) -> str:
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            return path.read_text(encoding=encoding)
        except UnicodeDecodeError:
            continue
    raise ValueError(f"Cannot decode {path.name}")


def choose_delimiter(sample: str) -> str:
    try:
        return csv.Sniffer().sniff(sample, delimiters=",\t;").delimiter
    except csv.Error:
        return ","


def find_column(header_map: dict[str, str], aliases: tuple[str, ...]) -> str | None:
    for alias in aliases:
        if alias in header_map:
            return header_map[alias]
    return None


def read_raw_recording(path: Path, fallback_sample_rate: float) -> tuple[np.ndarray, float, str]:
    text = read_text(path)
    delimiter = choose_delimiter(text[:8192])
    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    if not reader.fieldnames:
        raise ValueError(f"{path.name}: no CSV header was found")

    header_map = {normalise_header(name): name for name in reader.fieldnames if name}
    axis_columns = [find_column(header_map, ACCEL_ALIASES[axis]) for axis in "xyz"]
    if any(column is None for column in axis_columns):
        available = ", ".join(reader.fieldnames)
        raise ValueError(
            f"{path.name}: acceleration columns were not found. "
            f"Expected raw_acc_x_mg/raw_acc_y_mg/raw_acc_z_mg or "
            f"ax_mg/ay_mg/az_mg; found: {available}"
        )

    time_column = None
    time_scale = None
    for normalised, scale in TIME_COLUMNS.items():
        if normalised in header_map:
            time_column = header_map[normalised]
            time_scale = scale
            break

    acceleration: list[list[float]] = []
    raw_times: list[float] = []
    for row in reader:
        try:
            values = [float(row[column]) for column in axis_columns]
        except (TypeError, ValueError, KeyError):
            continue
        if not all(math.isfinite(value) for value in values):
            continue
        acceleration.append(values)
        if time_column is not None:
            try:
                raw_times.append(float(row[time_column]))
            except (TypeError, ValueError, KeyError):
                raw_times.append(float("nan"))

    data = np.asarray(acceleration, dtype=float)
    if len(data) < 128:
        raise ValueError(f"{path.name}: only {len(data)} numeric samples were found")

    sample_rate = fallback_sample_rate
    if time_column is not None and len(raw_times) == len(data):
        times = np.asarray(raw_times, dtype=float)
        finite_times = times[np.isfinite(times)]
        differences = np.diff(finite_times)
        differences = differences[differences > 0]
        if len(differences):
            median_difference = float(np.median(differences))
            if time_scale is None:
                if median_difference > 1000:
                    time_scale = 1e-6
                elif median_difference > 1:
                    time_scale = 1e-3
                else:
                    time_scale = 1.0
            estimated_rate = 1.0 / (median_difference * time_scale)
            if 2.0 <= estimated_rate <= 2000.0:
                sample_rate = estimated_rate

    unit = "mg" if all("mg" in normalise_header(column) for column in axis_columns) else "sensor units"
    return data, float(sample_rate), unit


def fft_bandpass(signal: np.ndarray, sample_rate: float, low_hz: float, high_hz: float) -> np.ndarray:
    frequencies = np.fft.rfftfreq(len(signal), d=1.0 / sample_rate)
    spectrum = np.fft.rfft(signal)
    keep = (frequencies >= low_hz) & (frequencies <= high_hz)
    spectrum[~keep] = 0.0
    return np.fft.irfft(spectrum, n=len(signal))


def analyse_recording(
    acceleration: np.ndarray,
    sample_rate: float,
    low_hz: float,
    high_hz: float,
    trim_seconds: float,
) -> dict[str, float | int]:
    trim_samples = int(round(trim_seconds * sample_rate))
    minimum_samples = max(128, int(math.ceil(10.0 * sample_rate)))
    if trim_samples and len(acceleration) - 2 * trim_samples >= minimum_samples:
        acceleration = acceleration[trim_samples:-trim_samples]
    if len(acceleration) < minimum_samples:
        raise ValueError(
            f"recording is too short after trimming: {len(acceleration)} samples; "
            f"need at least {minimum_samples}"
        )

    # Remove a linear trend from every axis without normalising its amplitude.
    time_basis = np.linspace(-1.0, 1.0, len(acceleration))
    design = np.column_stack((np.ones(len(acceleration)), time_basis))
    coefficients = np.linalg.lstsq(design, acceleration, rcond=None)[0]
    detrended = acceleration - design @ coefficients

    covariance = np.cov(detrended, rowvar=False)
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    order = np.argsort(eigenvalues)[::-1]
    scores = detrended @ eigenvectors[:, order]

    filtered_components = np.column_stack(
        [fft_bandpass(scores[:, index], sample_rate, low_hz, high_hz) for index in range(3)]
    )
    respiratory_rms = np.sqrt(np.mean(filtered_components**2, axis=0))
    selected_index = int(np.argmax(respiratory_rms))
    respiratory_signal = filtered_components[:, selected_index]

    amplitude = float(np.percentile(respiratory_signal, 95) - np.percentile(respiratory_signal, 5))
    frequencies = np.fft.rfftfreq(len(respiratory_signal), d=1.0 / sample_rate)
    window = np.hanning(len(respiratory_signal))
    power = np.abs(np.fft.rfft((respiratory_signal - np.mean(respiratory_signal)) * window)) ** 2
    band = (frequencies >= low_hz) & (frequencies <= high_hz)
    band_indices = np.flatnonzero(band)
    if not len(band_indices):
        raise ValueError("recording is too short for the requested respiratory frequency band")
    peak_index = int(band_indices[np.argmax(power[band])])
    peak_frequency = float(frequencies[peak_index])

    resolution = sample_rate / len(respiratory_signal)
    signal_width = max(0.05, 1.5 * resolution)
    signal_band = band & (np.abs(frequencies - peak_frequency) <= signal_width)
    noise_band = band & ~signal_band
    signal_power = float(np.sum(power[signal_band]))
    noise_power = float(np.sum(power[noise_band])) if np.any(noise_band) else np.finfo(float).eps
    snr_db = 10.0 * math.log10((signal_power + np.finfo(float).eps) / (noise_power + np.finfo(float).eps))

    return {
        "value": amplitude,
        "samples_used": int(len(respiratory_signal)),
        "sample_rate_hz": float(sample_rate),
        "selected_pc": selected_index + 1,
        "rr_bpm": peak_frequency * 60.0,
        "snr_db": snr_db,
    }


def point_number_from_filename(path: Path) -> int | None:
    match = re.search(r"(?i)(?:^|[^a-z0-9])p(?:oint)?[_\- ]*0*(\d{1,2})(?=$|[^0-9])", path.stem)
    if not match:
        return None
    number = int(match.group(1))
    return number if 1 <= number <= 24 else None


def discover_point_files(folder: Path) -> dict[int, Path]:
    discovered: dict[int, Path] = {}
    duplicates: dict[int, list[str]] = {}
    for path in sorted(folder.iterdir()):
        if not path.is_file() or path.suffix.lower() not in {".csv", ".txt"}:
            continue
        number = point_number_from_filename(path)
        if number is None:
            continue
        if number in discovered:
            duplicates.setdefault(number, [discovered[number].name]).append(path.name)
        else:
            discovered[number] = path
    if duplicates:
        detail = "; ".join(f"P{number}: {', '.join(names)}" for number, names in duplicates.items())
        raise ValueError("More than one file was found for a point: " + detail)
    missing = [f"P{number}" for number in range(1, 25) if number not in discovered]
    if missing:
        raise ValueError("Missing raw files for: " + ", ".join(missing))
    return discovered


def find_heatmap_script(explicit_path: Path | None) -> Path:
    if explicit_path is not None:
        candidates = [explicit_path]
    else:
        script_folder = Path(__file__).resolve().parent
        candidates = [
            script_folder / "paul_upper_body_heatmap_24.py",
            script_folder / "paul_upper_body_heatmap.py",
        ]
    for candidate in candidates:
        candidate = candidate.resolve()
        if candidate.is_file() and "P24" in candidate.read_text(encoding="utf-8", errors="ignore"):
            return candidate
    raise FileNotFoundError(
        "The 24-point heatmap script was not found. Put "
        "paul_upper_body_heatmap_24.py in the same folder as this program."
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("input_folder", type=Path, help="folder containing P1-P24 raw CSV/TXT files")
    parser.add_argument("--output-dir", type=Path, help="default: paul_24_output beside the raw-data folder")
    parser.add_argument("--sample-rate", type=float, default=33.333333, help="fallback rate if no usable time column exists")
    parser.add_argument("--trim-seconds", type=float, default=2.0, help="remove this much handling time from both ends")
    parser.add_argument("--low-hz", type=float, default=0.1)
    parser.add_argument("--high-hz", type=float, default=1.5)
    parser.add_argument("--heatmap-script", type=Path, help="optional explicit path to the 24-point heatmap program")
    parser.add_argument("--metric-label", default="PCA amplitude (mg)")
    args = parser.parse_args()

    if args.sample_rate <= 0 or args.trim_seconds < 0:
        parser.error("sample rate must be positive and trim seconds cannot be negative")
    if not 0 < args.low_hz < args.high_hz < args.sample_rate / 2:
        parser.error("frequency limits must satisfy 0 < low < high < Nyquist")

    input_folder = args.input_folder.resolve()
    if not input_folder.is_dir():
        parser.error(f"input folder does not exist: {input_folder}")
    output_dir = (args.output_dir or input_folder.parent / "paul_24_output").resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    try:
        point_files = discover_point_files(input_folder)
        results = []
        units = set()
        for number in range(1, 25):
            path = point_files[number]
            acceleration, sample_rate, unit = read_raw_recording(path, args.sample_rate)
            units.add(unit)
            result = analyse_recording(
                acceleration,
                sample_rate,
                args.low_hz,
                args.high_hz,
                args.trim_seconds,
            )
            pid = f"P{number}"
            results.append({
                "point": pid,
                "value": result["value"],
                "location": POINT_LOCATIONS[pid],
                "samples_used": result["samples_used"],
                "sample_rate_hz": result["sample_rate_hz"],
                "selected_pc": result["selected_pc"],
                "rr_bpm": result["rr_bpm"],
                "snr_db": result["snr_db"],
                "source_file": path.name,
            })

        values_path = output_dir / "paul_24_pca_values.csv"
        fieldnames = [
            "point", "value", "location", "samples_used", "sample_rate_hz",
            "selected_pc", "rr_bpm", "snr_db", "source_file",
        ]
        with values_path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            for row in results:
                serialised = row.copy()
                for key in ("value", "sample_rate_hz", "rr_bpm", "snr_db"):
                    serialised[key] = f"{float(serialised[key]):.8g}"
                writer.writerow(serialised)

        heatmap_script = find_heatmap_script(args.heatmap_script)
        command = [
            sys.executable,
            str(heatmap_script),
            "--values-csv", str(values_path),
            "--output-dir", str(output_dir),
            "--metric-label", args.metric_label,
        ]
        subprocess.run(command, check=True, cwd=heatmap_script.parent)
    except (ValueError, FileNotFoundError, subprocess.CalledProcessError) as exc:
        parser.exit(2, f"Error: {exc}\n")

    print(json.dumps({
        "raw_files_processed": 24,
        "input_units": sorted(units),
        "values_csv": str(values_path),
        "interactive_html": str(output_dir / "paul-upper-body-heatmap-v2.html"),
        "preview_png": str(output_dir / "paul_upper_body_heatmap_preview.png"),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
