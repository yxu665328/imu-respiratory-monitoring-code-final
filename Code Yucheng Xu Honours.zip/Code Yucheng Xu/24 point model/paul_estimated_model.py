#!/usr/bin/env python3
"""Build an approximate 3D model of Paul from reference dimensions and a photo.
Some dimensions are estimated. The model is for visualisation and has not
been validated for biomechanical analysis.

Run: python paul_estimated_model.py
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np


@dataclass
class Mesh:
    name: str
    vertices: np.ndarray
    faces: np.ndarray
    material: str = "skin"


def ellipsoid_mesh(
    name: str,
    center: Sequence[float],
    radii: Sequence[float],
    n_lat: int = 14,
    n_lon: int = 24,
    material: str = "skin",
) -> Mesh:
    """Closed UV ellipsoid.  Duplicate pole vertices are harmless for display."""
    c = np.asarray(center, dtype=float)
    r = np.asarray(radii, dtype=float)
    verts: list[list[float]] = []
    for i in range(n_lat + 1):
        phi = math.pi * i / n_lat
        sp, cp = math.sin(phi), math.cos(phi)
        for j in range(n_lon):
            theta = 2.0 * math.pi * j / n_lon
            verts.append(
                [
                    c[0] + r[0] * sp * math.cos(theta),
                    c[1] + r[1] * sp * math.sin(theta),
                    c[2] + r[2] * cp,
                ]
            )
    faces: list[list[int]] = []
    for i in range(n_lat):
        for j in range(n_lon):
            nj = (j + 1) % n_lon
            a, b = i * n_lon + j, i * n_lon + nj
            c0, d = (i + 1) * n_lon + j, (i + 1) * n_lon + nj
            faces.extend(([a, c0, b], [b, c0, d]))
    return Mesh(name, np.asarray(verts), np.asarray(faces, dtype=int), material)


def ellipsoid_cap_mesh(
    name: str,
    center: Sequence[float],
    radii: Sequence[float],
    phi_max: float,
    n_lat: int = 10,
    n_lon: int = 28,
    material: str = "hair",
) -> Mesh:
    """Open cap measured from the ellipsoid's +z pole."""
    c = np.asarray(center, dtype=float)
    r = np.asarray(radii, dtype=float)
    verts: list[list[float]] = []
    for i in range(n_lat + 1):
        phi = phi_max * i / n_lat
        sp, cp = math.sin(phi), math.cos(phi)
        for j in range(n_lon):
            theta = 2.0 * math.pi * j / n_lon
            verts.append(
                [
                    c[0] + r[0] * sp * math.cos(theta),
                    c[1] + r[1] * sp * math.sin(theta),
                    c[2] + r[2] * cp,
                ]
            )
    faces: list[list[int]] = []
    for i in range(n_lat):
        for j in range(n_lon):
            nj = (j + 1) % n_lon
            a, b = i * n_lon + j, i * n_lon + nj
            c0, d = (i + 1) * n_lon + j, (i + 1) * n_lon + nj
            faces.extend(([a, c0, b], [b, c0, d]))
    return Mesh(name, np.asarray(verts), np.asarray(faces, dtype=int), material)


def loft_mesh(
    name: str,
    rings: Sequence[tuple[float, float, float, float]],
    n_ring: int = 36,
    material: str = "skin",
) -> Mesh:
    """Asymmetric torso loft; each ring is z, x-radius, posterior, anterior."""
    verts: list[list[float]] = []
    for z, rx, y_back, y_front in rings:
        for j in range(n_ring):
            theta = 2.0 * math.pi * j / n_ring
            s = math.sin(theta)
            ry = y_front if s >= 0 else y_back
            verts.append([rx * math.cos(theta), ry * s, z])
    faces: list[list[int]] = []
    for i in range(len(rings) - 1):
        for j in range(n_ring):
            nj = (j + 1) % n_ring
            a, b = i * n_ring + j, i * n_ring + nj
            c0, d = (i + 1) * n_ring + j, (i + 1) * n_ring + nj
            faces.extend(([a, b, c0], [b, d, c0]))
    # Close both ends to complete the surface mesh.
    bottom_idx = len(verts)
    verts.append([0.0, 0.0, rings[0][0]])
    top_idx = len(verts)
    verts.append([0.0, 0.0, rings[-1][0]])
    for j in range(n_ring):
        nj = (j + 1) % n_ring
        faces.append([bottom_idx, nj, j])
        a, b = (len(rings) - 1) * n_ring + j, (len(rings) - 1) * n_ring + nj
        faces.append([top_idx, a, b])
    return Mesh(name, np.asarray(verts), np.asarray(faces, dtype=int), material)


def oriented_frustum_mesh(
    name: str,
    p0: Sequence[float],
    p1: Sequence[float],
    r0: float,
    r1: float,
    n_axis: int = 5,
    n_ring: int = 18,
    flatten: float = 0.92,
    material: str = "skin",
) -> Mesh:
    """Closed tapered limb aligned to arbitrary endpoints."""
    a = np.asarray(p0, dtype=float)
    b = np.asarray(p1, dtype=float)
    axis = b - a
    axis /= np.linalg.norm(axis)
    trial = np.array([0.0, 0.0, 1.0])
    if abs(float(np.dot(axis, trial))) > 0.9:
        trial = np.array([0.0, 1.0, 0.0])
    u = np.cross(axis, trial)
    u /= np.linalg.norm(u)
    v = np.cross(axis, u)
    verts: list[list[float]] = []
    for i in range(n_axis + 1):
        t = i / n_axis
        center = a * (1.0 - t) + b * t
        radius = r0 * (1.0 - t) + r1 * t
        for j in range(n_ring):
            th = 2.0 * math.pi * j / n_ring
            q = center + radius * math.cos(th) * u + flatten * radius * math.sin(th) * v
            verts.append(q.tolist())
    faces: list[list[int]] = []
    for i in range(n_axis):
        for j in range(n_ring):
            nj = (j + 1) % n_ring
            x0, x1 = i * n_ring + j, i * n_ring + nj
            y0, y1 = (i + 1) * n_ring + j, (i + 1) * n_ring + nj
            faces.extend(([x0, x1, y0], [x1, y1, y0]))
    c0, c1 = len(verts), len(verts) + 1
    verts.extend((a.tolist(), b.tolist()))
    for j in range(n_ring):
        nj = (j + 1) % n_ring
        faces.extend(([c0, nj, j], [c1, n_axis * n_ring + j, n_axis * n_ring + nj]))
    return Mesh(name, np.asarray(verts), np.asarray(faces, dtype=int), material)


def torso_profile(rings: Sequence[tuple[float, float, float, float]], z: float) -> tuple[float, float, float]:
    arr = np.asarray(rings, dtype=float)
    return tuple(float(np.interp(z, arr[:, 0], arr[:, k])) for k in (1, 2, 3))


def build_model(length_cm: float, head_circumference_cm: float, chest_depth_cm: float, abdomen_depth_cm: float):
    scale = length_cm / 35.0
    # Width/depth choices are intentionally separate.  Depth is the least certain
    # dimension in a single front photograph and can be changed at the CLI.
    head_scale = head_circumference_cm / 26.0
    chest_half = chest_depth_cm / 2.0
    abdomen_half = abdomen_depth_cm / 2.0

    rings = [
        (-6.4, 3.55, abdomen_half * 0.86, abdomen_half * 0.96),
        (-4.2, 4.05, abdomen_half * 0.90, abdomen_half * 1.00),
        (-1.8, 4.18, abdomen_half * 0.87, abdomen_half * 0.98),
        (0.8, 4.13, chest_half * 0.91, chest_half * 1.00),
        (3.6, 4.32, chest_half * 0.88, chest_half * 0.97),
        (5.6, 4.62, chest_half * 0.82, chest_half * 0.90),
        (6.5, 3.55, chest_half * 0.72, chest_half * 0.78),
    ]
    rings = [tuple(v * scale for v in ring) for ring in rings]

    meshes: list[Mesh] = [loft_mesh("torso", rings)]
    # Neck and head.  Head breadth and AP depth satisfy the circumference only
    # approximately because the real head is not a perfect ellipse.
    meshes.extend(
        [
            ellipsoid_mesh("neck", (0, 0, 7.0 * scale), (1.75 * scale, 1.65 * scale, 1.35 * scale)),
            ellipsoid_mesh(
                "head",
                (0, 0.15 * scale, 12.55 * scale),
                (5.00 * head_scale * scale, 5.00 * head_scale * scale, 5.00 * scale),
                n_lat=18,
                n_lon=30,
            ),
            ellipsoid_cap_mesh(
                "hair_cap",
                (0, 0.12 * scale, 12.55 * scale),
                (5.00 * head_scale * scale, 5.00 * head_scale * scale, 5.00 * scale),
                phi_max=1.43,
            ),
            ellipsoid_mesh("ear_photo_left", (3.93 * scale, 0.0, 12.3 * scale), (0.42, 0.58, 0.90), 10, 18),
            ellipsoid_mesh("ear_photo_right", (-3.93 * scale, 0.0, 12.3 * scale), (0.42, 0.58, 0.90), 10, 18),
            ellipsoid_mesh("nose", (0, 4.22 * head_scale * scale, 12.25 * scale), (0.62, 0.42, 0.76), 10, 18),
            ellipsoid_mesh("eye_photo_left", (1.25 * scale, 3.96 * scale, 13.45 * scale), (0.70, 0.15, 0.17), 8, 16, "detail"),
            ellipsoid_mesh("eye_photo_right", (-1.25 * scale, 3.96 * scale, 13.45 * scale), (0.70, 0.15, 0.17), 8, 16, "detail"),
            ellipsoid_mesh("mouth", (0, 3.98 * scale, 10.80 * scale), (1.22, 0.15, 0.38), 8, 18, "detail"),
        ]
    )

    # Arms are separate segments to preserve the visible mannequin joint seams.
    for side, sx in (("photo_left", 1.0), ("photo_right", -1.0)):
        shoulder = np.array([sx * 4.25, 0.0, 5.15]) * scale
        elbow = np.array([sx * 5.22, 0.05, 0.35]) * scale
        wrist = np.array([sx * 5.78, 0.18, -4.55]) * scale
        hand = np.array([sx * 5.90, 0.32, -5.95]) * scale
        meshes.extend(
            [
                ellipsoid_mesh(f"{side}_shoulder", shoulder, (1.20, 1.18, 1.35)),
                oriented_frustum_mesh(f"{side}_upper_arm", shoulder, elbow, 1.12 * scale, 0.88 * scale),
                ellipsoid_mesh(f"{side}_elbow", elbow, (0.91, 0.82, 0.94)),
                oriented_frustum_mesh(f"{side}_forearm", elbow, wrist, 0.84 * scale, 0.62 * scale),
                ellipsoid_mesh(f"{side}_hand", hand, (0.72, 0.72, 1.42), 12, 20),
            ]
        )

    # Lower body is a conservative generic estimate because it is cropped out.
    for side, sx in (("photo_left", 1.0), ("photo_right", -1.0)):
        hip = np.array([sx * 2.88, 0.0, -5.9]) * scale
        knee = np.array([sx * 2.35, 0.15, -11.0]) * scale
        ankle = np.array([sx * 2.25, 0.20, -15.55]) * scale
        foot = np.array([sx * 2.25, 1.10, -16.45]) * scale
        meshes.extend(
            [
                ellipsoid_mesh(f"{side}_hip", hip, (1.75, 1.65, 1.62), 12, 20),
                oriented_frustum_mesh(f"{side}_thigh", hip, knee, 1.55 * scale, 1.10 * scale),
                ellipsoid_mesh(f"{side}_knee", knee, (1.12, 1.02, 1.02)),
                oriented_frustum_mesh(f"{side}_shin", knee, ankle, 1.00 * scale, 0.68 * scale),
                ellipsoid_mesh(f"{side}_foot", foot, (1.00, 1.72, 1.05), 12, 20),
            ]
        )

    # Small anterior umbilical feature helps orient the chest/abdomen surface.
    meshes.append(
        oriented_frustum_mesh(
            "umbilical_feature",
            (0, abdomen_half * scale * 0.97, -4.55 * scale),
            (0, (abdomen_half + 1.05) * scale, -4.55 * scale),
            0.50 * scale,
            0.42 * scale,
            n_axis=3,
            material="detail",
        )
    )

    # Nine candidate surface locations: rows upper/middle/lower and columns
    # photo-left/front/photo-right.  These are positions only, never fake values.
    points = []
    labels = [
        ("P1", "图像左·上", 1, 3.6), ("P2", "前方·上", 0, 3.6), ("P3", "图像右·上", -1, 3.6),
        ("P4", "图像左·中", 1, 0.8), ("P5", "前方·中", 0, 0.8), ("P6", "图像右·中", -1, 0.8),
        ("P7", "图像左·下", 1, -3.6), ("P8", "前方·下", 0, -3.6), ("P9", "图像右·下", -1, -3.6),
    ]
    for pid, label, col, z0 in labels:
        z = z0 * scale
        rx, _yb, yf = torso_profile(rings, z)
        if col == 0:
            x, y = 0.0, yf + 0.12 * scale
        else:
            x = col * 0.70 * rx
            # Surface point on the anterior quadrant of an ellipse.
            y = yf * math.sqrt(max(0.0, 1.0 - (x / rx) ** 2)) + 0.12 * scale
        points.append({"id": pid, "label": label, "xyz_cm": [round(x, 4), round(y, 4), round(z, 4)]})

    return meshes, rings, points


def write_obj(path: Path, meshes: Iterable[Mesh], mtl_name: str) -> None:
    lines = ["# Approximate Paul research visualisation mesh", f"mtllib {mtl_name}"]
    offset = 1
    for mesh in meshes:
        lines.extend((f"o {mesh.name}", f"usemtl {mesh.material}"))
        lines.extend(f"v {x:.6f} {y:.6f} {z:.6f}" for x, y, z in mesh.vertices)
        lines.extend(
            f"f {a + offset} {b + offset} {c + offset}" for a, b, c in mesh.faces
        )
        offset += len(mesh.vertices)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_mtl(path: Path) -> None:
    path.write_text(
        "# Approximate colours sampled visually from the supplied photograph\n"
        "newmtl skin\nKd 0.54 0.29 0.22\nKa 0.08 0.04 0.03\nKs 0.10 0.10 0.10\nNs 18\n\n"
        "newmtl hair\nKd 0.20 0.07 0.14\nKa 0.03 0.01 0.02\nKs 0.03 0.03 0.03\nNs 8\n\n"
        "newmtl detail\nKd 0.28 0.05 0.09\nKa 0.03 0.01 0.01\nKs 0.04 0.04 0.04\nNs 10\n",
        encoding="utf-8",
    )


def read_point_values(path: Path | None) -> dict[str, float]:
    if path is None:
        return {}
    values: dict[str, float] = {}
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or not {"point", "value"}.issubset(reader.fieldnames):
            raise ValueError("CSV must contain columns: point,value")
        for row in reader:
            point = row["point"].strip().upper()
            if point in {f"P{i}" for i in range(1, 10)}:
                values[point] = float(row["value"])
    return values


def rounded(values: np.ndarray, digits: int = 3) -> list:
    return np.round(values.astype(float), digits).tolist()


def write_interactive_fragment(path: Path, meshes: list[Mesh], points: list[dict], values: dict[str, float]) -> None:
    payload_meshes = []
    # Combine same-material pieces to reduce the number of WebGL traces.
    for material in ("skin", "hair", "detail"):
        selected = [m for m in meshes if m.material == material]
        if not selected:
            continue
        vv: list[np.ndarray] = []
        ff: list[np.ndarray] = []
        offset = 0
        for mesh in selected:
            vv.append(mesh.vertices)
            ff.append(mesh.faces + offset)
            offset += len(mesh.vertices)
        vertices = np.vstack(vv)
        faces = np.vstack(ff)
        payload_meshes.append(
            {
                "name": material,
                "x": rounded(vertices[:, 0]), "y": rounded(vertices[:, 1]), "z": rounded(vertices[:, 2]),
                "i": faces[:, 0].tolist(), "j": faces[:, 1].tolist(), "k": faces[:, 2].tolist(),
            }
        )
    payload = json.dumps({"meshes": payload_meshes, "points": points, "values": values}, ensure_ascii=False, separators=(",", ":"))
    html = f'''<div id="paul-estimated-model-v1" class="paul-model" aria-label="可旋转的 Paul 近似三维模型与九个候选测点">
  <style>
    #paul-estimated-model-v1 {{ color: var(--foreground); background: var(--background); font-family: var(--font-sans); width: 100%; }}
    #paul-estimated-model-v1 .pm-shell {{ border: 1px solid var(--border); border-radius: var(--radius-lg); background: var(--card); overflow: hidden; }}
    #paul-estimated-model-v1 .pm-head {{ display:flex; align-items:flex-start; justify-content:space-between; gap:1rem; padding:1rem 1rem .65rem; flex-wrap:wrap; }}
    #paul-estimated-model-v1 h2 {{ margin:0 0 .25rem; font-size:1.05rem; color:var(--foreground); }}
    #paul-estimated-model-v1 p {{ margin:0; color:var(--muted-foreground); font-size:.86rem; line-height:1.5; }}
    #paul-estimated-model-v1 .pm-controls {{ display:flex; gap:.4rem; flex-wrap:wrap; }}
    #paul-estimated-model-v1 button {{ min-height:2rem; padding:.35rem .68rem; border:1px solid var(--border); border-radius:var(--radius-md); color:var(--foreground); background:var(--background); cursor:pointer; font:inherit; }}
    #paul-estimated-model-v1 button:hover {{ background:var(--muted); }}
    #paul-estimated-model-v1 button:focus-visible {{ outline:2px solid var(--ring); outline-offset:2px; }}
    #paul-estimated-model-v1 .pm-plot {{ width:100%; height:clamp(450px,65vw,650px); }}
    #paul-estimated-model-v1 .pm-note {{ border-top:1px solid var(--border); padding:.75rem 1rem .9rem; display:flex; gap:.9rem; align-items:center; flex-wrap:wrap; }}
    #paul-estimated-model-v1 .pm-dot {{ width:.7rem; height:.7rem; border-radius:999px; background:var(--viz-series-2); display:inline-block; }}
    #paul-estimated-model-v1 .pm-label {{ display:inline-flex; gap:.4rem; align-items:center; color:var(--muted-foreground); font-size:.82rem; }}
    @media (max-width: 560px) {{ #paul-estimated-model-v1 .pm-plot {{ height:500px; }} }}
  </style>
  <div class="pm-shell">
    <div class="pm-head">
      <div><h2>Paul 科研可视化近似模型</h2><p>拖动旋转 · 滚轮缩放 · 单位 cm · 正面照片约束，前后厚度为可调估计</p></div>
      <div class="pm-controls" aria-label="视角控制">
        <button type="button" data-view="front">正面</button><button type="button" data-view="left">图像左侧</button><button type="button" data-view="right">图像右侧</button><button type="button" data-view="iso">立体</button>
      </div>
    </div>
    <div id="paul-model-plot-v1" class="pm-plot" role="img" aria-label="Paul 三维表面模型"></div>
    <div class="pm-note"><span class="pm-label"><span class="pm-dot"></span>P1–P9 是候选位置，不代表已测数值</span><p>坐标：x 正值向照片左，y 向身体前方，z 向头侧。</p></div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/plotly.js-dist-min@2.35.2/plotly.min.js"></script>
  <script>
  (() => {{
    const data = {payload};
    const root = document.getElementById('paul-estimated-model-v1');
    const css = getComputedStyle(document.documentElement);
    const palette = {{ skin: css.getPropertyValue('--viz-series-1').trim(), hair: css.getPropertyValue('--muted-foreground').trim(), detail: css.getPropertyValue('--viz-series-4').trim(), points: css.getPropertyValue('--viz-series-2').trim(), text: css.getPropertyValue('--foreground').trim(), grid: css.getPropertyValue('--border').trim() }};
    const traces = data.meshes.map((m) => ({{ type:'mesh3d', name:m.name, x:m.x, y:m.y, z:m.z, i:m.i, j:m.j, k:m.k, color:palette[m.name], opacity:m.name==='skin'?0.88:0.96, flatshading:false, hoverinfo:'skip', lighting:{{ambient:.55,diffuse:.75,specular:.18,roughness:.72,fresnel:.08}}, lightposition:{{x:40,y:65,z:80}}, showlegend:false }}));
    const vals = data.points.map(p => Object.prototype.hasOwnProperty.call(data.values,p.id) ? data.values[p.id] : null);
    const hasValues = vals.some(v => v !== null);
    const hover = data.points.map((p,idx) => hasValues && vals[idx] !== null ? `${{p.id}} · ${{p.label}}<br>值：${{vals[idx]}}` : `${{p.id}} · ${{p.label}}<br>候选位置（未加载数值）`);
    traces.push({{type:'scatter3d', mode:'markers+text', name:'P1–P9', x:data.points.map(p=>p.xyz_cm[0]), y:data.points.map(p=>p.xyz_cm[1]), z:data.points.map(p=>p.xyz_cm[2]), text:data.points.map(p=>p.id), textposition:'top center', hovertext:hover, hoverinfo:'text', marker:hasValues?{{size:3,color:vals,colorscale:'Turbo',showscale:true,colorbar:{{title:'value',thickness:12,len:.48}}}}:{{size:7,color:palette.points,line:{{color:palette.text,width:1}}}}, textfont:{{color:palette.text,size:11}} }});
    const axis = (title, range) => ({{title:{{text:title,font:{{size:11}}}},range,showbackground:false,gridcolor:palette.grid,zerolinecolor:palette.grid,tickfont:{{size:9}},color:palette.text}});
    const layout = {{margin:{{l:0,r:0,t:0,b:0}},paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',font:{{color:palette.text}},showlegend:false,scene:{{aspectmode:'manual',aspectratio:{{x:.7,y:.58,z:1.7}},xaxis:axis('x · 照片左右',[-8,8]),yaxis:axis('y · 向前',[-6,6]),zaxis:axis('z · 向头',[-18,18]),camera:{{eye:{{x:1.28,y:1.75,z:.72}},up:{{x:0,y:0,z:1}}}},dragmode:'orbit'}} }};
    Plotly.newPlot('paul-model-plot-v1', traces, layout, {{responsive:true,displaylogo:false,scrollZoom:true,modeBarButtonsToRemove:['select2d','lasso2d']}});
    const cameras = {{front:{{x:0,y:2.25,z:.05}},left:{{x:-2.25,y:0,z:.05}},right:{{x:2.25,y:0,z:.05}},iso:{{x:1.28,y:1.75,z:.72}}}};
    root.querySelectorAll('button[data-view]').forEach(btn => btn.addEventListener('click', () => Plotly.relayout('paul-model-plot-v1', {{'scene.camera.eye':cameras[btn.dataset.view]}})));
  }})();
  </script>
</div>'''
    path.write_text(html, encoding="utf-8")


def write_preview_png(path: Path, meshes: list[Mesh], points: list[dict]) -> None:
    """Render a static oblique QA view; the interactive HTML is the main preview."""
    import os
    os.environ.setdefault("MPLCONFIGDIR", "/tmp/paul-model-mpl")
    import matplotlib.pyplot as plt
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection

    fig = plt.figure(figsize=(7.2, 8.2), dpi=150)
    ax = fig.add_subplot(111, projection="3d")
    colours = {"skin": "#A95E4C", "hair": "#54243F", "detail": "#742338"}
    for mesh in meshes:
        # Full mesh remains manageable; edges are disabled for a clean surface.
        poly = Poly3DCollection(mesh.vertices[mesh.faces], linewidths=0, alpha=0.86)
        poly.set_facecolor(colours[mesh.material])
        ax.add_collection3d(poly)
    xyz = np.asarray([p["xyz_cm"] for p in points])
    ax.scatter(xyz[:, 0], xyz[:, 1], xyz[:, 2], s=30, c="#21B7A8", depthshade=False)
    for p in points:
        x, y, z = p["xyz_cm"]
        ax.text(x, y + 0.25, z + 0.25, p["id"], fontsize=7, ha="center")
    ax.set(xlim=(-8, 8), ylim=(-6, 6), zlim=(-18, 18), xlabel="x / cm", ylabel="front y / cm", zlabel="z / cm")
    ax.set_box_aspect((16, 12, 36))
    ax.view_init(elev=8, azim=90)
    ax.set_title("Paul approximate research-visualisation mesh\nP1–P9 are candidate locations only")
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--length", type=float, default=35.0, help="crown-to-foot length in cm")
    parser.add_argument("--head-circumference", type=float, default=26.0, help="head circumference in cm")
    parser.add_argument("--chest-depth", type=float, default=5.4, help="estimated AP chest depth in cm")
    parser.add_argument("--abdomen-depth", type=float, default=6.0, help="estimated AP abdomen depth in cm")
    parser.add_argument("--values-csv", type=Path, help="optional CSV with point,value columns")
    args = parser.parse_args()
    if min(args.length, args.head_circumference, args.chest_depth, args.abdomen_depth) <= 0:
        parser.error("all dimensions must be positive")

    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    meshes, rings, points = build_model(args.length, args.head_circumference, args.chest_depth, args.abdomen_depth)
    values = read_point_values(args.values_csv)

    obj_path = out / "paul_estimated_model.obj"
    mtl_path = out / "paul_estimated_model.mtl"
    json_path = out / "paul_estimated_model_parameters.json"
    png_path = out / "paul_estimated_model_preview.png"
    html_path = out / "paul-estimated-model.html"
    write_obj(obj_path, meshes, mtl_path.name)
    write_mtl(mtl_path)
    write_interactive_fragment(html_path, meshes, points, values)

    params = {
        "model_name": "Paul approximate research visualisation model v1",
        "classification": "estimated surface model; not manufacturer CAD; not a validated digital twin",
        "source_constraints": {
            "published_length_cm": args.length,
            "published_head_circumference_cm": args.head_circumference,
            "supplied_view": "single anterior/front photograph",
            "photo_used_for": "relative frontal silhouette and segment proportions",
        },
        "editable_depth_assumptions_cm": {"chest_ap": args.chest_depth, "abdomen_ap": args.abdomen_depth},
        "coordinate_system": {"x": "positive toward image left", "y": "positive anterior/toward camera", "z": "positive headward"},
        "torso_rings": [{"z_cm": z, "half_width_cm": x, "posterior_depth_cm": yb, "anterior_depth_cm": yf} for z, x, yb, yf in rings],
        "candidate_points": points,
        "uncertainty": {
            "head_and_front_silhouette": "medium; constrained by circumference and front photo",
            "torso_width": "medium; estimated uncertainty roughly ±0.5 cm",
            "chest_abdomen_depth": "low confidence; estimated uncertainty roughly ±0.8 cm until a calibrated side photo is supplied",
            "legs_and_feet": "low confidence; lower body is cropped from the supplied photo",
        },
        "recommended_next_capture": "one true side photo with a ruler in the mannequin mid-sagittal plane, plus chest and abdomen AP caliper measurements",
    }
    json_path.write_text(json.dumps(params, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    write_preview_png(png_path, meshes, points)
    print(json.dumps({"outputs": [str(obj_path), str(mtl_path), str(json_path), str(png_path), str(html_path)]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
