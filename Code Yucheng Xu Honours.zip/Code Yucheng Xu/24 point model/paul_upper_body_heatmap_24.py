#!/usr/bin/env python3
"""Plot the P1-P24 values as a heatmap on the Paul 3D model.
Keep this file in the same folder as paul_estimated_model.py.
The CSV needs point,value columns with values for all 24 points.
Colours between points are interpolated, not directly measured.
Without a values CSV, the script uses demo data.

Run: python paul_upper_body_heatmap_24.py --values-csv point_values.csv
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
from pathlib import Path

import numpy as np

try:
    from paul_estimated_model import Mesh, build_model, loft_mesh, rounded, torso_profile
except ImportError as exc:
    raise SystemExit(
        "paul_estimated_model.py must be in the same folder as this script."
    ) from exc


DEMO_VALUES = {
    "P1": 0.38, "P2": 0.62, "P3": 0.45,
    "P4": 0.52, "P5": 0.90, "P6": 0.58,
    "P7": 0.33, "P8": 0.70, "P9": 0.40,
    "P10": 0.34, "P11": 0.46, "P12": 0.31,
    "P13": 0.39, "P14": 0.51, "P15": 0.35,
    "P16": 0.29, "P17": 0.40, "P18": 0.27,
    "P19": 0.26, "P20": 0.37, "P21": 0.25,
    "P22": 0.30, "P23": 0.42, "P24": 0.28,
}

POINT_IDS = tuple(f"P{i}" for i in range(1, 25))


def read_values(path: Path | None) -> tuple[dict[str, float], bool]:
    if path is None:
        return DEMO_VALUES.copy(), True
    values: dict[str, float] = {}
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or not {"point", "value"}.issubset(reader.fieldnames):
            raise ValueError("CSV must contain columns: point,value")
        for row in reader:
            label = row["point"].strip().upper()
            if label.startswith("V"):
                label = "P" + label[1:]
            if label in POINT_IDS:
                values[label] = float(row["value"])
    missing = [pid for pid in POINT_IDS if pid not in values]
    if missing:
        raise ValueError("Missing values for: " + ", ".join(missing))
    return values, False


def build_24_points(rings, scale: float):
    """Return 24 torso points: three heights at eight circumferential sectors.

    P1-P9 retain the original anterior numbering. P10-P24 add the true side
    and posterior sectors. Left/right below refer to the displayed photograph,
    matching the model's x-axis convention rather than anatomical laterality.
    """
    upper, middle, lower = 3.6 * scale, 0.8 * scale, -3.6 * scale
    specs = [
        ("P1", "图像左前·上", math.pi / 4, upper),
        ("P2", "正前·上", math.pi / 2, upper),
        ("P3", "图像右前·上", 3 * math.pi / 4, upper),
        ("P4", "图像左前·中", math.pi / 4, middle),
        ("P5", "正前·中", math.pi / 2, middle),
        ("P6", "图像右前·中", 3 * math.pi / 4, middle),
        ("P7", "图像左前·下", math.pi / 4, lower),
        ("P8", "正前·下", math.pi / 2, lower),
        ("P9", "图像右前·下", 3 * math.pi / 4, lower),
        ("P10", "图像左侧·上", 0.0, upper),
        ("P11", "图像左侧·中", 0.0, middle),
        ("P12", "图像左侧·下", 0.0, lower),
        ("P13", "图像右侧·上", math.pi, upper),
        ("P14", "图像右侧·中", math.pi, middle),
        ("P15", "图像右侧·下", math.pi, lower),
        ("P16", "图像左后·上", -math.pi / 4, upper),
        ("P17", "图像左后·中", -math.pi / 4, middle),
        ("P18", "图像左后·下", -math.pi / 4, lower),
        ("P19", "正后·上", -math.pi / 2, upper),
        ("P20", "正后·中", -math.pi / 2, middle),
        ("P21", "正后·下", -math.pi / 2, lower),
        ("P22", "图像右后·上", -3 * math.pi / 4, upper),
        ("P23", "图像右后·中", -3 * math.pi / 4, middle),
        ("P24", "图像右后·下", -3 * math.pi / 4, lower),
    ]
    points = []
    offset = 0.12 * scale
    for pid, label, theta, z in specs:
        rx, y_back, y_front = torso_profile(rings, z)
        ry = y_front if math.sin(theta) >= 0.0 else y_back
        ct, st = math.cos(theta), math.sin(theta)
        x, y = rx * ct, ry * st
        # Push the marker just outside the elliptical torso surface.
        nx, ny = ct / rx, st / ry
        normal_length = math.hypot(nx, ny)
        x += offset * nx / normal_length
        y += offset * ny / normal_length
        points.append({"id": pid, "label": label, "xyz_cm": [round(x, 4), round(y, 4), round(z, 4)]})
    return points


def densify_rings(rings, n_z: int = 29):
    source = np.asarray(rings, dtype=float)
    z_new = np.linspace(source[0, 0], source[-1, 0], n_z)
    return [
        (
            float(z),
            float(np.interp(z, source[:, 0], source[:, 1])),
            float(np.interp(z, source[:, 0], source[:, 2])),
            float(np.interp(z, source[:, 0], source[:, 3])),
        )
        for z in z_new
    ]


def interpolate_surface(vertices, points, values, smoothing_cm: float):
    anchors = np.asarray([p["xyz_cm"] for p in points], dtype=float)
    amplitudes = np.asarray([values[p["id"]] for p in points], dtype=float)

    # Gaussian radial-basis interpolation with a constant term. The small
    # regularisation stabilises the 24x24 solve while retaining anchor values.
    # AP distance is reduced slightly to respect the torso's flatter AP shape.
    scale = np.asarray([1.0, 0.72, 1.0])
    anchor_diff = (anchors[:, None, :] - anchors[None, :, :]) * scale
    kernel = np.exp(-np.sum(anchor_diff * anchor_diff, axis=2) / (2.0 * smoothing_cm**2))
    system = np.block([
        [kernel + np.eye(len(anchors)) * 1e-7, np.ones((len(anchors), 1))],
        [np.ones((1, len(anchors))), np.zeros((1, 1))],
    ])
    solution = np.linalg.solve(system, np.r_[amplitudes, 0.0])
    surface_diff = (vertices[:, None, :] - anchors[None, :, :]) * scale
    basis = np.exp(-np.sum(surface_diff * surface_diff, axis=2) / (2.0 * smoothing_cm**2))
    field = basis @ solution[:-1] + solution[-1]
    return np.clip(field, float(np.min(amplitudes)), float(np.max(amplitudes)))


def combine_meshes(meshes: list[Mesh], name: str):
    vertices, faces, offset = [], [], 0
    for mesh in meshes:
        vertices.append(mesh.vertices)
        faces.append(mesh.faces + offset)
        offset += len(mesh.vertices)
    return {
        "name": name,
        "x": rounded(np.vstack(vertices)[:, 0]),
        "y": rounded(np.vstack(vertices)[:, 1]),
        "z": rounded(np.vstack(vertices)[:, 2]),
        "i": np.vstack(faces)[:, 0].tolist(),
        "j": np.vstack(faces)[:, 1].tolist(),
        "k": np.vstack(faces)[:, 2].tolist(),
    }


def mesh_payload(mesh: Mesh, intensity=None):
    data = {
        "name": mesh.name,
        "x": rounded(mesh.vertices[:, 0]),
        "y": rounded(mesh.vertices[:, 1]),
        "z": rounded(mesh.vertices[:, 2]),
        "i": mesh.faces[:, 0].tolist(),
        "j": mesh.faces[:, 1].tolist(),
        "k": mesh.faces[:, 2].tolist(),
    }
    if intensity is not None:
        data["intensity"] = rounded(np.asarray(intensity), 5)
    return data


def write_html(path, meshes, torso, torso_values, points, point_values, demo, metric_label):
    # Pass Matplotlib's actual Turbo lookup table to Plotly instead of relying
    # on a named browser-side scale. Some Plotly builds do not recognise the
    # string "Turbo" and silently fall back to a different sequential palette.
    os.environ.setdefault("MPLCONFIGDIR", "/tmp/paul-heatmap-mpl")
    from matplotlib import colormaps

    turbo = colormaps["turbo"]
    turbo_colorscale = []
    for index in range(256):
        fraction = index / 255.0
        red, green, blue, _alpha = turbo(fraction)
        rgb = f"rgb({round(red * 255)},{round(green * 255)},{round(blue * 255)})"
        turbo_colorscale.append([round(fraction, 6), rgb])
    colour_min = 0.0
    colour_max = 50.0
    if demo:
        data_note = "24 点示例数据，未加载实验结果"
    else:
        data_note = "已加载 P1–P24 实验值"

    non_torso_skin = [m for m in meshes if m.material == "skin" and m.name != "torso"]
    hair = [m for m in meshes if m.material == "hair"]
    detail = [m for m in meshes if m.material == "detail"]
    payload = {
        "body": combine_meshes(non_torso_skin, "body"),
        "hair": combine_meshes(hair, "hair"),
        "detail": combine_meshes(detail, "detail"),
        "torso": mesh_payload(torso, torso_values),
        "points": points,
        "values": point_values,
        "demo": demo,
        "metric": metric_label,
        "colorscale": turbo_colorscale,
        "cmin": colour_min,
        "cmax": colour_max,
    }
    data = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    html = f'''<div id="paul-upper-body-heatmap-v1" aria-label="Paul 上半身连续呼吸强度热图">
  <style>
    #paul-upper-body-heatmap-v1 {{ width:100%; color:var(--foreground); background:var(--background); font-family:var(--font-sans); }}
    #paul-upper-body-heatmap-v1 .controls {{ display:flex; flex-wrap:wrap; gap:.45rem; padding:.35rem 0 .6rem; }}
    #paul-upper-body-heatmap-v1 button {{ border:1px solid var(--border); color:var(--foreground); background:var(--card); border-radius:var(--radius-md); padding:.42rem .7rem; cursor:pointer; }}
    #paul-upper-body-heatmap-v1 button[aria-pressed="true"] {{ background:var(--primary); color:var(--primary-foreground); }}
    #paul-upper-body-heatmap-v1 .plot {{ width:100%; height:clamp(500px,70vw,690px); }}
    #paul-upper-body-heatmap-v1 .status {{ color:var(--muted-foreground); padding:.45rem 0 0; }}
  </style>
  <div class="controls" aria-label="显示控制">
    <button type="button" data-mode="heat" aria-pressed="true">连续热图</button>
    <button type="button" data-mode="dots" aria-pressed="false">热图＋表面点</button>
    <button type="button" data-mode="skin" aria-pressed="false">肉色模型</button>
    <button type="button" data-view="front">正面</button>
    <button type="button" data-view="left">左侧</button>
    <button type="button" data-view="right">右侧</button>
    <button type="button" data-view="back">后背</button>
    <button type="button" data-view="iso">立体</button>
  </div>
  <div id="paul-upper-body-heatmap-plot-v1" class="plot" role="img" aria-label="鼠标可旋转的 Paul 胸腹呼吸强度表面热图"></div>
  <div class="status">{metric_label} · {data_note} · 统一 Turbo 色图 {colour_min:.3g}–{colour_max:.3g} · 24 点空间插值</div>
  <script src="https://cdn.jsdelivr.net/npm/plotly.js-dist-min@2.35.2/plotly.min.js"></script>
  <script>
  (() => {{
    const d = {data};
    const css = getComputedStyle(document.documentElement);
    const text = css.getPropertyValue('--foreground').trim();
    const grid = css.getPropertyValue('--border').trim();
    const flesh = 'rgb(174,100,82)';
    // Keep every closed body surface fully opaque. Semi-transparent Mesh3d
    // traces blend posterior triangles and back markers into the front view.
    const makeMesh = (m,color,visible=true) => ({{type:'mesh3d',x:m.x,y:m.y,z:m.z,i:m.i,j:m.j,k:m.k,color,visible,opacity:1,flatshading:false,hoverinfo:'skip',showlegend:false,lighting:{{ambient:.55,diffuse:.78,specular:.14,roughness:.76}},lightposition:{{x:40,y:70,z:90}}}});
    const traces = [
      makeMesh(d.body,flesh,true),
      makeMesh(d.hair,'rgb(78,32,62)',true),
      makeMesh(d.detail,'rgb(112,38,55)',true),
      makeMesh(d.torso,flesh,false),
      {{type:'mesh3d',x:d.torso.x,y:d.torso.y,z:d.torso.z,i:d.torso.i,j:d.torso.j,k:d.torso.k,intensity:d.torso.intensity,intensitymode:'vertex',colorscale:d.colorscale,autocolorscale:false,cmin:d.cmin,cmax:d.cmax,showscale:true,colorbar:{{title:{{text:d.metric}},thickness:14,len:.55}},opacity:1,flatshading:false,hovertemplate:d.metric+': %{{intensity:.4f}}<extra></extra>',showlegend:false,lighting:{{ambient:1,diffuse:0,specular:0,roughness:1,fresnel:0}}}},
      {{type:'scatter3d',mode:'markers',x:d.torso.x.filter((_,i)=>i%3===0),y:d.torso.y.filter((_,i)=>i%3===0),z:d.torso.z.filter((_,i)=>i%3===0),marker:{{size:2,color:d.torso.intensity.filter((_,i)=>i%3===0),colorscale:d.colorscale,autocolorscale:false,cmin:d.cmin,cmax:d.cmax,line:{{width:0}}}},hoverinfo:'skip',visible:false,showlegend:false}},
      {{type:'scatter3d',mode:'markers+text',x:d.points.map(p=>p.xyz_cm[0]),y:d.points.map(p=>p.xyz_cm[1]),z:d.points.map(p=>p.xyz_cm[2]),text:d.points.map(p=>p.id),textposition:'top center',marker:{{size:3,color:d.points.map(p=>d.values[p.id]),colorscale:d.colorscale,autocolorscale:false,cmin:d.cmin,cmax:d.cmax,line:{{color:text,width:1}}}},hovertext:d.points.map(p=>p.id+' · '+p.label+'<br>'+d.metric+': '+d.values[p.id]),hoverinfo:'text',textfont:{{color:text,size:11}},showlegend:false}}
    ];
    const axis=(title,range)=>({{title:{{text:title}},range,gridcolor:grid,zerolinecolor:grid,color:text,showbackground:false}});
    const layout={{margin:{{l:0,r:0,t:0,b:0}},paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',font:{{color:text}},scene:{{xaxis:axis('x / cm',[-8,8]),yaxis:axis('y / cm',[-6,6]),zaxis:axis('z / cm',[-18,18]),aspectmode:'manual',aspectratio:{{x:.7,y:.58,z:1.7}},camera:{{eye:{{x:1.25,y:1.8,z:.72}},up:{{x:0,y:0,z:1}}}},dragmode:'orbit'}}}};
    Plotly.newPlot('paul-upper-body-heatmap-plot-v1',traces,layout,{{responsive:true,displaylogo:false,scrollZoom:true,modeBarButtonsToRemove:['select2d','lasso2d']}});
    const root=document.getElementById('paul-upper-body-heatmap-v1');
    const modes={{heat:[false,true,false],dots:[false,true,true],skin:[true,false,false]}};
    root.querySelectorAll('button[data-mode]').forEach(btn=>btn.addEventListener('click',()=>{{
      const state=modes[btn.dataset.mode];
      Plotly.restyle('paul-upper-body-heatmap-plot-v1',{{visible:[state[0],state[1],state[2]]}},[3,4,5]);
      root.querySelectorAll('button[data-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b===btn)));
    }}));
    const cameras={{front:{{x:0,y:2.3,z:.04}},left:{{x:2.3,y:0,z:.04}},right:{{x:-2.3,y:0,z:.04}},back:{{x:0,y:-2.3,z:.04}},iso:{{x:1.25,y:1.8,z:.72}}}};
    root.querySelectorAll('button[data-view]').forEach(btn=>btn.addEventListener('click',()=>Plotly.relayout('paul-upper-body-heatmap-plot-v1',{{'scene.camera.eye':cameras[btn.dataset.view]}})));
  }})();
  </script>
</div>'''
    path.write_text(html, encoding="utf-8")


def write_preview(path, meshes, torso, intensity, points, point_values, metric_label):
    os.environ.setdefault("MPLCONFIGDIR", "/tmp/paul-heatmap-mpl")
    import matplotlib.pyplot as plt
    from matplotlib import colormaps
    from matplotlib.colors import Normalize
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection

    fig = plt.figure(figsize=(7.1, 8.4), dpi=150)
    ax = fig.add_subplot(111, projection="3d")
    for mesh in meshes:
        if mesh.name == "torso":
            continue
        colour = "#A95E4C" if mesh.material == "skin" else ("#54243F" if mesh.material == "hair" else "#742638")
        poly = Poly3DCollection(mesh.vertices[mesh.faces], linewidths=0, alpha=1.0)
        poly.set_facecolor(colour)
        ax.add_collection3d(poly)
    norm = Normalize(vmin=0.0, vmax=50.0, clip=True)
    cmap = colormaps["turbo"]
    face_values = np.mean(intensity[torso.faces], axis=1)
    heat = Poly3DCollection(torso.vertices[torso.faces], linewidths=0, alpha=1.0)
    heat.set_facecolor(cmap(norm(face_values)))
    ax.add_collection3d(heat)
    xyz = np.asarray([p["xyz_cm"] for p in points])
    pvals = np.asarray([point_values[p["id"]] for p in points])
    ax.scatter(xyz[:, 0], xyz[:, 1], xyz[:, 2], c=pvals, cmap=cmap, norm=norm, s=34, edgecolors="black", linewidths=.4, depthshade=False)
    for p in points:
        x, y, z = p["xyz_cm"]
        ax.text(x, y+.18, z+.2, p["id"], fontsize=7, ha="center")
    ax.set(xlim=(-8,8),ylim=(-6,6),zlim=(-18,18),xlabel="x / cm",ylabel="front y / cm",zlabel="z / cm")
    ax.set_box_aspect((16,12,36))
    ax.view_init(elev=8,azim=90)
    ax.set_title("Paul upper-body respiratory-intensity heatmap\n24-point spatial interpolation")
    sm=plt.cm.ScalarMappable(norm=norm,cmap=cmap)
    sm.set_array([])
    fig.colorbar(sm,ax=ax,shrink=.48,pad=.08,label=metric_label)
    fig.tight_layout()
    fig.savefig(path,bbox_inches="tight",facecolor="white")
    plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--values-csv",type=Path,help="CSV with point,value; accepts P1-P24 or V1-V24")
    parser.add_argument("--output-dir",type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument("--metric-label",default="PCA amplitude")
    parser.add_argument("--smoothing-cm",type=float,default=3.6)
    parser.add_argument("--length",type=float,default=35.0)
    parser.add_argument("--head-circumference",type=float,default=26.0)
    parser.add_argument("--chest-depth",type=float,default=5.4)
    parser.add_argument("--abdomen-depth",type=float,default=6.0)
    args=parser.parse_args()
    if args.smoothing_cm<=0:
        parser.error("--smoothing-cm must be positive")
    values,demo=read_values(args.values_csv)
    meshes,rings,_original_points=build_model(args.length,args.head_circumference,args.chest_depth,args.abdomen_depth)
    points=build_24_points(rings,args.length/35.0)
    dense_torso=loft_mesh("torso_heatmap",densify_rings(rings),n_ring=72,material="heatmap")
    field=interpolate_surface(dense_torso.vertices,points,values,args.smoothing_cm)
    out=args.output_dir.resolve()
    out.mkdir(parents=True,exist_ok=True)
    html_v2_path=out/"paul-upper-body-heatmap-v2.html"
    png_path=out/"paul_upper_body_heatmap_preview.png"
    write_html(html_v2_path,meshes,dense_torso,field,points,values,demo,args.metric_label)
    write_preview(png_path,meshes,dense_torso,field,points,values,args.metric_label)
    print(json.dumps({"html":str(html_v2_path),"html_v2":str(html_v2_path),"preview":str(png_path),"data_mode":"demo" if demo else "measured","points_loaded":24,"range":[float(np.min(field)),float(np.max(field))]},ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
