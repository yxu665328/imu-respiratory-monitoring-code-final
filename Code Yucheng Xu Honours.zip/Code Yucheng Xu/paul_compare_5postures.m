function result = paul_compare_5postures(dataFolder, referenceRR)

result = [];
%% 参数设置
cfg.searchBand_Hz = [0.1 1.5];
cfg.trimStart_s = 2;
cfg.trimEnd_s = 2;
cfg.minDuration_s = 20;
cfg.analysisDuration_s = [];
cfg.bareAxisUnit = 'mg';
cfg.fallbackFs_Hz = [];
cfg.maxGapRatio = 5;
cfg.minHalfPeakRatio = 0.25;
cfg.minLongPeriodCorrelation = 0.30;
cfg.minCorrelationGain = 0.15;
% 仅控制频谱图的显示宽度，不参与检测。约三十五的主峰显示在二十五至四十五附近。
cfg.plotHalfWidth_bpm = 10;

postureNames = ["Supine"; ...
    "45° leftward rotation"; ...
    "45° rightward rotation"; ...
    "135° leftward rotation"; ...
    "135° rightward rotation"];

%% 选择数据文件夹及参考呼吸率
if nargin < 1 || isempty(dataFolder)
    dataFolder = uigetdir(pwd, 'Select the folder containing P1.csv to P5.csv');
    if isequal(dataFolder, 0), return; end
end
assert(isfolder(dataFolder), 'Data folder does not exist.');
if nargin < 2 || isempty(referenceRR)
    answer = inputdlg('Reference RR (breaths/min); leave blank if unknown:', ...
        'Reference RR', [1 65], {'35'});
    if isempty(answer), return; end
    if isempty(strtrim(answer{1}))
        referenceRR = NaN;
    else
        referenceRR = str2double(answer{1});
        assert(isfinite(referenceRR) && referenceRR > 0, ...
            'Reference RR must be a positive number.');
    end
end
assert(isnumeric(referenceRR) && isscalar(referenceRR) && ...
    (isnan(referenceRR) || (isfinite(referenceRR) && referenceRR > 0)), ...
    'Reference RR must be positive or NaN.');

listing = dir(dataFolder);
allNames = string({listing.name});
files = strings(5,1);
for p = 1:5
    expected = sprintf('P%d.csv', p);
    hit = find(~[listing.isdir] & strcmpi(allNames, expected));
    assert(numel(hit) == 1, 'Expected exactly one file named %s.', expected);
    files(p) = allNames(hit);
end

%% 读取并分析，发生错误时记录原因，不生成虚构结果
records = cell(5,1);
details = cell(5,1);
errors = cell(5,1);
for p = 1:5
    try
        [t,A,removedRows] = readIMU(fullfile(dataFolder,files(p)),cfg);
        keep = t >= cfg.trimStart_s & t <= t(end)-cfg.trimEnd_s;
        t = t(keep); A = A(keep,:);
        assert(numel(t) >= 30, 'Fewer than 30 samples remain after trimming.');
        t = t-t(1);
        if ~isempty(cfg.analysisDuration_s)
            assert(isscalar(cfg.analysisDuration_s) && ...
                isfinite(cfg.analysisDuration_s) && ...
                cfg.analysisDuration_s >= cfg.minDuration_s, ...
                'Invalid analysis duration.');
            assert(t(end) >= cfg.analysisDuration_s, 'Recording is too short.');
            keep = t <= cfg.analysisDuration_s;
            t = t(keep); A = A(keep,:);
        end
        assert(t(end) >= cfg.minDuration_s, ...
            'At least %.1f seconds are required after trimming.',cfg.minDuration_s);
        dt = diff(t);
        fs = 1/median(dt);
        gapRatio = max(dt)/median(dt);
        assert(fs > 2*cfg.searchBand_Hz(2), 'Sampling rate is too low.');
        assert(gapRatio <= cfg.maxGapRatio, 'A large timestamp gap was detected.');
        [m,d] = detectRR(t,A,cfg);
        r = struct();
        r.PostureID = p;
        r.Posture = postureNames(p);
        r.File = files(p);
        r.DetectedRR_bpm = m.RR;
        r.ReferenceRR_bpm = referenceRR;
        r.DifferenceFromSetting_bpm = m.RR-referenceRR;
        r.RawLargestPeakRR_bpm = m.RawRR;
        r.HarmonicCorrected = m.HarmonicCorrected;
        r.HalfCandidateRR_bpm = m.HalfCandidateRR;
        r.HalfPeakRatio = m.HalfPeakRatio;
        r.ShortPeriodCorrelation = m.ShortCorrelation;
        r.LongPeriodCorrelation = m.LongCorrelation;
        r.UnresolvedHalfPeak = m.UnresolvedHalfPeak;
        r.CompetingPeakRR_bpm = m.CompetingRR;
        r.CompetingPeakRatio = m.CompetingPeakRatio;
        r.PeakToMedian = m.PeakToMedian;
        r.Duration_s = t(end);
        r.Samples = numel(t);
        r.MedianFs_Hz = fs;
        r.RecordLengthScale_bpm = 60/t(end);
        r.TimingCV = std(dt)/median(dt);
        r.MaxGapRatio = gapRatio;
        r.RemovedRows = removedRows;
        records{p} = r;
        details{p} = d;
    catch ME
        errors{p} = struct('PostureID',p,'File',files(p), ...
            'Reason',string(ME.message));
        fprintf(2,'P%d: analysis failed (%s).\n',p,ME.message);
    end
end

%% 每次创建独立输出目录，保留原始数据及先前结果
outputFolder = tempname(dataFolder);
[ok,msg] = mkdir(outputFolder);
assert(ok,'Could not create output folder: %s',msg);
errors = errors(~cellfun(@isempty,errors));
if ~isempty(errors)
    writetable(struct2table([errors{:}]),fullfile(outputFolder,'read_errors.csv'));
end
records = records(~cellfun(@isempty,records));
assert(~isempty(records),'No recordings could be analysed. See read_errors.csv in %s.',outputFolder);
T = sortrows(struct2table([records{:}]),'PostureID');

%% 简洁结果表与相对正躺差异
simple = T(:,{'PostureID','Posture','DetectedRR_bpm', ...
    'ReferenceRR_bpm','DifferenceFromSetting_bpm'});
writetable(simple,fullfile(outputFolder,'RR_results.csv'));
% 详细数据只保存在文件中，不在图表或命令窗口显示。
writetable(T,fullfile(outputFolder,'RR_details.csv'));
C = table((2:5)',postureNames(2:5),nan(4,1), ...
    'VariableNames',{'PostureID','Posture','RRdifference_bpm'});
base = find(T.PostureID == 1,1);
if ~isempty(base)
    for j = 1:4
        k = find(T.PostureID == j+1,1);
        if ~isempty(k)
            C.RRdifference_bpm(j) = T.DetectedRR_bpm(k)-T.DetectedRR_bpm(base);
        end
    end
end
writetable(C,fullfile(outputFolder,'RR_vs_supine.csv'));
S = struct('ValidPostures',height(T), ...
    'ReferenceRR_bpm',referenceRR, ...
    'MinRR_bpm',min(T.DetectedRR_bpm), ...
    'MaxRR_bpm',max(T.DetectedRR_bpm), ...
    'RangeRR_bpm',max(T.DetectedRR_bpm)-min(T.DetectedRR_bpm));
writetable(struct2table(S),fullfile(outputFolder,'RR_summary.csv'));

%% 呼吸率比较图，所有成功分析的姿势采用相同标记
rr = nan(5,1);
rr(T.PostureID) = T.DetectedRR_bpm;
fig = figure('Color','w','Name','RR comparison', ...
    'Position',[100 100 1100 500]);
plot(1:5,rr,'-o','Color',[0.12 0.40 0.72], ...
    'MarkerFaceColor',[0.12 0.40 0.72],'LineWidth',1.5, ...
    'MarkerSize',7,'DisplayName','Estimated RR');
hold on;
if isfinite(referenceRR)
    yline(referenceRR,'k--','LineWidth',1.1,'DisplayName','Reference RR');
end
for p = 1:5
    if isfinite(rr(p))
        text(p,rr(p),sprintf('  %.2f',rr(p)), ...
            'VerticalAlignment','bottom','FontSize',11);
    end
end
xticks(1:5);
xticklabels(postureNames);
xtickangle(12);
xlim([0.7 5.3]);
xlabel('Posture'); ylabel('RR (breaths/min)');
title('Respiratory rate across five postures');
grid on; box off;
legend('Location','best');
saveas(fig,fullfile(outputFolder,'comparison_RR.png'));

%% 主峰局部频谱图，缩放显示而不删改完整频谱
centre = median(T.DetectedRR_bpm);
lo = max(60*cfg.searchBand_Hz(1), ...
    min(centre-cfg.plotHalfWidth_bpm,min(T.DetectedRR_bpm)-3));
hi = min(60*cfg.searchBand_Hz(2), ...
    max(centre+cfg.plotHalfWidth_bpm,max(T.DetectedRR_bpm)+3));
figSpectrum = figure('Color','w','Name','Main peak spectra', ...
    'Position',[100 50 1050 900]);
for p = 1:5
    subplot(5,1,p);
    k = find(T.PostureID == p,1);
    if isempty(k)
        axis off;
        title(sprintf('P%d | %s | No result',p,char(postureNames(p))));
        continue;
    end
    d = details{p};
    fRR = 60*d.Frequency;
    visible = fRR >= lo & fRR <= hi;
    % 仅绘图时按当前显示窗口最大功率归一化，不用于幅度比较。
    displayPower = d.Power/max(max(d.Power(visible)),eps);
    plot(fRR,displayPower,'Color',[0.12 0.40 0.72],'LineWidth',1.3);
    hold on;
    xline(T.DetectedRR_bpm(k),'--','Color',[0.25 0.25 0.25]);
    xlim([lo hi]); ylim([0 1.1]);
    ylabel('Normalised power');
    title(sprintf('P%d | %s | RR = %.2f breaths/min', ...
        p,char(postureNames(p)),T.DetectedRR_bpm(k)));
    grid on; box off;
end
xlabel('Frequency equivalent (breaths/min)');
sgtitle('Respiratory spectra: main-peak region');
saveas(figSpectrum,fullfile(outputFolder,'RR_spectra.png'));

%% 保存完整结果，命令窗口只显示简洁表格
result = struct('Config',cfg,'ReferenceRR',referenceRR, ...
    'Recordings',T,'Comparisons',C,'Summary',S, ...
    'Details',{details},'OutputFolder',outputFolder);
save(fullfile(outputFolder,'RR_analysis.mat'),'result');
fprintf('\n');
disp(simple(:,{'PostureID','Posture','DetectedRR_bpm'}));
fprintf('Results saved to:\n%s\n',outputFolder);
end

function [m,d] = detectRR(t,A,cfg)
% 保留宽频带最大峰、半频峰及周期重复性联合选峰。
t = t(:)-t(1);
D = [ones(size(t)),t-mean(t)];
Ad = A-D*(D\A);
fs = 1/median(diff(t));
tu = (0:1/fs:t(end))';
Au = interp1(t,Ad,tu,'linear');
N = numel(tu);
window = 0.5-0.5*cos(2*pi*(0:N-1)'/(N-1));
assert(sum(sum((Au.*window).^2)) > eps, ...
    'No measurable variation remains after detrending.');
nfft = 2^nextpow2(8*N);
F = fft(Au.*window,nfft,1);
frequency = (0:nfft/2)'*fs/nfft;
powerXYZ = sum(abs(F(1:nfft/2+1,:)).^2,2)/sum(window.^2);
band = frequency >= cfg.searchBand_Hz(1) & frequency <= cfg.searchBand_Hz(2);
indices = find(band);
[largestPower,pos] = max(powerXYZ(indices));
largestIndex = indices(pos);
highFrequency = refinePeak(frequency(largestIndex),Au,window,tu,fs/nfft,cfg);
selectedFrequency = highFrequency;
selectedPower = largestPower;
localPeaks = find(powerXYZ(2:end-1)>powerXYZ(1:end-2) & ...
    powerXYZ(2:end-1)>=powerXYZ(3:end))+1;
localPeaks = localPeaks(band(localPeaks));
harmonicCorrected = false;
halfCandidateRR = NaN; halfPeakRatio = NaN;
shortCorrelation = NaN; longCorrelation = NaN;
unresolvedHalfPeak = false;
halfTarget = highFrequency/2;
halfTolerance = max(1/t(end),0.03*highFrequency);
candidates = localPeaks(abs(frequency(localPeaks)-halfTarget)<=halfTolerance);
if halfTarget >= cfg.searchBand_Hz(1) && ~isempty(candidates)
    [halfPower,j] = max(powerXYZ(candidates));
    lowFrequency = refinePeak(frequency(candidates(j)),Au,window,tu,fs/nfft,cfg);
    halfCandidateRR = 60*lowFrequency;
    halfPeakRatio = halfPower/max(largestPower,eps);
    if halfPeakRatio >= cfg.minHalfPeakRatio
        Y = bandLimitedSignal(Au,fs,cfg.searchBand_Hz);
        shortCorrelation = periodCorrelation(Y,fs,highFrequency);
        longCorrelation = periodCorrelation(Y,fs,lowFrequency);
        acceptLower = isfinite(shortCorrelation) && isfinite(longCorrelation) && ...
            longCorrelation >= cfg.minLongPeriodCorrelation && ...
            longCorrelation-shortCorrelation >= cfg.minCorrelationGain;
        if acceptLower
            selectedFrequency = lowFrequency;
            selectedPower = halfPower;
            harmonicCorrected = true;
        else
            unresolvedHalfPeak = true;
        end
    end
end
% 保留竞争峰诊断数值，但不在图上增加诊断标记。
other = localPeaks(abs(frequency(localPeaks)-selectedFrequency)>1.5/t(end));
if harmonicCorrected
    other = other(abs(frequency(other)-highFrequency)> ...
        max(1/t(end),0.03*highFrequency));
end
competingRR = NaN; competingRatio = 0;
if ~isempty(other)
    [otherPower,j] = max(powerXYZ(other));
    competingRR = 60*frequency(other(j));
    competingRatio = otherPower/max(selectedPower,eps);
end
m = struct('RR',60*selectedFrequency,'RawRR',60*highFrequency, ...
    'HarmonicCorrected',harmonicCorrected,'HalfCandidateRR',halfCandidateRR, ...
    'HalfPeakRatio',halfPeakRatio,'ShortCorrelation',shortCorrelation, ...
    'LongCorrelation',longCorrelation,'UnresolvedHalfPeak',unresolvedHalfPeak, ...
    'CompetingRR',competingRR,'CompetingPeakRatio',competingRatio, ...
    'PeakToMedian',selectedPower/max(median(powerXYZ(band)),eps));
d = struct('Frequency',frequency(band),'Power',powerXYZ(band));
end

function f = refinePeak(initialFrequency,A,window,t,step,cfg)
% 零填充及局部细化不增加真实频率分辨能力。
lower = max(cfg.searchBand_Hz(1),initialFrequency-step);
upper = min(cfg.searchBand_Hz(2),initialFrequency+step);
f = initialFrequency;
if upper <= lower, return; end
weighted = A.*window;
if sum(weighted(:).^2)<=eps, return; end
objective = @(x) -sum(abs(weighted'*exp(-1i*2*pi*x*t)).^2);
f = fminbnd(objective,lower,upper,optimset('TolX',1e-7,'Display','off'));
end

function Y = bandLimitedSignal(A,fs,band)
% 镜像延拓及频带限制仅用于周期判断。
N = size(A,1);
extended = [flipud(A(2:end,:)); A; flipud(A(1:end-1,:))];
M = size(extended,1);
frequency = (0:M-1)'*fs/M;
absoluteFrequency = min(frequency,fs-frequency);
mask = absoluteFrequency>=band(1) & absoluteFrequency<=band(2);
filtered = real(ifft(fft(extended,[],1).*mask,[],1));
Y = filtered(N:2*N-1,:);
cut = min(round(2*fs),floor(N/10));
if cut>0, Y = Y(cut+1:end-cut,:); end
Y = Y-mean(Y,1);
end

function value = periodCorrelation(Y,fs,frequency)
% 计算候选周期延迟前后的三轴归一化内积。
value = NaN;
lag = round(fs/frequency);
if lag<1 || size(Y,1)<=2*lag, return; end
X1 = Y(1:end-lag,:); X2 = Y(1+lag:end,:);
denominator = sqrt(sum(X1(:).^2)*sum(X2(:).^2));
if denominator<=eps, return; end
value = sum(X1(:).*X2(:))/denominator;
end

function [t,A,removedRows] = readIMU(filePath,cfg)
% 寻找原始表头，支持开头少量日志行。
fid = fopen(filePath,'r');
assert(fid>=0,'Could not open the CSV file.');
cleanup = onCleanup(@() fclose(fid));
headerLine = 0;
for k = 1:100
    line = fgetl(fid);
    if ~ischar(line), break; end
    names = normalizeNames(split(string(line),','));
    hasX = any(ismember(names,["ax","axmg","axg","axms2","accelx","accelxmg"]));
    hasY = any(ismember(names,["ay","aymg","ayg","ayms2","accely","accelymg"]));
    if hasX && hasY, headerLine = k; break; end
end
clear cleanup
assert(headerLine>0,'No supported acceleration header was found in the first 100 lines.');
options = detectImportOptions(filePath,'Delimiter',',','NumHeaderLines',headerLine-1);
options.VariableNamesLine = headerLine;
options.DataLines = [headerLine+1 Inf];
T = readtable(filePath,options);
names = normalizeNames(string(T.Properties.VariableNames));
A = zeros(height(T),3);
axisNames = ["x","y","z"];
% 将三轴数据统一为毫重力加速度单位。
for j = 1:3
    a = axisNames(j);
    choices = ["a"+a,"a"+a+"mg","a"+a+"g","a"+a+"ms2", ...
        "accel"+a,"accel"+a+"mg"];
    index = find(ismember(names,choices));
    assert(numel(index)==1,'Missing or ambiguous acceleration axis: %s.',char(a));
    column = names(index);
    if endsWith(column,'mg')
        scale = 1;
    elseif endsWith(column,'ms2')
        scale = 1000/9.80665;
    elseif column == "a"+a+"g"
        scale = 1000;
    else
        switch cfg.bareAxisUnit
            case 'mg', scale = 1;
            case 'g', scale = 1000;
            case 'm/s2', scale = 1000/9.80665;
            otherwise, error('Invalid bareAxisUnit setting.');
        end
    end
    A(:,j) = numericColumn(T,index)*scale;
end
% 优先使用设备时间戳，禁止在未知采样率时任意假定时间。
known = ["timeus","timems","times","elapsedtimes","elapsedseconds"];
timeIndex = []; timeScale = 1;
for k = 1:numel(known)
    candidate = find(names==known(k));
    if isempty(candidate), continue; end
    assert(numel(candidate)==1,'Ambiguous timestamp column.');
    timeIndex = candidate;
    if k==1, timeScale = 1e-6; elseif k==2, timeScale = 1e-3; end
    break;
end
if isempty(timeIndex)
    assert(isscalar(cfg.fallbackFs_Hz) && isfinite(cfg.fallbackFs_Hz) && ...
        cfg.fallbackFs_Hz>0,'No device timestamps. Set fallbackFs_Hz only if the sampling rate is known.');
    t = (0:height(T)-1)'/cfg.fallbackFs_Hz;
else
    t = numericColumn(T,timeIndex)*timeScale;
end
valid = isfinite(t) & all(isfinite(A),2);
removedRows = sum(~valid);
t = t(valid); A = A(valid,:);
assert(numel(t)>=30,'Fewer than 30 valid numeric rows.');
assert(all(diff(t)>0),'Timestamps contain duplicates, resets, or rollover.');
t = t-t(1);
end

function x = numericColumn(T,index)
% 文本形式数字及数值列统一转换为双精度列向量。
x = T{:,index};
if ~isnumeric(x), x = str2double(string(x)); end
x = double(x(:));
end

function names = normalizeNames(names)
% 表头转小写并去掉空格、括号和下划线。
names = regexprep(lower(names),'[^a-z0-9]','');
end
